import { readdir, stat, readFile } from "node:fs/promises";
import assert from "node:assert/strict";

async function bytes(path) {
  const files = await readdir(path, { withFileTypes: true });
  let total = 0;
  for (const file of files) total += file.isDirectory() ? await bytes(`${path}/${file.name}`) : (await stat(`${path}/${file.name}`)).size;
  return total;
}
const units = ["altushka", "girlfriend", "granny", "speaker", "cat", "kiosk", "patrol", "boss", "skuf"];
for (const unit of units) {
  assert.ok((await stat(`dist/art/units/source-${unit}.webp`)).size > 0);
  assert.ok((await stat(`dist/art/${unit}.webp`)).size > 0);
}
const report = JSON.parse(await readFile("assets/source-art/pixel-audit.json", "utf8"));
for (const unit of units) assert.equal(report[unit].rgbMismatchPixels, 0);
const total = await bytes("dist");
assert.ok(total < 70 * 1024 * 1024, `Build exceeds 70 MiB: ${total}`);
console.log(`Build audit passed: ${(total / 1024 / 1024).toFixed(2)} MiB, all original-art textures present, 0 changed source RGB pixels.`);