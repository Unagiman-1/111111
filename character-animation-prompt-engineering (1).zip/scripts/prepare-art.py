"""Compatibility entry point for the source-only artwork pipeline."""
from pathlib import Path
import runpy

runpy.run_path(str(Path(__file__).with_name("prepare-source-art.py")), run_name="__main__")
