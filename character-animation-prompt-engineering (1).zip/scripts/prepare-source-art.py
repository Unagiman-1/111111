"""Source-pixel cutouts. Requires Pillow only, no models or synthesized anatomy."""

import hashlib
import json
import shutil
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter

ROOT = Path(__file__).resolve().parent.parent
ART = ROOT / "public/art"
SOURCE = ROOT / "assets/source-art"
INCOMING = ROOT / "assets/incoming"
UNITS = ART / "units"
for folder in (SOURCE, INCOMING, UNITS):
    folder.mkdir(parents=True, exist_ok=True)

# Background-only masks, traced on the supplied paintings at height 768.
# Missing legs in a cropped portrait deliberately remain missing.
OUTLINES = {
 "altushka": [[(226,4),(259,8),(283,23),(297,47),(298,90),(316,109),(325,147),(326,222),(335,300),(350,308),(400,267),(458,222),(480,217),(491,229),(468,247),(437,275),(394,312),(376,327),(356,340),(363,393),(380,450),(394,503),(407,555),(419,620),(428,669),(443,746),(385,750),(377,724),(374,681),(368,629),(359,610),(330,624),(295,637),(261,644),(230,642),(214,650),(215,702),(211,721),(106,724),(108,708),(135,693),(153,674),(155,643),(140,631),(115,625),(103,607),(98,575),(101,530),(102,485),(108,449),(112,400),(122,362),(133,334),(141,292),(150,241),(157,190),(167,153),(186,131),(198,113),(198,87),(197,51),(204,28)]],
 "girlfriend": [[(180,27),(218,7),(278,0),(334,5),(365,23),(391,62),(400,104),(391,165),(380,218),(371,247),(405,286),(418,327),(431,380),(451,446),(474,515),(497,577),(512,634),(512,768),(0,768),(0,331),(21,306),(49,284),(95,266),(137,245),(151,212),(140,171),(137,120),(148,68)]],
 "granny": [[(199,17),(245,4),(276,22),(300,47),(318,78),(320,126),(309,178),(307,214),(328,259),(347,303),(380,343),(413,350),(449,372),(457,409),(460,451),(471,495),(468,542),(455,573),(432,581),(427,653),(435,716),(443,768),(0,768),(0,260),(31,233),(61,215),(84,190),(94,154),(117,116),(137,78),(163,44)],[(354,187),(371,159),(401,141),(435,143),(469,163),(495,191),(511,232),(510,275),(490,311),(464,331),(442,344),(430,377),(411,393),(395,377),(400,342),(372,322),(352,289),(346,246)]],
 "speaker": [[(191,27),(230,4),(289,0),(329,19),(357,46),(367,82),(357,127),(338,171),(315,201),(296,221),(310,254),(332,294),(353,349),(370,406),(390,472),(398,517),(385,551),(335,570),(316,614),(295,665),(279,768),(0,768),(0,298),(19,237),(47,182),(91,134),(139,102),(166,61)],[(380,239),(512,209),(512,669),(473,701),(448,706),(446,768),(219,768),(211,704),(195,690),(195,630),(206,600),(243,572),(356,569),(382,539)]],
 "patrol": [[(172,61),(195,23),(243,3),(286,3),(321,22),(336,54),(338,101),(327,141),(326,171),(349,199),(377,229),(393,273),(405,327),(415,395),(430,455),(443,509),(453,558),(470,607),(488,647),(495,682),(477,704),(466,768),(0,768),(0,329),(16,279),(50,242),(99,211),(139,192),(158,155),(163,112)],[(471,490),(487,486),(499,497),(478,586),(469,668),(447,721),(435,716),(449,633),(459,561)]],
 "skuf": [[(234,27),(271,9),(320,9),(362,22),(388,50),(398,91),(400,137),(386,179),(382,211),(406,245),(426,288),(438,347),(455,403),(463,464),(477,521),(484,563),(480,606),(459,631),(438,648),(424,700),(415,768),(54,768),(34,721),(36,675),(43,634),(41,599),(36,563),(32,515),(27,472),(22,425),(27,374),(39,326),(64,285),(90,251),(132,218),(172,190),(203,165),(215,116),(216,69)]],
 "boss": [[(191,38),(217,16),(267,11),(307,24),(337,51),(348,88),(347,137),(346,171),(363,202),(395,236),(425,290),(444,350),(459,408),(479,466),(502,514),(512,571),(512,768),(0,768),(0,206),(33,186),(82,166),(126,160),(162,140),(176,91)]],
 "cat": [[(122,16),(138,22),(177,70),(201,68),(247,73),(276,48),(287,60),(283,93),(300,125),(297,165),(286,204),(300,233),(328,260),(352,303),(372,351),(398,395),(426,443),(448,491),(458,535),(477,589),(491,640),(487,699),(468,747),(445,765),(404,768),(392,739),(412,690),(428,643),(433,602),(417,582),(382,583),(331,579),(285,579),(243,577),(210,575),(172,573),(140,572),(112,563),(108,531),(113,485),(101,443),(96,407),(87,368),(83,329),(88,282),(93,243),(101,202),(94,161),(102,119),(111,92)]],
 "kiosk": [[(90,20),(151,0),(512,0),(512,614),(39,614),(37,493),(51,465),(100,444),(124,419),(135,382),(140,341),(147,298),(159,265),(175,230),(179,197),(180,160),(194,123),(210,91),(251,75),(296,74),(333,82),(355,101),(369,135),(380,182),(394,219),(412,244),(420,280),(427,318),(438,354),(455,377),(476,381),(486,350),(512,324),(512,0),(93,0)]],
}

report = {}
for name in OUTLINES:
    original = ART / f"{name}.png"
    backup = SOURCE / f"{name}.png"
    if original.exists() and not backup.exists():
        shutil.copy2(original, backup)
    incoming = next((INCOMING / f"{name}{ext}" for ext in (".png", ".webp", ".jpg", ".jpeg") if (INCOMING / f"{name}{ext}").exists()), None)
    path = incoming or backup
    image = Image.open(path).convert("RGBA")
    image.thumbnail((768, 1152), Image.Resampling.LANCZOS)
    image.convert("RGB").save(ART / f"{name}.webp", "WEBP", lossless=True, method=6)
    mask = image.getchannel("A")
    if mask.getextrema() == (255, 255):
        if incoming:
            raise RuntimeError(f"{path}: use a transparent PNG or import a white-background image through the in-game artwork studio")
        mask = Image.new("L", image.size, 0)
        draw = ImageDraw.Draw(mask)
        scale = image.height / (614 if name == "kiosk" else 768)
        for contour in OUTLINES[name]:
            draw.polygon([(round(x*scale), round(y*scale)) for x,y in contour], fill=255)
        mask = mask.filter(ImageFilter.GaussianBlur(0.65))
    image.putalpha(mask)
    box = mask.getbbox()
    if not box:
        raise RuntimeError(f"Empty cutout for {name}")
    sprite = image.crop(box)
    destination = UNITS / f"source-{name}.webp"
    sprite.save(destination, "WEBP", lossless=True, exact=True, method=6)
    decoded = Image.open(destination).convert("RGBA")
    original_pixels, decoded_pixels = sprite.load(), decoded.load()
    mismatch = sum(1 for y in range(sprite.height) for x in range(sprite.width) if original_pixels[x,y][3] and original_pixels[x,y] != decoded_pixels[x,y])
    if mismatch:
        raise RuntimeError(f"Pixel audit failed for {name}: {mismatch}")
    report[name] = {"source": str(path.relative_to(ROOT)), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "size": list(sprite.size), "fullBody": name == "altushka" and not incoming, "rgbMismatchPixels": mismatch}
    print(f"{name}: {sprite.width}x{sprite.height}, original RGB retained", flush=True)

(SOURCE / "pixel-audit.json").write_text(json.dumps(report, indent=2) + "\n")
manifest = {name: {"width": data["size"][0], "height": data["size"][1], "fullBody": data["fullBody"]} for name, data in report.items()}
(ROOT / "src/game/rig-manifest.ts").write_text("// Generated from source artwork by scripts/prepare-source-art.py.\nexport const BUILTIN_ART = " + json.dumps(manifest, indent=2) + " as const;\n")
print("Source pixel audit passed for all 9 paintings.")