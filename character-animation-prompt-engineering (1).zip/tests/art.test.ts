import assert from "node:assert/strict";
import { test } from "node:test";
import { removeEdgeBackground } from "../src/game/alpha-mask";
import { ART_UNITS } from "../src/game/art-types";
import {
  MOTION_RIGS, applyRigid, hasArticulatedGait, rigidLength,
  sampleSourceMotion, sourcePoint, toLocal,
} from "../src/game/source-motion";

function fixture() {
  const pixels = new Uint8ClampedArray(9 * 9 * 4).fill(255);
  for (let y = 2; y < 7; y++) for (let x = 2; x < 7; x++) {
    const p = (y * 9 + x) * 4;
    pixels[p] = 37; pixels[p + 1] = 51; pixels[p + 2] = 79;
  }
  // A white interior patch represents white clothing, not the external backdrop.
  const center = (4 * 9 + 4) * 4;
  pixels[center] = pixels[center + 1] = pixels[center + 2] = 255;
  return pixels;
}

test("white-key removes only border-connected background and preserves RGB", () => {
  const pixels = fixture(), before = pixels.slice();
  const report = removeEdgeBackground(pixels, 9, 9, "white");
  assert.equal(report.removed, 56);
  assert.equal(pixels[(4 * 9 + 4) * 4 + 3], 255);
  for (let p = 0; p < pixels.length; p += 4) assert.deepEqual([...pixels.slice(p, p + 3)], [...before.slice(p, p + 3)]);
});

test("transparent PNGs pass auto-key without changing any pixel", () => {
  const pixels = fixture(); pixels[3] = 0;
  const before = pixels.slice();
  assert.equal(removeEdgeBackground(pixels, 9, 9, "auto").applied, "none");
  assert.deepEqual(pixels, before);
});

test("no-key mode is exactly identical to the input", () => {
  const pixels = fixture(), before = pixels.slice();
  removeEdgeBackground(pixels, 9, 9, "none");
  assert.deepEqual(pixels, before);
});

test("black-key never invents white fill or recolours pixels", () => {
  const pixels = fixture();
  for (let i = 0; i < pixels.length; i += 4) if (pixels[i] === 255 && pixels[i + 1] === 255 && pixels[i + 2] === 255) pixels[i] = pixels[i + 1] = pixels[i + 2] = 0;
  assert.equal(removeEdgeBackground(pixels, 9, 9, "black").removed, 56);
  assert.equal(pixels[(4 * 9 + 4) * 4 + 3], 255);
});

test("no animation ever stretches the source mesh", () => {
  for (const unit of ART_UNITS) for (const x of [0, .25, .5, .75, 1]) for (const y of [0, .25, .5, .75, 1]) {
    for (const pose of [
      { time: 5, phase: 1.5, walking: true, attack: 1, neutral: true },
      { time: 2, phase: 2.7, walking: true, attack: .6 },
      { time: 7, phase: .3, walking: false, anticipation: .8 },
    ]) assert.deepEqual(sourcePoint(x, y, unit, pose, true), [x, y]);
  }
});

test("rigid transforms preserve source bone lengths and join at original joints", () => {
  const aspect = 848 / 1264;
  const distance = (a: { x: number; y: number }, b: { x: number; y: number }) => Math.hypot(a.x - b.x, a.y - b.y);
  for (const unit of ART_UNITS) for (const phase of [0, .13, .25, .38, .5, .63, .75, .88, .99]) {
    const pose = sampleSourceMotion(unit, { time: 1.4, phase: phase * Math.PI * 2, walking: true, attack: .55, anticipation: .2 }, aspect, true);
    const neck = toLocal(MOTION_RIGS[unit].neck, aspect);
    assert.ok(Math.abs(rigidLength(pose.head, neck, { x: neck.x, y: neck.y - .08 }) - .08) < 1e-10);
    assert.ok(Math.abs(pose.body.angle) < .15);
    if (!pose.legs || !pose.rig?.legs) continue;
    pose.legs.forEach((leg, i) => {
      const source = pose.rig!.legs![i];
      const hip = toLocal(source.hip, aspect), knee = toLocal(source.knee, aspect), ankle = toLocal(source.ankle, aspect);
      assert.ok(Math.abs(rigidLength(leg.upper, hip, knee) - distance(hip, knee)) < 1e-10);
      assert.ok(Math.abs(rigidLength(leg.lower, knee, ankle) - distance(knee, ankle)) < 1e-10);
      assert.ok(distance(applyRigid(leg.upper, knee), leg.lower.target) < 1e-8, `${unit}: knee disconnected`);
      assert.ok(distance(applyRigid(leg.lower, ankle), leg.ankle) < 1e-4, `${unit}: ankle disconnected`);
      assert.ok(Number.isFinite(leg.upper.angle) && Number.isFinite(leg.lower.angle));
    });
  }
});

test("contact foot stays fixed in world space as the root advances", () => {
  const aspect = 848 / 1264;
  for (const unit of ["altushka", "girlfriend", "boss"] as const) {
    const stride = MOTION_RIGS[unit].stride;
    for (const travel of [{ x: 1, y: 0 }, { x: .6, y: .8 }]) {
      for (const [side, times] of [[0, [.04, .15, .3, .46]], [1, [.54, .65, .8, .96]]] as const) {
        const placements = times.map((t) => {
          const pose = sampleSourceMotion(unit, { time: 1, phase: t * Math.PI * 2, walking: true, travel }, aspect, true);
          assert.equal(pose.legs![side].contact, true);
          return {
            x: pose.legs![side].ankle.x + t * stride * travel.x,
            y: pose.legs![side].ankle.y + t * stride * travel.y,
          };
        });
        for (const position of placements) {
          assert.ok(Math.hypot(position.x - placements[0].x, position.y - placements[0].y) < 1e-8, `${unit}: planted foot slides`);
        }
      }
    }
  }
});

test("seated artwork never receives a fabricated walking rig", () => {
  for (const unit of ["cat", "kiosk"] as const) {
    assert.equal(hasArticulatedGait(unit), false);
    assert.equal(sampleSourceMotion(unit, { time: 1, phase: Math.PI / 2, walking: true }, 848 / 1264, true).legs, null);
  }
  for (const unit of ["altushka", "girlfriend", "granny", "speaker", "patrol", "skuf", "boss"] as const) {
    assert.equal(hasArticulatedGait(unit), true);
  }
});