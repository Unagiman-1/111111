import assert from "node:assert/strict";
import { chromium } from "playwright";

const base = process.env.BASE_URL ?? "http://127.0.0.1:5173";
const browser = await chromium.launch({ headless: true, args: ["--no-sandbox"] });
const errors = [];

async function openGame(page) {
  page.on("pageerror", (error) => errors.push(error.message));
  page.on("response", (response) => {
    if (response.url().includes("/art/") && response.status() >= 400) errors.push(`${response.status()} ${response.url()}`);
  });
  await page.goto(base, { waitUntil: "networkidle" });
  await page.getByRole("button", { name: /ВОЙТИ ВО ДВОР/ }).click();
  await page.locator("canvas").waitFor();
}

async function clickWorld(page, x, y) {
  const canvas = page.locator("canvas");
  const box = await canvas.boundingBox();
  assert.ok(box);
  await canvas.click({ position: { x: x * box.width / 1200, y: y * box.height / 720 } });
}

try {
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  await openGame(page);
  await page.getByRole("button", { name: "Подруга, 70 монет" }).click();
  assert.match(await page.locator(".resource.coins").innerText(), /200/);
  await page.getByRole("button", { name: /НАЧАТЬ ПЕРВУЮ ВОЛНУ/ }).click();
  await page.getByRole("button", { name: "Баба Валя, 110 монет" }).click();
  assert.match(await page.locator(".placement-tip").innerText(), /свободную площадку/);
  await clickWorld(page, 390, 345);
  assert.equal(await page.locator(".inspector-person h2").innerText(), "Баба Валя");
  assert.match(await page.locator(".resource.coins").innerText(), /90/);
  await page.getByRole("button", { name: /Улучшить до уровня 2/ }).click();
  assert.match(await page.locator(".inspector-person span").innerText(), /УРОВЕНЬ 2/);
  assert.match(await page.locator(".money-hint").innerText(), /Не хватает/);
  await clickWorld(page, 220, 170);
  assert.equal(await page.locator(".inspector-person h2").innerText(), "Подруга");
  const before = await page.locator(".resource.coins").innerText();
  await page.getByRole("button", { name: /Улучшить до уровня 2/ }).click();
  assert.equal(await page.locator(".resource.coins").innerText(), before);
  assert.match(await page.locator(".battle-notice").innerText(), /НЕ ХВАТАЕТ МОНЕТ/);

  const motion = await page.evaluate(async () => {
    const { ActorArt } = await import("/src/game/actor-art.ts");
    const art = new ActorArt();
    await new Promise((resolve) => setTimeout(resolve, 600));
    const canvas = document.createElement("canvas");
    canvas.width = 180; canvas.height = 180;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas unavailable");
    const render = (kind, value) => {
      ctx.clearRect(0, 0, 180, 180);
      ctx.save(); ctx.translate(90, 165);
      if (kind === "walk") art.drawHuman(ctx, "skuf", 1, value, true, 0);
      if (kind === "attack") art.drawHuman(ctx, "girlfriend", 1, 0, false, value);
      if (kind === "hero") art.drawHero(ctx, value, value ? 1 : 0);
      if (kind === "cat") art.drawCat(ctx, value, 0, value ? 1 : 0);
      ctx.restore();
      return ctx.getImageData(0, 0, 180, 180).data;
    };
    const difference = (first, second) => {
      let changed = 0;
      for (let i = 0; i < first.length; i += 4) if (first[i] !== second[i] || first[i + 3] !== second[i + 3]) changed++;
      return changed;
    };
    return {
      walk: difference(render("walk", 0), render("walk", Math.PI / 2)),
      attack: difference(render("attack", 0), render("attack", 0.5)),
      hero: difference(render("hero", 0), render("hero", 1.1)),
      cat: difference(render("cat", 0), render("cat", 1.1)),
    };
  });
  for (const [kind, changed] of Object.entries(motion)) assert.ok(changed > 100, `${kind} pose should change pixels, got ${changed}`);
  await page.close();

  const upgrades = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  await openGame(upgrades);
  await upgrades.getByRole("button", { name: "Подруга, 70 монет" }).click();
  await upgrades.getByRole("button", { name: /НАЧАТЬ ПЕРВУЮ ВОЛНУ/ }).click();
  await upgrades.getByRole("button", { name: /Улучшить до уровня 2/ }).click();
  await upgrades.getByRole("button", { name: /Битое стекло/ }).click();
  assert.match(await upgrades.locator(".inspector-person span").innerText(), /УРОВЕНЬ 3/);
  await upgrades.getByRole("button", { name: /Открыть капстоун/ }).click();
  assert.match(await upgrades.locator(".inspector-person span").innerText(), /УРОВЕНЬ 4/);
  await upgrades.close();

  const mobile = await browser.newPage({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  await openGame(mobile);
  await mobile.getByRole("button", { name: "Подруга, 70 монет" }).click();
  assert.equal(await mobile.locator(".inspector-person h2").innerText(), "Подруга");
  await mobile.getByRole("button", { name: /Улучшить до уровня 2/ }).click();
  assert.match(await mobile.locator(".inspector-person span").innerText(), /УРОВЕНЬ 2/);
  assert.equal(errors.length, 0, errors.join("\n"));
  console.log(`Browser smoke passed: combat purchase, body hitbox, all upgrade stages, insufficient funds, mobile, animated walk/attack/hero/cat (${JSON.stringify(motion)} changed pixels).`);
} finally {
  await browser.close();
}