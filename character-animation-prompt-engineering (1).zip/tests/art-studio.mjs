import assert from "node:assert/strict";
import { chromium } from "playwright";

const base = process.env.BASE_URL ?? "http://127.0.0.1:5173";
const browser = await chromium.launch({ headless: true, args: ["--no-sandbox", "--enable-unsafe-swiftshader"] });
const errors = [];
try {
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  page.on("pageerror", (error) => errors.push(error.message));
  await page.goto(base, { waitUntil: "networkidle" });
  await page.getByRole("button", { name: "Арты и анимация" }).click();
  await page.getByRole("dialog").waitFor();
  await page.getByRole("button", { name: /Подруга/ }).click();
  assert.equal(await page.getByRole("button", { name: "Шаг", exact: true }).isDisabled(), false);
  await page.getByRole("button", { name: /Кот Барсик/ }).click();
  assert.equal(await page.getByRole("button", { name: "Шаг", exact: true }).isDisabled(), true);
  await page.getByRole("button", { name: /Алтушка/ }).click();
  await page.getByRole("button", { name: "Сравнить с исходником" }).click();
  assert.equal(await page.locator(".studio-reference img").count(), 1);
  await page.getByRole("button", { name: "Исходник", exact: true }).click();

  const png = await page.evaluate(() => {
    const canvas = document.createElement("canvas"); canvas.width = 64; canvas.height = 96;
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "white"; ctx.fillRect(0, 0, 64, 96);
    ctx.fillStyle = "rgb(37, 51, 79)"; ctx.fillRect(12, 12, 40, 72);
    ctx.fillStyle = "white"; ctx.fillRect(25, 25, 14, 14);
    return canvas.toDataURL("image/png").split(",")[1];
  });
  await page.getByLabel("Загрузить оригинал персонажа").setInputFiles({ name: "exact-source-test.png", mimeType: "image/png", buffer: Buffer.from(png, "base64") });
  await page.getByText("Исходник применён и сохранён на этом устройстве.", { exact: true }).waitFor();
  assert.equal(await page.locator(".studio-animated canvas").getAttribute("data-art-source"), "uploaded");
  assert.equal(await page.getByRole("button", { name: "Шаг", exact: true }).isDisabled(), true);

  const fidelity = await page.evaluate(async () => {
    const { getArtwork } = await import("/src/game/art-library.ts");
    const { PuppetPainter, sourceCacheStats } = await import("/src/game/source-painter.ts");
    const art = getArtwork("altushka"); await art.image.decode();
    const canvas = document.createElement("canvas"); canvas.width = 64; canvas.height = 96;
    const ctx = canvas.getContext("2d");
    ctx.translate(32, 96); new PuppetPainter().draw(ctx, "altushka", { time: 0, neutral: true }, 96);
    const pixels = ctx.getImageData(0, 0, 64, 96).data;
    const read = (x, y) => Array.from(pixels.slice((y * 64 + x) * 4, (y * 64 + x) * 4 + 4));
    return { edge: read(0, 0), painted: read(15, 15), clothing: read(30, 30), cache: sourceCacheStats() };
  });
  assert.deepEqual(fidelity.edge, [0, 0, 0, 0]);
  assert.deepEqual(fidelity.painted, [37, 51, 79, 255]);
  assert.deepEqual(fidelity.clothing, [255, 255, 255, 255]);
  assert.ok(fidelity.cache.bytes <= fidelity.cache.limit);
  await page.getByRole("button", { name: "Закрыть арт-студию" }).click();
  await page.getByRole("button", { name: /ВОЙТИ ВО ДВОР/ }).click();
  await page.waitForFunction(() => document.querySelector(".rail-portrait img")?.getAttribute("data-art-source") === "uploaded");
  await page.reload({ waitUntil: "networkidle" });
  await page.getByRole("button", { name: "Арты и анимация" }).click();
  await page.waitForFunction(() => document.querySelector(".studio-animated canvas")?.getAttribute("data-art-source") === "uploaded");
  await page.getByRole("button", { name: "Вернуть арт проекта" }).click();
  await page.getByText("Восстановлен арт из проекта.", { exact: true }).waitFor();
  assert.equal(await page.locator(".studio-animated canvas").getAttribute("data-art-source"), "builtin");
  assert.deepEqual(errors, []);
  console.log("Art studio passed: exact upload, white-background alpha, unchanged RGB, protected white clothing, game integration, reload persistence, source comparison and reset.");
} finally { await browser.close(); }