import assert from "node:assert/strict";
import { chromium } from "playwright";

const base = process.env.BASE_URL ?? "http://127.0.0.1:4173";
const browser = await chromium.launch({ headless: true, args: ["--no-sandbox", "--enable-unsafe-swiftshader"] });
const errors = [];
try {
  for (const mobile of [false, true]) {
    const page = await browser.newPage({ viewport: mobile ? { width: 390, height: 844 } : { width: 1440, height: 900 }, isMobile: mobile, hasTouch: mobile });
    page.on("pageerror", (error) => errors.push(error.message));
    page.on("response", (response) => { if (response.url().includes("/art/") && response.status() >= 400) errors.push(`${response.status()} ${response.url()}`); });
    await page.goto(base, { waitUntil: "networkidle" });
    await page.getByRole("button", { name: "Арты и анимация" }).click();
    await page.getByRole("dialog").waitFor();
    await page.getByRole("button", { name: "Исходник", exact: true }).click();
    assert.equal(await page.locator(".studio-animated canvas").isVisible(), true);
    await page.getByRole("button", { name: "Закрыть арт-студию" }).click();
    await page.getByRole("button", { name: /ВОЙТИ ВО ДВОР/ }).click();
    await page.getByRole("button", { name: "Подруга, 70 монет" }).click();
    await page.getByRole("button", { name: /НАЧАТЬ ПЕРВУЮ ВОЛНУ/ }).click();
    await page.getByRole("button", { name: /Улучшить до уровня 2/ }).click();
    await page.getByRole("button", { name: /Битое стекло/ }).click();
    await page.getByRole("button", { name: /Открыть капстоун/ }).click();
    assert.match(await page.locator(".inspector-person span").innerText(), /УРОВЕНЬ 4/);
    const layout = await page.evaluate(() => ({ width: document.documentElement.scrollWidth, viewport: document.documentElement.clientWidth }));
    assert.equal(layout.width, layout.viewport, "Page should not overflow horizontally");
    await page.close();
  }
  assert.deepEqual(errors, []);
  console.log("Production browser audit passed: desktop/mobile studio, all combat upgrades, no missing images, no runtime errors, no horizontal overflow.");
} finally { await browser.close(); }