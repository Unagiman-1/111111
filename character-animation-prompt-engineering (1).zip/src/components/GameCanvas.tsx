import { useEffect, useRef } from "react";
import { LOGICAL_HEIGHT, LOGICAL_WIDTH } from "../game/data";
import type { Game } from "../game/engine";
import { Renderer } from "../game/renderer";
import { audio } from "../game/audio";
import type { Snapshot, Vec } from "../game/types";

export function GameCanvas({ game, onSnapshot }: { game: Game; onSnapshot: (snapshot: Snapshot) => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const pointerRef = useRef<Vec | null>(null);
  const snapshotRef = useRef(onSnapshot);
  snapshotRef.current = onSnapshot;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const renderer = new Renderer();
    let raf = 0;
    let last = performance.now();
    let accumulator = 0;
    let lastUi = 0;
    let frames = 0;
    let fpsTime = last;
    const fixed = 1 / 30;

    const frame = (now: number) => {
      const elapsed = Math.min(0.1, (now - last) / 1000);
      last = now;
      accumulator += elapsed * game.speed;
      let steps = 0;
      while (accumulator >= fixed && steps < 8) {
        game.update(fixed);
        accumulator -= fixed;
        steps++;
      }
      if (steps === 8) accumulator = 0;
      renderer.render(canvas, game, pointerRef.current);
      for (const event of game.events.splice(0)) audio.event(event);
      audio.setMood(game.waveActive, game.enemies.some((e) => e.type === "boss" && !e.dead));
      frames++;
      if (now - fpsTime > 1000) {
        game.fps = Math.round(frames * 1000 / (now - fpsTime));
        frames = 0; fpsTime = now;
      }
      if (now - lastUi > 90) {
        snapshotRef.current(game.snapshot());
        lastUi = now;
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    snapshotRef.current(game.snapshot());

    const blur = () => {
      if (game.status === "wave" || game.status === "prep") game.paused = true;
      audio.setHidden(true);
      snapshotRef.current(game.snapshot());
    };
    const focus = () => audio.setHidden(false);
    window.addEventListener("blur", blur);
    window.addEventListener("focus", focus);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("blur", blur);
      window.removeEventListener("focus", focus);
    };
  }, [game]);

  const toWorld = (event: React.PointerEvent<HTMLCanvasElement>): Vec => {
    const rect = event.currentTarget.getBoundingClientRect();
    return {
      x: (event.clientX - rect.left) / rect.width * LOGICAL_WIDTH,
      y: (event.clientY - rect.top) / rect.height * LOGICAL_HEIGHT,
    };
  };

  return (
    <canvas
      ref={canvasRef}
      className="game-canvas"
      aria-label="Игровое поле: двор, дорожки врагов и площадки для защитников"
      onPointerMove={(event) => { pointerRef.current = toWorld(event); }}
      onPointerLeave={() => { pointerRef.current = null; }}
      onPointerDown={(event) => {
        if (event.button !== 0) return;
        const p = toWorld(event);
        if (game.targeting) game.castAbility(p.x, p.y);
        else game.selectAt(p.x, p.y);
        snapshotRef.current(game.snapshot());
      }}
      onContextMenu={(event) => {
        event.preventDefault();
        game.targeting = null;
        game.selectedPad = null;
        game.selectedTowerUid = null;
        game.selectedPropUid = null;
        game.selectedSpot = null;
        game.pendingTower = null;
        snapshotRef.current(game.snapshot());
      }}
    />
  );
}
