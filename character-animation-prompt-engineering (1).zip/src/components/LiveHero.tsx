import { SourceFigure } from "./SourceFigure";

export function LiveHero() {
  return (
    <div className="live-hero-doll">
      <SourceFigure unit="altushka" />
    </div>
  );
}