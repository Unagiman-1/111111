import { PuppetPainter } from "./source-painter";
import type { ArtPose, ArtUnit } from "./art-types";
import type { EnemyId, TowerId } from "./types";

export { PuppetPainter, sourceCacheStats } from "./source-painter";

type MotionInput = Pick<ArtPose, "walkWeight" | "travel" | "anticipation">;

// Compatibility facade: every human/cat is now an intact source texture.
export class ActorArt {
  private painter = new PuppetPainter();
  drawHuman(ctx: CanvasRenderingContext2D, kind: Exclude<TowerId, "cat"> | "skuf" | "boss", time: number, phase: number, walking: boolean, attack: number, _flash = 0, motion: MotionInput = {}) {
    this.painter.draw(ctx, kind as ArtUnit, { time, phase, walking, attack, ...motion }, 100);
  }
  drawCat(ctx: CanvasRenderingContext2D, time: number, phase: number, attack: number) {
    this.painter.draw(ctx, "cat", { time, phase, attack }, 78);
  }
  drawHero(ctx: CanvasRenderingContext2D, time: number, attack: number, anticipation = 0) {
    this.painter.draw(ctx, "altushka", { time, attack, anticipation }, 138);
  }
  drawBird(ctx: CanvasRenderingContext2D, time: number, phase: number, color: string) {
    const wing = Math.sin(time * 11 + phase);
    ctx.save(); ctx.fillStyle = color;
    ctx.beginPath(); ctx.moveTo(-2, -12); ctx.quadraticCurveTo(-20, -27 - wing * 10, -30, -8 + wing * 3); ctx.quadraticCurveTo(-13, -12, 0, 0); ctx.fill();
    ctx.beginPath(); ctx.moveTo(2, -12); ctx.quadraticCurveTo(20, -27 + wing * 10, 30, -8 - wing * 3); ctx.quadraticCurveTo(13, -12, 0, 0); ctx.fill();
    ctx.fillStyle = "#495766"; ctx.beginPath(); ctx.ellipse(0, -7, 8, 13, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#c5ae7c"; ctx.beginPath(); ctx.moveTo(6, -13); ctx.lineTo(14, -10); ctx.lineTo(6, -8); ctx.fill(); ctx.restore();
  }
}

export function enemyOutfit(type: EnemyId): "boss" | "skuf" { return type === "boss" ? "boss" : "skuf"; }
