import type { ArtPose, ArtUnit } from "./art-types";

export interface Point { x: number; y: number }
export interface RigidTransform {
  pivot: Point;
  target: Point;
  angle: number;
}
export interface LegRig { hip: Point; knee: Point; ankle: Point }
export interface MotionRig {
  neck: Point;
  cut: number;
  split: number;
  legs?: [LegRig, LegRig];
  stride: number;
  cadence?: number;
  lift?: number;
  overlays?: Point[][];
}
export interface LegPose {
  upper: RigidTransform;
  lower: RigidTransform;
  contact: boolean;
  ankle: Point;
}
export interface SourceMotion {
  body: RigidTransform;
  head: RigidTransform;
  legs: [LegPose, LegPose] | null;
  rig: MotionRig | null;
}

const point = (x: number, y: number): Point => ({ x, y });
const clamp = (n: number, min = 0, max = 1) => Math.max(min, Math.min(max, n));
const smooth = (n: number) => { const t = clamp(n); return t * t * (3 - 2 * t); };
const length = (p: Point) => Math.hypot(p.x, p.y);
const difference = (a: Point, b: Point) => point(a.x - b.x, a.y - b.y);
const phase01 = (phase: number) => ((phase / (Math.PI * 2)) % 1 + 1) % 1;

// Coordinates describe existing cutout joints, not replacement anatomy. The
// seated figures have no walk rig; their heads and bodies still move rigidly.
export const MOTION_RIGS: Record<ArtUnit, MotionRig> = {
  altushka: {
    neck: point(.49, .255), cut: .515, split: .505, stride: .235,
    legs: [
      { hip: point(.425, .505), knee: point(.445, .715), ankle: point(.435, .915) },
      { hip: point(.565, .505), knee: point(.595, .725), ankle: point(.645, .905) },
    ],
  },
  girlfriend: {
    neck: point(.505, .225), cut: .575, split: .515, stride: .20,
    legs: [
      { hip: point(.405, .57), knee: point(.375, .77), ankle: point(.35, .92) },
      { hip: point(.605, .57), knee: point(.62, .77), ankle: point(.655, .915) },
    ],
  },
  granny: {
    neck: point(.44, .25), cut: .795, split: .505, stride: .055, lift: .011,
    legs: [
      { hip: point(.40, .79), knee: point(.39, .87), ankle: point(.40, .935) },
      { hip: point(.58, .79), knee: point(.585, .87), ankle: point(.595, .925) },
    ],
  },
  speaker: {
    neck: point(.495, .23), cut: .615, split: .45, stride: .17,
    legs: [
      { hip: point(.355, .61), knee: point(.345, .76), ankle: point(.345, .895) },
      { hip: point(.53, .61), knee: point(.54, .765), ankle: point(.565, .88) },
    ],
  },
  patrol: {
    neck: point(.51, .23), cut: .615, split: .50, stride: .21,
    legs: [
      { hip: point(.405, .61), knee: point(.375, .775), ankle: point(.365, .92) },
      { hip: point(.595, .61), knee: point(.605, .775), ankle: point(.625, .91) },
    ],
    overlays: [[point(.67, .55), point(.76, .51), point(.76, .74), point(.69, .75), point(.65, .63)]],
  },
  skuf: {
    neck: point(.505, .235), cut: .825, split: .515, stride: .065, cadence: .175, lift: .009,
    legs: [
      { hip: point(.41, .82), knee: point(.415, .875), ankle: point(.415, .93) },
      { hip: point(.605, .82), knee: point(.605, .87), ankle: point(.61, .915) },
    ],
  },
  boss: {
    neck: point(.52, .26), cut: .66, split: .515, stride: .18,
    legs: [
      { hip: point(.405, .655), knee: point(.38, .785), ankle: point(.365, .92) },
      { hip: point(.61, .655), knee: point(.62, .78), ankle: point(.64, .9) },
    ],
  },
  cat: { neck: point(.48, .43), cut: 1, split: .5, stride: 0 },
  kiosk: { neck: point(.585, .465), cut: 1, split: .5, stride: 0 },
};

export const hasArticulatedGait = (unit: ArtUnit) => !!MOTION_RIGS[unit].legs;

// Convert artwork UVs to units of image height, so every rotation is
// orthonormal even though the canvas texture is not square.
export function toLocal(p: Point, aspect: number): Point {
  return point((p.x - .5) * aspect, p.y - 1);
}

export function applyRigid(transform: RigidTransform, p: Point): Point {
  const dx = p.x - transform.pivot.x, dy = p.y - transform.pivot.y;
  const c = Math.cos(transform.angle), s = Math.sin(transform.angle);
  return point(transform.target.x + dx * c - dy * s, transform.target.y + dx * s + dy * c);
}

export function rigidLength(transform: RigidTransform, a: Point, b: Point): number {
  return length(difference(applyRigid(transform, a), applyRigid(transform, b)));
}

function jointChain(hip: Point, knee: Point, ankle: Point, hipTarget: Point, ankleTarget: Point) {
  const upper = length(difference(knee, hip));
  const lower = length(difference(ankle, knee));
  const delta = difference(ankleTarget, hipTarget);
  const distance = Math.max(.0001, length(delta));
  const reach = clamp(distance, Math.abs(upper - lower) + .00001, upper + lower - .00001);
  const direction = point(delta.x / distance, delta.y / distance);
  const along = (upper * upper - lower * lower + reach * reach) / (2 * reach);
  const sideways = Math.sqrt(Math.max(0, upper * upper - along * along));
  const original = difference(knee, hip);
  const oldLine = difference(ankle, hip);
  const bend = Math.sign(oldLine.x * original.y - oldLine.y * original.x) || 1;
  const nextKnee = point(
    hipTarget.x + direction.x * along - direction.y * sideways * bend,
    hipTarget.y + direction.y * along + direction.x * sideways * bend,
  );
  const upperAngle = Math.atan2(nextKnee.y - hipTarget.y, nextKnee.x - hipTarget.x) - Math.atan2(original.y, original.x);
  const lowerAngle = Math.atan2(ankleTarget.y - nextKnee.y, ankleTarget.x - nextKnee.x) - Math.atan2(ankle.y - knee.y, ankle.x - knee.x);
  return {
    upper: { pivot: hip, target: hipTarget, angle: upperAngle },
    lower: { pivot: knee, target: nextKnee, angle: lowerAngle },
  };
}

function footMotion(t: number, side: 0 | 1, stride: number, lift: number, inPlace: boolean) {
  const support = side === 0 ? t < .5 : t >= .5;
  const local = side === 0 ? (support ? t * 2 : (t - .5) * 2) : (support ? (t - .5) * 2 : t * 2);
  if (inPlace) {
    return { support, x: support ? 0 : Math.sin(Math.PI * local) * stride * .23, y: support ? 0 : -Math.sin(Math.PI * local) * lift };
  }
  return {
    support,
    x: support ? stride * (.25 - local * .5) : stride * (-.25 + smooth(local) * .5),
    y: support ? 0 : -Math.sin(Math.PI * local) * lift,
  };
}

export function sampleSourceMotion(unit: ArtUnit, pose: ArtPose, aspect: number, fullBody: boolean): SourceMotion {
  const rig = MOTION_RIGS[unit];
  const neck = toLocal(rig.neck, aspect);
  const hipUV = rig.legs
    ? point((rig.legs[0].hip.x + rig.legs[1].hip.x) / 2, (rig.legs[0].hip.y + rig.legs[1].hip.y) / 2)
    : point(.5, .82);
  const hip = toLocal(hipUV, aspect);
  const identity = { pivot: hip, target: hip, angle: 0 };
  if (pose.neutral) return { body: identity, head: { pivot: neck, target: neck, angle: 0 }, legs: null, rig: null };

  const walking = !!rig.legs && fullBody ? clamp(pose.walkWeight ?? (pose.walking ? 1 : 0)) : 0;
  const phase = phase01(pose.phase ?? 0);
  const breath = Math.sin(pose.time * 1.55 + (pose.phase ?? 0) * (walking ? 0 : .09));
  const settle = Math.sin(pose.time * .68 + .75);
  const recoil = clamp(pose.attack ?? 0);
  const impulseTime = 1 - recoil;
  const impulse = Math.sin(Math.PI * impulseTime) * recoil;
  const headLag = Math.sin(Math.PI * impulseTime) * impulseTime;
  const prepare = clamp(pose.anticipation ?? 0);
  const walkWave = Math.sin(phase * Math.PI * 2);
  const bodyAngle = breath * .0038 + settle * .0014 + walking * walkWave * .009 + prepare * .009 - impulse * .037;
  const shift = point(
    walking * walkWave * aspect * .004 + impulse * aspect * .006,
    walking * (.011 - .007 * Math.sin(phase * Math.PI * 2) ** 2) * (rig.stride < .1 ? .45 : 1) + prepare * .003 + impulse * .003,
  );
  const body: RigidTransform = { pivot: hip, target: point(hip.x + shift.x, hip.y + shift.y), angle: bodyAngle };
  const headAngle = bodyAngle - breath * .0018 - walking * walkWave * .005 + impulse * .017 - headLag * .011;
  const head: RigidTransform = { pivot: neck, target: applyRigid(body, neck), angle: headAngle };

  if (!rig.legs) return { body, head, legs: null, rig };

  const direction = pose.travel ?? point(1, 0);
  const directionLength = length(direction) || 1;
  const travel = point(direction.x / directionLength, direction.y / directionLength);
  const legs = rig.legs.map((leg, index) => {
    const hipPoint = toLocal(leg.hip, aspect);
    const kneePoint = toLocal(leg.knee, aspect);
    const anklePoint = toLocal(leg.ankle, aspect);
    const step = footMotion(phase, index as 0 | 1, rig.stride, rig.lift ?? .026, !!pose.inPlace);
    const ankleTarget = point(
      anklePoint.x + walking * step.x * travel.x,
      anklePoint.y + walking * (step.x * travel.y + step.y),
    );
    const chain = jointChain(hipPoint, kneePoint, anklePoint, applyRigid(body, hipPoint), ankleTarget);
    return {
      ...chain,
      contact: walking > .99 && step.support,
      ankle: ankleTarget,
    };
  }) as [LegPose, LegPose];
  return { body, head, legs, rig };
}

// Legacy sample points are never warped; the renderer draws rigid source
// regions instead of assigning different transforms to shared mesh vertices.
export function sourcePoint(x: number, y: number, _unit: ArtUnit, _pose: ArtPose, _fullBody: boolean): [number, number] {
  return [x, y];
}