// Generated from source artwork by scripts/prepare-source-art.py.
export const BUILTIN_ART = {
  "altushka": {
    "width": 594,
    "height": 1124,
    "fullBody": true
  },
  "girlfriend": {
    "width": 768,
    "height": 1152,
    "fullBody": true
  },
  "granny": {
    "width": 768,
    "height": 1148,
    "fullBody": true
  },
  "speaker": {
    "width": 768,
    "height": 1152,
    "fullBody": true
  },
  "patrol": {
    "width": 751,
    "height": 1150,
    "fullBody": true
  },
  "skuf": {
    "width": 698,
    "height": 1140,
    "fullBody": true
  },
  "boss": {
    "width": 768,
    "height": 1138,
    "fullBody": true
  },
  "cat": {
    "width": 617,
    "height": 1130,
    "fullBody": true
  },
  "kiosk": {
    "width": 714,
    "height": 922,
    "fullBody": true
  }
} as const;
