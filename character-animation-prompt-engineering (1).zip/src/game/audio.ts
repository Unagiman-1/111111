class AudioDirector {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private music: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  private nextBeat = 0;
  private step = 0;
  private activeWave = false;
  private boss = false;
  private enabled = true;
  private hidden = false;
  private lastSfx = new Map<string, number>();
  private noise: AudioBuffer | null = null;
  private drones: OscillatorNode[] = [];

  async start() {
    if (!this.ctx) this.init();
    if (this.ctx?.state === "suspended") await this.ctx.resume();
  }

  private init() {
    const Ctx = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    this.ctx = ctx;
    this.master = ctx.createGain(); this.master.gain.value = this.enabled ? 0.72 : 0;
    this.music = ctx.createGain(); this.music.gain.value = 0.34;
    this.sfxBus = ctx.createGain(); this.sfxBus.gain.value = 0.7;
    this.music.connect(this.master); this.sfxBus.connect(this.master); this.master.connect(ctx.destination);
    const filter = ctx.createBiquadFilter(); filter.type = "lowpass"; filter.frequency.value = 430; filter.Q.value = 1.2; filter.connect(this.music);
    for (const [frequency, volume] of [[55, 0.035], [82.41, 0.022], [110, 0.009]] as const) {
      const osc = ctx.createOscillator(), gain = ctx.createGain();
      osc.type = frequency === 55 ? "triangle" : "sine"; osc.frequency.value = frequency;
      gain.gain.value = volume; osc.connect(gain); gain.connect(filter); osc.start(); this.drones.push(osc);
    }
    const lfo = ctx.createOscillator(), lfoGain = ctx.createGain();
    lfo.frequency.value = 0.075; lfoGain.gain.value = 90; lfo.connect(lfoGain); lfoGain.connect(filter.frequency); lfo.start();
    const buffer = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    this.noise = buffer;
    this.nextBeat = ctx.currentTime + 0.1;
    window.setInterval(() => this.schedule(), 100);
  }

  private schedule() {
    const ctx = this.ctx;
    if (!ctx || ctx.state !== "running") return;
    const beat = 60 / 82 / 2;
    while (this.nextBeat < ctx.currentTime + 0.25) {
      const step = this.step % 16;
      if (step % 8 === 0) this.note(this.nextBeat, step === 0 ? 110 : 130.81, 0.8, 0.022, "triangle", this.music!);
      if (this.activeWave) {
        if (step % 4 === 0) this.kick(this.nextBeat, this.boss ? 0.16 : 0.11);
        if (step % 2 === 1) this.hat(this.nextBeat, this.boss ? 0.036 : 0.022);
        if (step === 4 || step === 12) this.snare(this.nextBeat, 0.055);
      }
      if (this.boss && step % 4 === 2) this.note(this.nextBeat, step % 8 ? 155.56 : 146.83, 0.22, 0.026, "sawtooth", this.music!);
      this.nextBeat += beat;
      this.step++;
    }
  }

  private note(time: number, frequency: number, duration: number, volume: number, type: OscillatorType, destination: AudioNode) {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator(), gain = this.ctx.createGain();
    osc.type = type; osc.frequency.setValueAtTime(frequency, time);
    gain.gain.setValueAtTime(0.0001, time); gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, volume), time + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, time + duration);
    osc.connect(gain); gain.connect(destination); osc.start(time); osc.stop(time + duration + 0.03);
  }

  private kick(time: number, volume: number) {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator(), gain = this.ctx.createGain();
    osc.frequency.setValueAtTime(105, time); osc.frequency.exponentialRampToValueAtTime(42, time + 0.13);
    gain.gain.setValueAtTime(volume, time); gain.gain.exponentialRampToValueAtTime(0.0001, time + 0.18);
    osc.connect(gain); gain.connect(this.music!); osc.start(time); osc.stop(time + 0.2);
  }

  private hat(time: number, volume: number) {
    if (!this.ctx || !this.noise) return;
    const src = this.ctx.createBufferSource(), filter = this.ctx.createBiquadFilter(), gain = this.ctx.createGain();
    src.buffer = this.noise; filter.type = "highpass"; filter.frequency.value = 6200;
    gain.gain.setValueAtTime(volume, time); gain.gain.exponentialRampToValueAtTime(0.0001, time + 0.045);
    src.connect(filter); filter.connect(gain); gain.connect(this.music!); src.start(time); src.stop(time + 0.05);
  }

  private snare(time: number, volume: number) {
    if (!this.ctx || !this.noise) return;
    const src = this.ctx.createBufferSource(), filter = this.ctx.createBiquadFilter(), gain = this.ctx.createGain();
    src.buffer = this.noise; filter.type = "bandpass"; filter.frequency.value = 1700; filter.Q.value = 0.8;
    gain.gain.setValueAtTime(volume, time); gain.gain.exponentialRampToValueAtTime(0.0001, time + 0.12);
    src.connect(filter); filter.connect(gain); gain.connect(this.music!); src.start(time); src.stop(time + 0.13);
  }

  setMood(activeWave: boolean, boss: boolean) { this.activeWave = activeWave; this.boss = boss; }

  event(name: string) {
    if (!this.ctx || !this.enabled || this.hidden) return;
    const now = this.ctx.currentTime;
    const throttle = name === "shot" ? 0.065 : name === "heavy" ? 0.09 : name === "coin" ? 0.08 : 0.025;
    if (now - (this.lastSfx.get(name) ?? -10) < throttle) return;
    this.lastSfx.set(name, now);
    const out = this.sfxBus!;
    switch (name) {
      case "shot": this.note(now, 320 + Math.random() * 70, 0.055, 0.025, "square", out); break;
      case "hero": this.note(now, 440, 0.09, 0.035, "triangle", out); this.note(now + 0.025, 660, 0.08, 0.018, "triangle", out); break;
      case "heavy": this.note(now, 95, 0.12, 0.075, "square", out); break;
      case "speaker": this.note(now, 74, 0.22, 0.045, "sawtooth", out); break;
      case "coin": this.note(now, 880, 0.08, 0.045, "sine", out); this.note(now + 0.06, 1174, 0.11, 0.035, "sine", out); break;
      case "build": this.note(now, 180, 0.09, 0.05, "triangle", out); this.note(now + 0.08, 260, 0.13, 0.04, "triangle", out); break;
      case "upgrade": [330, 440, 660].forEach((f, i) => this.note(now + i * 0.065, f, 0.18, 0.04, "triangle", out)); break;
      case "wave": this.note(now, 110, 0.35, 0.07, "sawtooth", out); break;
      case "waveClear": [220, 277, 330].forEach((f, i) => this.note(now + i * 0.1, f, 0.35, 0.05, "triangle", out)); break;
      case "boss": this.note(now, 55, 0.8, 0.12, "sawtooth", out); this.note(now, 58, 0.8, 0.08, "square", out); break;
      case "bossDown": this.note(now, 65, 0.8, 0.12, "sawtooth", out); break;
      case "telegraph": this.note(now, 190, 0.45, 0.06, "square", out); break;
      case "ability": this.note(now, 130, 0.4, 0.09, "sawtooth", out); this.note(now + 0.04, 390, 0.3, 0.05, "triangle", out); break;
      case "explode": case "alarm": this.snare(now, 0.18); this.note(now, 60, 0.35, 0.1, "sawtooth", out); break;
      case "leak": this.note(now, 120, 0.25, 0.08, "square", out); break;
      case "lost": this.note(now, 82, 1.1, 0.1, "sawtooth", out); break;
      case "deny": this.note(now, 105, 0.08, 0.035, "square", out); break;
    }
  }

  toggle() {
    this.enabled = !this.enabled;
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(this.enabled && !this.hidden ? 0.72 : 0, this.ctx.currentTime, 0.04);
    return this.enabled;
  }

  setHidden(hidden: boolean) {
    this.hidden = hidden;
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(this.enabled && !hidden ? 0.72 : 0, this.ctx.currentTime, 0.05);
  }

  get isEnabled() { return this.enabled; }
}

export const audio = new AudioDirector();
