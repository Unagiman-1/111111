import { getArtwork } from "./art-library";
import type { Artwork, ArtPose, ArtUnit } from "./art-types";
import { sampleSourceMotion, type MotionRig, type Point, type RigidTransform } from "./source-motion";

const MAX_FRAME_BYTES = 18 * 1024 * 1024;
const FRAME_BORDER = .1;
const cache = new Map<string, { canvas: HTMLCanvasElement; bytes: number }>();
let cacheBytes = 0;

export function sourceCacheStats() { return { frames: cache.size, bytes: cacheBytes, limit: MAX_FRAME_BYTES }; }

function cached(key: string): HTMLCanvasElement | null {
  const item = cache.get(key);
  if (!item) return null;
  cache.delete(key);
  cache.set(key, item);
  return item.canvas;
}

function remember(key: string, canvas: HTMLCanvasElement) {
  const bytes = canvas.width * canvas.height * 4;
  while (cacheBytes + bytes > MAX_FRAME_BYTES && cache.size) {
    const oldest = cache.keys().next().value!;
    cacheBytes -= cache.get(oldest)!.bytes;
    cache.delete(oldest);
  }
  cache.set(key, { canvas, bytes });
  cacheBytes += bytes;
}

function sourceTexture(art: Artwork, height: number): CanvasImageSource {
  if (height > 230) return art.image;
  const resolution = height > 125 ? 320 : 224;
  const key = `source:${art.unit}:${art.revision}:${resolution}`;
  const existing = cached(key);
  if (existing) return existing;
  const canvas = document.createElement("canvas");
  canvas.height = resolution;
  canvas.width = Math.max(1, Math.round(resolution * art.width / art.height));
  const context = canvas.getContext("2d");
  if (!context) return art.image;
  context.imageSmoothingQuality = "high";
  context.drawImage(art.image, 0, 0, canvas.width, canvas.height);
  remember(key, canvas);
  return canvas;
}

function drawRegion(
  ctx: CanvasRenderingContext2D,
  texture: CanvasImageSource,
  width: number,
  height: number,
  transform: RigidTransform,
  region: { x: number; y: number; width: number; height: number } | Point[],
  exclusions: Point[][] = [],
) {
  ctx.save();
  ctx.translate(transform.target.x * height, transform.target.y * height);
  ctx.rotate(transform.angle);
  ctx.translate(-transform.pivot.x * height, -transform.pivot.y * height);
  ctx.beginPath();
  if (Array.isArray(region)) {
    for (let i = 0; i < region.length; i++) {
      const x = (region[i].x - .5) * width;
      const y = (region[i].y - 1) * height;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
  } else {
    ctx.rect((region.x - .5) * width, (region.y - 1) * height, region.width * width, region.height * height);
  }
  for (const polygon of exclusions) {
    polygon.forEach((p, i) => {
      const x = (p.x - .5) * width, y = (p.y - 1) * height;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.closePath();
  }
  ctx.clip(exclusions.length ? "evenodd" : "nonzero");
  ctx.drawImage(texture, -width / 2, -height, width, height);
  ctx.restore();
}

function drawLegs(
  ctx: CanvasRenderingContext2D,
  texture: CanvasImageSource,
  width: number,
  height: number,
  rig: MotionRig,
  legs: NonNullable<ReturnType<typeof sampleSourceMotion>["legs"]>,
) {
  if (!rig.legs) return;
  for (let index = 0; index < 2; index++) {
    const data = rig.legs[index];
    const leg = legs[index];
    const x = index === 0 ? 0 : rig.split;
    const regionWidth = index === 0 ? rig.split : 1 - rig.split;
    const kneeStart = data.knee.y - .003;
    // Each fragment uses an isometry of the unchanged source image. Joint
    // overlap is hidden under the original clothing, never stretched over it.
    drawRegion(ctx, texture, width, height, leg.lower,
      { x, y: kneeStart, width: regionWidth, height: 1.01 - kneeStart }, rig.overlays);
    drawRegion(ctx, texture, width, height, leg.upper,
      { x, y: rig.cut - .008, width: regionWidth, height: data.knee.y + .003 - rig.cut + .008 }, rig.overlays);
  }
}

function drawUncached(ctx: CanvasRenderingContext2D, art: Artwork, unit: ArtUnit, pose: ArtPose, height: number) {
    const width = height * art.width / art.height;
    const motion = sampleSourceMotion(unit, pose, art.width / art.height, art.fullBody);
    const texture = sourceTexture(art, height);
    // Imported artwork has no calibrated joints: retain the complete image
    // and use only a grounded, uniform rigid transform.
    if (art.source !== "builtin" || !motion.rig) {
      ctx.save();
      ctx.rotate(motion.body.angle);
      ctx.drawImage(texture, -width / 2, -height, width, height);
      ctx.restore();
      return;
    }

    if (motion.legs) drawLegs(ctx, texture, width, height, motion.rig, motion.legs);
    const torsoTop = motion.rig.neck.y - .012;
    drawRegion(ctx, texture, width, height, motion.body,
      { x: 0, y: torsoTop, width: 1, height: motion.rig.cut + .012 - torsoTop });
    for (const polygon of motion.rig.overlays ?? []) {
      drawRegion(ctx, texture, width, height, motion.body, polygon);
    }
    drawRegion(ctx, texture, width, height, motion.head,
      { x: 0, y: 0, width: 1, height: motion.rig.neck.y + .023 });
}

export class PuppetPainter {
  draw(ctx: CanvasRenderingContext2D, unit: ArtUnit, pose: ArtPose, height = 100) {
    const art = getArtwork(unit);
    if (!art.ready) return;
    const aspect = art.width / art.height;
    if (pose.neutral) {
      ctx.drawImage(art.image, -height * aspect / 2, -height, height * aspect, height);
      return;
    }

    // Shared walking frames avoid doing six clipped source draws for every
    // enemy each frame. Only the small battlefield figures are quantized;
    // portraits and action/transition poses remain continuous.
    const weight = pose.walkWeight ?? (pose.walking ? 1 : 0);
    if (art.source === "builtin" && height <= 110 && pose.walking && weight > .995 &&
        (pose.attack ?? 0) === 0 && (pose.anticipation ?? 0) === 0 && !pose.inPlace) {
      const frames = 20;
      const phase = ((pose.phase ?? 0) / (Math.PI * 2) % 1 + 1) % 1;
      const phaseFrame = Math.floor(phase * frames) % frames;
      const travel = pose.travel ?? { x: 1, y: 0 };
      const angle = Math.atan2(travel.y, travel.x);
      const directions = 16;
      const directionFrame = ((Math.round(angle / (Math.PI * 2) * directions) % directions) + directions) % directions;
      const key = `motion:${unit}:${art.revision}:${phaseFrame}:${directionFrame}`;
      let frame = cached(key);
      if (!frame) {
        const base = 160;
        frame = document.createElement("canvas");
        frame.width = Math.ceil(base * (aspect + FRAME_BORDER * 2));
        frame.height = Math.ceil(base * (1 + FRAME_BORDER * 2));
        const buffer = frame.getContext("2d");
        if (buffer) {
          buffer.translate(frame.width / 2, base * (1 + FRAME_BORDER));
          const direction = directionFrame / directions * Math.PI * 2;
          drawUncached(buffer, art, unit, {
            time: 0, phase: (phaseFrame + .5) / frames * Math.PI * 2,
            walking: true, walkWeight: 1, travel: { x: Math.cos(direction), y: Math.sin(direction) },
          }, base);
          remember(key, frame);
        }
      }
      ctx.drawImage(frame, -height * (aspect / 2 + FRAME_BORDER),
        -height * (1 + FRAME_BORDER), height * (aspect + FRAME_BORDER * 2), height * (1 + FRAME_BORDER * 2));
      return;
    }
    drawUncached(ctx, art, unit, pose, height);
  }
}