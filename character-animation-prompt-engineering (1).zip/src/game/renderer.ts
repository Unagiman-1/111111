import { ENEMIES, LOGICAL_HEIGHT, LOGICAL_WIDTH, PROP_DATA, TOWERS } from "./data";
import type { Game } from "./engine";
import type { Enemy, Tower, Vec } from "./types";
import { ActorArt, enemyOutfit } from "./actor-art";
import { MOTION_RIGS } from "./source-motion";

const ART_PATHS = [
  "/art/courtyard.jpg", "/art/cat.webp",
];

class ArtCache {
  images = new Map<string, HTMLImageElement>();
  constructor() {
    for (const path of ART_PATHS) {
      const image = new Image();
      image.src = path;
      image.decoding = "async";
      this.images.set(path, image);
    }
  }
  get(path: string) {
    const image = this.images.get(path);
    return image?.complete && image.naturalWidth > 0 ? image : null;
  }
}

export class Renderer {
  art = new ArtCache();
  actors = new ActorArt();
  private background: HTMLCanvasElement | null = null;
  private backgroundKey = "";
  private unitScale = 1;
  private leaves = Array.from({ length: 34 }, (_, i) => ({
    x: (i * 197) % LOGICAL_WIDTH, y: (i * 83) % LOGICAL_HEIGHT,
    speed: 8 + (i % 7) * 2, drift: 15 + (i % 5) * 7, size: 2 + (i % 4), phase: i * 1.71,
  }));

  render(canvas: HTMLCanvasElement, game: Game, pointer: Vec | null) {
    const rect = canvas.getBoundingClientRect();
    this.unitScale = rect.width < 600 ? 1.25 : 1;
    const dpr = Math.min(window.devicePixelRatio || 1, 1.6);
    const width = Math.max(1, Math.round(rect.width * dpr));
    const height = Math.max(1, Math.round(rect.height * dpr));
    if (canvas.width !== width || canvas.height !== height) { canvas.width = width; canvas.height = height; }
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) return;
    const sx = width / LOGICAL_WIDTH, sy = height / LOGICAL_HEIGHT;
    ctx.setTransform(sx, 0, 0, sy, 0, 0);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    const trauma = game.shake * game.shake * 11;
    const ox = Math.sin(game.time * 91) * trauma;
    const oy = Math.cos(game.time * 77) * trauma * 0.7;
    ctx.save();
    ctx.translate(ox, oy);
    this.drawCachedBackground(ctx, game);
    this.drawVignette(ctx);
    this.drawPropSpots(ctx, game);
    this.drawLinks(ctx, game);
    this.drawPads(ctx, game);
    this.drawProps(ctx, game);
    this.drawEffects(ctx, game);
    const selected = game.selectedTower;
    if (selected && selected.type !== "kiosk") {
      const pos = game.padPos(selected.pad);
      const range = game.towerStats(selected).range;
      const color = TOWERS[selected.type].color;
      ctx.fillStyle = `${color}0c`; ctx.strokeStyle = `${color}66`; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(pos.x, pos.y, range, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    }
    const figures: { y: number; draw: () => void }[] = [
      ...game.enemies.map((enemy) => ({ y: game.enemyPos(enemy).y, draw: () => this.drawEnemy(ctx, game, enemy) })),
      ...game.towers.map((tower) => ({ y: game.padPos(tower.pad).y, draw: () => this.drawTower(ctx, game, tower) })),
      ...game.fadingActors.map((actor) => ({ y: actor.y, draw: () => this.drawFadingActor(ctx, game, actor) })),
      { y: game.map.hero.y, draw: () => this.drawHero(ctx, game) },
    ];
    figures.sort((a, b) => a.y - b.y);
    for (const figure of figures) figure.draw();
    this.drawProjectiles(ctx, game);
    this.drawParticles(ctx, game);
    this.drawLeaves(ctx, game);
    if (pointer && game.targeting) this.drawTargeting(ctx, game, pointer);
    ctx.restore();
  }

  private drawCachedBackground(ctx: CanvasRenderingContext2D, game: Game) {
    const key = `${game.map.id}:${this.art.get("/art/courtyard.jpg") ? "ready" : "loading"}`;
    if (!this.background || this.backgroundKey !== key) {
      this.background = document.createElement("canvas");
      this.background.width = LOGICAL_WIDTH;
      this.background.height = LOGICAL_HEIGHT;
      const background = this.background.getContext("2d");
      if (background) {
        this.drawBackground(background, game);
        this.drawPaths(background, game);
      }
      this.backgroundKey = key;
    }
    ctx.drawImage(this.background, 0, 0);
  }

  private drawBackground(ctx: CanvasRenderingContext2D, game: Game) {
    const art = this.art.get("/art/courtyard.jpg");
    if (art) {
      const scale = Math.max(LOGICAL_WIDTH / art.naturalWidth, LOGICAL_HEIGHT / art.naturalHeight);
      const w = art.naturalWidth * scale, h = art.naturalHeight * scale;
      ctx.drawImage(art, (LOGICAL_WIDTH - w) / 2, (LOGICAL_HEIGHT - h) / 2, w, h);
    } else {
      const gradient = ctx.createLinearGradient(0, 0, 0, LOGICAL_HEIGHT);
      gradient.addColorStop(0, "#68727f"); gradient.addColorStop(1, "#343b46");
      ctx.fillStyle = gradient; ctx.fillRect(0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);
    }
    ctx.fillStyle = "rgba(25,31,43,.34)";
    ctx.fillRect(0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);
    const light = ctx.createRadialGradient(620, 340, 40, 620, 340, 660);
    light.addColorStop(0, "rgba(166,175,188,.08)"); light.addColorStop(1, "rgba(10,14,24,.3)");
    ctx.fillStyle = light; ctx.fillRect(0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);
    ctx.globalAlpha = 0.08;
    ctx.fillStyle = game.map.tint;
    ctx.fillRect(0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);
    ctx.globalAlpha = 1;
  }

  private drawPaths(ctx: CanvasRenderingContext2D, game: Game) {
    ctx.save(); ctx.lineCap = "round"; ctx.lineJoin = "round";
    ctx.beginPath();
    for (const path of game.map.paths) {
      path.forEach((p, i) => i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y));
    }
    ctx.strokeStyle = "rgba(20,25,31,.14)"; ctx.lineWidth = 58; ctx.stroke();
    ctx.strokeStyle = "rgba(171,174,174,.045)"; ctx.lineWidth = 36; ctx.stroke();
    for (let lane = 0; lane < game.map.paths.length; lane++) {
      const p = game.pathPoint(lane, 65);
      ctx.save(); ctx.translate(p.x, p.y);
      ctx.fillStyle = "rgba(188,113,119,.44)";
      ctx.beginPath(); ctx.moveTo(-8, -5); ctx.lineTo(4, 0); ctx.lineTo(-8, 5); ctx.closePath(); ctx.fill();
      ctx.restore();
    }
    const exit = game.map.paths[0][game.map.paths[0].length - 2];
    ctx.fillStyle = "rgba(16,20,27,.36)";
    ctx.fillRect(exit.x + 10, exit.y - 35, 38, 52);
    ctx.fillStyle = "rgba(218,176,112,.19)";
    ctx.fillRect(exit.x + 19, exit.y - 26, 8, 17);
    ctx.fillRect(exit.x + 32, exit.y - 26, 8, 17);
    ctx.font = "600 9px Arial"; ctx.fillStyle = "rgba(229,225,215,.48)"; ctx.fillText("ПОДЪЕЗД", exit.x + 3, exit.y + 30);
    ctx.restore();
  }

  private drawPropSpots(ctx: CanvasRenderingContext2D, game: Game) {
    for (const spot of game.map.props) {
      if (game.props.some((p) => p.spot === spot.id)) continue;
      ctx.save(); ctx.translate(spot.x, spot.y);
      const selected = game.selectedSpot === spot.id;
      ctx.strokeStyle = selected ? "rgba(226,196,143,.9)" : "rgba(205,198,181,.24)"; ctx.lineWidth = selected ? 2.5 : 1.5; ctx.setLineDash([4, 7]);
      ctx.beginPath(); ctx.ellipse(0, 0, 32, 19, 0, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = "rgba(214,207,190,.42)"; ctx.font = "15px Georgia"; ctx.textAlign = "center"; ctx.fillText("+", 0, 5);
      ctx.restore();
    }
  }

  private drawLinks(ctx: CanvasRenderingContext2D, game: Game) {
    const links = game.getLinks();
    for (const link of links) {
      const a = game.padPos(link.a), b = game.padPos(link.b);
      const active = game.selectedTower && (game.selectedTower.pad === link.a || game.selectedTower.pad === link.b);
      ctx.save();
      ctx.strokeStyle = link.color; ctx.globalAlpha = active ? 0.85 : 0.42;
      ctx.lineWidth = active ? 3 : 2; ctx.setLineDash([4, 9]); ctx.lineDashOffset = -game.time * 22;
      ctx.beginPath(); ctx.moveTo(a.x, a.y - 15);
      ctx.quadraticCurveTo((a.x + b.x) / 2, (a.y + b.y) / 2 - 42, b.x, b.y - 15); ctx.stroke();
      ctx.setLineDash([]);
      if (active) {
        ctx.font = "600 9px Arial"; ctx.textAlign = "center"; ctx.fillStyle = link.color;
        ctx.fillText(link.name, (a.x + b.x) / 2, (a.y + b.y) / 2 - 35);
      }
      ctx.restore();
    }
  }

  private drawPads(ctx: CanvasRenderingContext2D, game: Game) {
    for (const pad of game.map.pads) {
      const unlocked = game.unlockedPads.includes(pad.id);
      const selected = game.selectedPad === pad.id;
      const occupied = game.towers.some((t) => t.pad === pad.id);
      if (occupied) continue;
      ctx.save(); ctx.translate(pad.x, pad.y);
      ctx.fillStyle = "rgba(13,18,25,.38)";
      ctx.beginPath(); ctx.ellipse(0, 8, 38, 20, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = selected ? "#d9c6a0" : unlocked && game.pendingTower ? "rgba(224,192,143,.8)" : unlocked ? "rgba(206,207,199,.48)" : "rgba(128,125,127,.25)";
      ctx.lineWidth = selected ? 3 : 2; ctx.setLineDash(unlocked ? [3, 5] : [2, 7]);
      ctx.beginPath(); ctx.ellipse(0, 0, 33, 22, 0, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
      if (!unlocked) {
        ctx.fillStyle = "rgba(26,29,37,.72)"; ctx.beginPath(); ctx.ellipse(0, 0, 29, 18, 0, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = "rgba(192,183,172,.55)"; ctx.lineWidth = 2; ctx.strokeRect(-6, -7, 12, 11);
        ctx.beginPath(); ctx.arc(0, -7, 5, Math.PI, 0); ctx.stroke();
        ctx.fillStyle = game.wave >= pad.unlockWave ? "#d8b978" : "rgba(211,207,199,.55)";
        ctx.font = "600 9px Arial"; ctx.textAlign = "center";
        ctx.fillText(game.wave >= pad.unlockWave ? `${pad.unlockCost}` : `ВОЛНА ${pad.unlockWave}`, 0, 38);
      } else {
        ctx.fillStyle = selected ? "#e0cba5" : "rgba(218,215,204,.58)";
        ctx.font = "22px Georgia"; ctx.textAlign = "center"; ctx.fillText("+", 0, 7);
      }
      ctx.restore();
    }
  }

  private drawTower(ctx: CanvasRenderingContext2D, game: Game, tower: Tower) {
    const def = TOWERS[tower.type];
    const p = game.padPos(tower.pad);
    const selected = game.selectedTowerUid === tower.uid;
    ctx.save(); ctx.translate(p.x, p.y);
    ctx.fillStyle = "rgba(8,12,17,.48)"; ctx.beginPath(); ctx.ellipse(0, 4, 29, 10, 0, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = selected ? "#e8d5af" : `${def.color}99`; ctx.lineWidth = selected ? 2.5 : 1.2;
    ctx.beginPath(); ctx.ellipse(0, 1, 29, 11, 0, 0, Math.PI * 2); ctx.stroke();
    ctx.save();
    ctx.scale(0.98 * this.unitScale, 0.98 * this.unitScale);
    if (tower.type === "cat") this.actors.drawCat(ctx, game.time, tower.uid, tower.recoil);
    else this.actors.drawHuman(ctx, tower.type, game.time, tower.uid * 0.7, false, tower.recoil, 0, {
      anticipation: tower.cooldown > 0 && tower.cooldown < .17 && tower.disabledUntil <= game.time
        ? 1 - tower.cooldown / .17 : 0,
    });
    ctx.restore();
    if (tower.disabledUntil > game.time) {
      ctx.fillStyle = "rgba(113,36,42,.6)"; ctx.beginPath(); ctx.arc(0, -92, 10, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = "#e59a91"; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-5, -97); ctx.lineTo(5, -87); ctx.moveTo(5, -97); ctx.lineTo(-5, -87); ctx.stroke();
    }
    if (tower.buffUntil > game.time) {
      ctx.strokeStyle = "rgba(231,190,105,.65)"; ctx.lineWidth = 1.5; ctx.setLineDash([2, 4]);
      ctx.beginPath(); ctx.ellipse(0, 1, 34 + Math.sin(game.time * 6) * 2, 14, 0, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
    }
    for (let i = 0; i < 4; i++) {
      ctx.fillStyle = i < tower.level ? (i === 3 ? "#e9c979" : def.color) : "rgba(190,190,190,.2)";
      ctx.fillRect(-14 + i * 8, 13, 6, 2.5);
    }
    ctx.restore();
  }

  private drawEnemy(ctx: CanvasRenderingContext2D, game: Game, e: Enemy) {
    if (e.dead) return;
    const def = ENEMIES[e.type];
    const p = game.enemyPos(e);
    const scale = def.scale * this.unitScale;
    if (e.telegraph > 0 && e.type === "boss") {
      const radius = e.telegraphKind === "slam" ? 220 : 145;
      const pulse = 0.12 + Math.sin(game.time * 14) * 0.05;
      ctx.save(); ctx.translate(p.x, p.y);
      ctx.fillStyle = `rgba(185,65,71,${pulse})`; ctx.strokeStyle = "rgba(236,117,112,.85)"; ctx.lineWidth = 3 / scale;
      ctx.setLineDash([12, 8]); ctx.beginPath(); ctx.arc(0, 0, radius, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = "#f2c2b6"; ctx.font = "700 14px Arial"; ctx.textAlign = "center";
      ctx.fillText(e.telegraphKind === "slam" ? "УДАР КЛЮЧАМИ" : e.telegraphKind === "summon" ? "ПРИЗЫВ" : "ЯРОСТЬ", 0, -radius - 12);
      ctx.restore();
    }
    if (e.type === "loudmouth") {
      ctx.save(); ctx.translate(p.x, p.y);
      ctx.strokeStyle = "rgba(174,123,190,.23)"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(0, 0, 150 + Math.sin(game.time * 4) * 4, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
    }
    ctx.save(); ctx.translate(p.x, p.y);
    ctx.fillStyle = "rgba(7,11,16,.45)"; ctx.beginPath(); ctx.ellipse(0, 9, 17, 8, 0, 0, Math.PI * 2); ctx.fill();
    ctx.globalAlpha *= Math.min(1, e.spawnScale * 1.7);
    ctx.scale(scale, scale);
    if (def.tags.includes("flying")) {
      this.actors.drawBird(ctx, game.time, e.wobble, def.color);
    } else {
      ctx.scale(0.72, 0.72);
      const unit = enemyOutfit(e.type);
      const stride = 100 * scale * .72 * (MOTION_RIGS[unit].cadence ?? MOTION_RIGS[unit].stride);
      const phase = e.progress / Math.max(1, stride) * Math.PI * 2;
      const ahead = game.pathPoint(e.lane, e.progress + 2);
      const behind = game.pathPoint(e.lane, e.progress - 2);
      const motion = { walkWeight: e.motionBlend, travel: { x: ahead.x - behind.x, y: ahead.y - behind.y }, anticipation: e.telegraph > 0 ? .55 + .2 * Math.sin(game.time * 4) : 0 };
      if (e.type === "crowd") {
        ctx.save(); ctx.translate(-18, 3); ctx.scale(0.8, 0.8);
        this.actors.drawHuman(ctx, "skuf", game.time + .4, phase, e.walking, 0, e.flash, motion); ctx.restore();
        ctx.save(); ctx.translate(19, 3); ctx.scale(0.78, 0.78);
        this.actors.drawHuman(ctx, "skuf", game.time + .8, phase, e.walking, 0, e.flash, motion); ctx.restore();
      }
      this.actors.drawHuman(ctx, unit, game.time + e.wobble * .2, phase, e.walking && e.type !== "scooter", e.abilityRecoil, e.flash, motion);

    }
    if (e.slowUntil > game.time) { ctx.strokeStyle = "rgba(157,190,213,.75)"; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(0, 8, 20, 9, 0, 0, Math.PI * 2); ctx.stroke(); }
    if (e.stunUntil > game.time || e.heldUntil > game.time) {
      ctx.strokeStyle = "#e3ca77"; ctx.lineWidth = 2;
      for (let i = 0; i < 3; i++) { const a = game.time * 4 + i * Math.PI * 2 / 3; ctx.beginPath(); ctx.arc(Math.cos(a) * 14, -108 + Math.sin(a) * 4, 2, 0, Math.PI * 2); ctx.stroke(); }
    }
    ctx.restore();
    if (e.type !== "skuf" && e.type !== "boss") {
      ctx.save(); ctx.font = "600 8px Arial"; ctx.textAlign = "center"; ctx.fillStyle = def.color;
      ctx.fillText(def.short, p.x, p.y - 80 * scale - 10); ctx.restore();
    }
    if (e.hp < e.maxHp || e.type === "boss" || e.shield > 0) {
      const width = e.type === "boss" ? 100 : 38;
      const y = p.y - (def.tags.includes("flying") ? 42 : 84) * scale;
      ctx.fillStyle = "rgba(12,15,20,.75)"; ctx.fillRect(p.x - width / 2, y, width, 5);
      ctx.fillStyle = e.type === "boss" ? "#b85861" : "#c7b4a0"; ctx.fillRect(p.x - width / 2 + 1, y + 1, (width - 2) * Math.max(0, e.hp / e.maxHp), 3);
      if (e.maxShield > 0 && e.shield > 0) { ctx.fillStyle = "#7da6c2"; ctx.fillRect(p.x - width / 2, y - 4, width * (e.shield / e.maxShield), 2); }
    }
  }

  private drawFadingActor(ctx: CanvasRenderingContext2D, game: Game, actor: Game["fadingActors"][number]) {
    const def = ENEMIES[actor.type];
    const progress = 1 - actor.life / actor.maxLife;
    ctx.save(); ctx.translate(actor.x, actor.y); ctx.globalAlpha = 1 - progress;
    ctx.rotate(progress * 0.9); ctx.scale(def.scale * 0.72 * this.unitScale, def.scale * 0.72 * this.unitScale);
    if (def.tags.includes("flying")) this.actors.drawBird(ctx, game.time, actor.phase, def.color);
    else this.actors.drawHuman(ctx, enemyOutfit(actor.type), game.time, actor.phase, false, 0);
    ctx.restore();
  }

  private drawProps(ctx: CanvasRenderingContext2D, game: Game) {
    for (const prop of game.props) {
      const p = game.map.props[prop.spot];
      const selected = game.selectedPropUid === prop.uid;
      ctx.save(); ctx.translate(p.x, p.y);
      if (selected) { ctx.strokeStyle = "#e2cda6"; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(0, 4, 42, 25, 0, 0, Math.PI * 2); ctx.stroke(); }
      ctx.fillStyle = "rgba(10,14,19,.45)"; ctx.beginPath(); ctx.ellipse(0, 11, 30, 10, 0, 0, Math.PI * 2); ctx.fill();
      if (prop.type === "sofa") {
        ctx.fillStyle = "#625861"; ctx.fillRect(-29, -11, 58, 23); ctx.fillStyle = "#796b72"; ctx.fillRect(-25, -19, 50, 15); ctx.fillRect(-32, -14, 8, 24); ctx.fillRect(24, -14, 8, 24);
        ctx.strokeStyle = "#a18c8d"; ctx.beginPath(); ctx.moveTo(0, -18); ctx.lineTo(0, 8); ctx.stroke();
      } else if (prop.type === "clothesline") {
        ctx.strokeStyle = "#48454a"; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(-30, 12); ctx.lineTo(-30, -42); ctx.moveTo(30, 12); ctx.lineTo(30, -42); ctx.stroke();
        ctx.strokeStyle = "#a9a3a0"; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(-30, -38); ctx.quadraticCurveTo(0, -28, 30, -38); ctx.stroke();
        const colors = ["#7c8490", "#8d6f77", "#b1a58e"]; for (let i = 0; i < 3; i++) { ctx.fillStyle = colors[i]; ctx.fillRect(-20 + i * 17, -35 + Math.abs(i - 1) * 3, 13, 22); }
      } else if (prop.type === "dumpster") {
        ctx.fillStyle = "#455d5b"; ctx.fillRect(-25, -24, 50, 34); ctx.fillStyle = "#5e7470"; ctx.beginPath(); ctx.moveTo(-29, -24); ctx.lineTo(25, -29); ctx.lineTo(29, -20); ctx.lineTo(-25, -16); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = "#82918a"; ctx.strokeRect(-25, -24, 50, 34);
      } else {
        ctx.fillStyle = "#4d515d"; ctx.beginPath(); ctx.roundRect(-34, -18, 68, 30, 9); ctx.fill(); ctx.fillStyle = "#68707c"; ctx.fillRect(-17, -29, 36, 16);
        ctx.fillStyle = prop.cooldown > 10.8 ? "#d86262" : "#a68c67"; ctx.fillRect(-30, -7, 6, 5); ctx.fillRect(24, -7, 6, 5);
      }
      if (prop.hp < prop.maxHp) { ctx.fillStyle = "#20242b"; ctx.fillRect(-25, 22, 50, 4); ctx.fillStyle = "#b49b84"; ctx.fillRect(-25, 22, 50 * prop.hp / prop.maxHp, 4); }
      ctx.restore();
    }
  }

  private drawHero(ctx: CanvasRenderingContext2D, game: Game) {
    const p = game.map.hero;
    ctx.save(); ctx.translate(p.x, p.y);
    const glow = ctx.createRadialGradient(0, -48, 5, 0, -48, 78);
    glow.addColorStop(0, "rgba(198,145,164,.18)"); glow.addColorStop(1, "rgba(198,145,164,0)");
    ctx.fillStyle = glow; ctx.fillRect(-85, -140, 170, 170);
    ctx.fillStyle = "rgba(8,12,18,.5)"; ctx.beginPath(); ctx.ellipse(0, 4, 35, 14, 0, 0, Math.PI * 2); ctx.fill();
    ctx.save(); ctx.scale(this.unitScale, this.unitScale);
    this.actors.drawHero(ctx, game.time, game.heroRecoil, game.heroCooldown > 0 && game.heroCooldown < .15 ? 1 - game.heroCooldown / .15 : 0);
    ctx.restore();
    ctx.fillStyle = "#dbc4cb"; ctx.font = "600 9px Georgia"; ctx.textAlign = "center"; ctx.fillText("АЛТУШКА", 0, 22);
    ctx.restore();
  }

  private drawProjectiles(ctx: CanvasRenderingContext2D, game: Game) {
    ctx.lineCap = "round";
    for (const p of game.projectiles) {
      const dx = p.to.x - p.from.x, dy = p.to.y - p.from.y, d = Math.hypot(dx, dy) || 1;
      ctx.strokeStyle = p.color; ctx.globalAlpha = 0.45; ctx.lineWidth = p.type === "heavy" ? 4 : 2;
      ctx.beginPath(); ctx.moveTo(p.from.x, p.from.y); ctx.lineTo(p.from.x - dx / d * 18, p.from.y - dy / d * 18); ctx.stroke();
      ctx.globalAlpha = 1; ctx.fillStyle = "#f0e5ce"; ctx.beginPath(); ctx.arc(p.from.x, p.from.y, p.type === "heavy" ? 4 : 2.5, 0, Math.PI * 2); ctx.fill();
    }
  }

  private drawEffects(ctx: CanvasRenderingContext2D, game: Game) {
    for (const effect of game.effects) {
      const alpha = Math.min(1, effect.life * 2);
      ctx.save(); ctx.globalAlpha = alpha;
      if (effect.kind === "bucket") {
        ctx.fillStyle = "rgba(132,174,193,.16)"; ctx.beginPath(); ctx.arc(effect.x, effect.y, effect.radius, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = "#a5c5d2"; ctx.lineWidth = 3; for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; ctx.beginPath(); ctx.moveTo(effect.x + Math.cos(a) * 20, effect.y + Math.sin(a) * 20); ctx.lineTo(effect.x + Math.cos(a) * effect.radius, effect.y + Math.sin(a) * effect.radius); ctx.stroke(); }
      } else if (effect.kind === "chord") {
        ctx.strokeStyle = "#c8a3d3"; ctx.lineWidth = 5;
        for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.arc(effect.x, effect.y, effect.radius * (0.35 + i * 0.28), 0, Math.PI * 2); ctx.stroke(); }
      } else {
        ctx.fillStyle = "rgba(212,190,108,.08)"; ctx.beginPath(); ctx.arc(effect.x, effect.y, effect.radius, 0, Math.PI * 2); ctx.fill();
        ctx.save(); ctx.translate(effect.x, effect.y); this.actors.drawCat(ctx, game.time, 0, 0.4); ctx.restore();
      }
      ctx.restore();
    }
  }

  private drawParticles(ctx: CanvasRenderingContext2D, game: Game) {
    for (const p of game.particles) {
      const alpha = Math.max(0, p.life / p.maxLife);
      ctx.save(); ctx.globalAlpha = Math.min(1, alpha * 1.5);
      if (p.kind === "ring") {
        const progress = 1 - alpha;
        ctx.strokeStyle = p.color; ctx.lineWidth = p.size * alpha;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.vx * progress, 0, Math.PI * 2); ctx.stroke();
      } else if (p.kind === "text" || p.kind === "coin") {
        ctx.font = p.kind === "coin" ? "700 13px Arial" : "700 12px Arial"; ctx.textAlign = "center";
        ctx.lineWidth = 3; ctx.strokeStyle = "rgba(17,19,25,.75)"; ctx.strokeText(p.text ?? "", p.x, p.y);
        ctx.fillStyle = p.color; ctx.fillText(p.text ?? "", p.x, p.y);
      } else {
        ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(p.x, p.y, p.size * alpha, 0, Math.PI * 2); ctx.fill();
      }
      ctx.restore();
    }
  }

  private drawLeaves(ctx: CanvasRenderingContext2D, game: Game) {
    ctx.fillStyle = "rgba(126,57,66,.48)";
    for (const leaf of this.leaves) {
      const x = (leaf.x + game.time * leaf.drift) % (LOGICAL_WIDTH + 40) - 20;
      const y = (leaf.y + game.time * leaf.speed) % (LOGICAL_HEIGHT + 30) - 15;
      ctx.save(); ctx.translate(x, y); ctx.rotate(game.time + leaf.phase);
      ctx.beginPath(); ctx.moveTo(0, -leaf.size * 2); ctx.lineTo(leaf.size, 0); ctx.lineTo(0, leaf.size * 2); ctx.lineTo(-leaf.size, 0); ctx.closePath(); ctx.fill(); ctx.restore();
    }
  }

  private drawTargeting(ctx: CanvasRenderingContext2D, game: Game, pointer: Vec) {
    const kind = game.targeting!;
    const radius = kind === "bucket" ? 105 : kind === "chord" ? 150 : 115;
    const color = kind === "bucket" ? "#a5c5d2" : kind === "chord" ? "#c8a3d3" : "#dbc674";
    ctx.fillStyle = `${color}18`; ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.setLineDash([8, 6]);
    ctx.beginPath(); ctx.arc(pointer.x, pointer.y, radius, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle = color; ctx.font = "600 11px Arial"; ctx.textAlign = "center"; ctx.fillText("НАЖМИ, ЧТОБЫ ПРИМЕНИТЬ · ESC ОТМЕНА", pointer.x, pointer.y - radius - 12);
  }

  private drawVignette(ctx: CanvasRenderingContext2D) {
    const vignette = ctx.createRadialGradient(600, 350, 240, 600, 350, 760);
    vignette.addColorStop(0, "rgba(5,8,14,0)"); vignette.addColorStop(1, "rgba(5,8,14,.48)");
    ctx.fillStyle = vignette; ctx.fillRect(0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);
  }
}

export const PROP_NAMES = Object.fromEntries(Object.entries(PROP_DATA).map(([id, data]) => [id, data.name]));
