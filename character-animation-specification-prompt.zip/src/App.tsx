import { useMemo, useState } from 'react';
import Viewport, { Hud, Overlays } from './components/Viewport';
import CurveChart from './components/CurveChart';
import SpecPanel from './components/SpecPanel';
import { AnimId, DURATION, PHASES, sampleAnimation } from './lib/rig';
import { SPECS } from './lib/specs';
import { cn } from './utils/cn';

const ANIMS: { id: AnimId; label: string; sub: string }[] = [
  { id: 'idle', label: 'Idle', sub: 'weight shift + breath' },
  { id: 'walk', label: 'Walk', sub: 'inverted pendulum' },
  { id: 'run', label: 'Run', sub: 'spring-mass + flight' },
  { id: 'jump', label: 'Jump', sub: 'crouch · launch · land' },
];

const EMPTY_HUD: Hud = {
  progress: 0,
  time: 0,
  phase: '—',
  phaseColor: '#38bdf8',
  rootSpeed: 0,
  contact: [true, true],
  comOffsetCm: 0,
  supportKind: 'inside',
  boneDev: 0,
  slip: 0,
  stanceClamps: 0,
  chainRes: 0,
  comY: 0,
  hipY: 0,
};

function Toggle({ on, onClick, children }: { on: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'rounded-full border px-3 py-1 text-xs font-medium transition',
        on ? 'border-sky-400/60 bg-sky-400/15 text-sky-200' : 'border-slate-700 text-slate-400 hover:text-slate-200',
      )}
    >
      {children}
    </button>
  );
}

function Stat({
  label,
  value,
  sub,
  tone = 'ok',
}: {
  label: string;
  value: string;
  sub?: string;
  tone?: 'ok' | 'warn' | 'info';
}) {
  const color = tone === 'ok' ? 'text-emerald-300' : tone === 'warn' ? 'text-amber-300' : 'text-sky-300';
  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-3.5">
      <div className="text-[11px] uppercase tracking-wider text-slate-500">{label}</div>
      <div className={cn('mt-1 font-mono text-lg font-semibold', color)}>{value}</div>
      {sub && <div className="mt-0.5 text-xs text-slate-500">{sub}</div>}
    </div>
  );
}

const samples: Partial<Record<AnimId, ReturnType<typeof sampleAnimation>>> = {};
const getSample = (a: AnimId) => (samples[a] ??= sampleAnimation(a));

export default function App() {
  const [anim, setAnim] = useState<AnimId>('walk');
  const [playing, setPlaying] = useState(true);
  const [speed, setSpeed] = useState(1);
  const [seek, setSeek] = useState({ f: 0, n: 0 });
  const [hud, setHud] = useState<Hud>(EMPTY_HUD);
  const [chartKey, setChartKey] = useState('hipY');
  const [ov, setOv] = useState<Overlays>({ com: true, support: true, secondary: true, trails: false, labels: false });

  const sampled = useMemo(() => getSample(anim), [anim]);
  const spec = SPECS[anim];
  const series = sampled.series.find((s) => s.key === chartKey) ?? sampled.series[0];
  const phases = PHASES[anim];
  const T = DURATION[anim];

  const toggle = (k: keyof Overlays) => setOv((o) => ({ ...o, [k]: !o[k] }));
  const changeAnim = (a: AnimId) => {
    setAnim(a);
    setSeek((s) => ({ f: 0, n: s.n + 1 }));
    setHud({ ...EMPTY_HUD });
  };

  const comTone = hud.supportKind === 'outside' ? 'warn' : 'info';
  const comText =
    hud.supportKind === 'airborne'
      ? 'Airborne'
      : hud.supportKind === 'inside'
        ? 'Inside base'
        : `${Math.abs(hud.comOffsetCm ?? 0).toFixed(0)} cm ${(hud.comOffsetCm ?? 0) > 0 ? 'ahead' : 'behind'}`;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200">
      <header className="border-b border-slate-800/80 bg-slate-950/80 backdrop-blur">
        <div className="mx-auto flex max-w-[1400px] flex-wrap items-center justify-between gap-4 px-5 py-4 sm:px-8">
          <div>
            <h1 className="text-lg font-semibold tracking-tight text-white sm:text-xl">
              Kinetic Rig Lab <span className="font-normal text-slate-500">· animation-layer spec studio</span>
            </h1>
            <p className="mt-0.5 text-xs text-slate-500">
              Rigid bones · physics-driven secondary motion · ground-locked contacts. Neutral rig proxy only. Character
              design is never touched.
            </p>
          </div>
          <div className="flex items-center gap-2 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1.5 text-xs text-emerald-300">
            <span className="h-2 w-2 rounded-full bg-emerald-400" />
            No-stretch mode · bone scale locked at 1.000
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1400px] space-y-6 px-5 py-6 sm:px-8">
        {/* Animation selector */}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {ANIMS.map((a) => (
            <button
              key={a.id}
              onClick={() => changeAnim(a.id)}
              className={cn(
                'rounded-xl border px-4 py-3 text-left transition',
                anim === a.id
                  ? 'border-sky-400/60 bg-sky-400/10'
                  : 'border-slate-800 bg-slate-900/50 hover:border-slate-700 hover:bg-slate-900',
              )}
            >
              <div className={cn('font-medium', anim === a.id ? 'text-white' : 'text-slate-300')}>{a.label}</div>
              <div className="text-xs text-slate-500">{a.sub}</div>
            </button>
          ))}
        </div>

        <div className="grid gap-6 xl:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)]">
          {/* Viewport column */}
          <div className="space-y-4">
            <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-3">
              <Viewport anim={anim} playing={playing} speed={speed} overlays={ov} seek={seek} onHud={setHud} />

              {/* Timeline */}
              <div className="px-1 pb-1 pt-4">
                <div className="mb-2 flex items-center justify-between text-xs">
                  <span className="flex items-center gap-2 font-medium text-slate-200">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: hud.phaseColor }} />
                    {hud.phase}
                  </span>
                  <span className="font-mono text-slate-500">
                    {hud.time.toFixed(2)} / {T.toFixed(2)} s · f{Math.round(hud.time * 30)}
                  </span>
                </div>
                <div className="relative h-8">
                  <div className="absolute inset-0 flex overflow-hidden rounded-md">
                    {phases.map((p, i) => (
                      <div
                        key={i}
                        title={p.name}
                        className="h-full border-r border-slate-950/70"
                        style={{ width: `${(p.to - p.from) * 100}%`, background: p.color, opacity: 0.28 }}
                      />
                    ))}
                  </div>
                  <div
                    className="pointer-events-none absolute top-0 h-full w-0.5 bg-amber-300 shadow-[0_0_8px_rgba(251,191,36,0.9)]"
                    style={{ left: `${hud.progress * 100}%` }}
                  />
                  <input
                    type="range"
                    min={0}
                    max={1000}
                    value={Math.round(hud.progress * 1000)}
                    onChange={(e) => setSeek((s) => ({ f: Number(e.target.value) / 1000, n: s.n + 1 }))}
                    className="absolute inset-0 h-full w-full cursor-ew-resize opacity-0"
                    aria-label="Timeline scrubber"
                  />
                </div>
                <div className="mt-1.5 flex text-[10px] text-slate-500">
                  {phases.map((p, i) => (
                    <div key={i} style={{ width: `${(p.to - p.from) * 100}%` }} className="truncate pr-1">
                      {p.name}
                    </div>
                  ))}
                </div>
              </div>

              {/* Controls */}
              <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-3 border-t border-slate-800 px-1 pt-3">
                <button
                  onClick={() => setPlaying((p) => !p)}
                  className="rounded-lg bg-sky-500 px-4 py-1.5 text-sm font-medium text-slate-950 hover:bg-sky-400"
                >
                  {playing ? 'Pause' : 'Play'}
                </button>
                <label className="flex items-center gap-2 text-xs text-slate-400">
                  Speed
                  <input
                    type="range"
                    min={0.1}
                    max={1.5}
                    step={0.05}
                    value={speed}
                    onChange={(e) => setSpeed(Number(e.target.value))}
                    className="w-28 accent-sky-400"
                  />
                  <span className="w-10 font-mono text-slate-300">{speed.toFixed(2)}×</span>
                </label>
                <div className="flex flex-wrap gap-1.5">
                  <Toggle on={ov.com} onClick={() => toggle('com')}>COM</Toggle>
                  <Toggle on={ov.support} onClick={() => toggle('support')}>Support</Toggle>
                  <Toggle on={ov.secondary} onClick={() => toggle('secondary')}>Secondary chains</Toggle>
                  <Toggle on={ov.trails} onClick={() => toggle('trails')}>Trails</Toggle>
                  <Toggle on={ov.labels} onClick={() => toggle('labels')}>Angles</Toggle>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-x-5 gap-y-1 px-1 text-xs text-slate-500">
              <span><span className="text-emerald-400">◯</span> locked contact</span>
              <span><span className="text-emerald-400">|</span> footprint (fixed to ground)</span>
              <span><span className="text-red-400">◌</span> IK reach clamp (never stretches)</span>
              <span><span className="text-teal-300">▬</span> support span</span>
              {(['hair', 'cloth', 'gear'] as const).map((c, i) => (
                <span key={c} style={{ color: ['#fbbf24', '#f472b6', '#2dd4bf'][i] }}>
                  ● {['light tail', 'loose fabric', 'hanging gear'][i]}
                </span>
              ))}
            </div>
          </div>

          {/* Metrics column */}
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              <Stat
                label="Bone-length error"
                value={`${hud.boneDev.toFixed(4)}%`}
                sub="max over all bones"
                tone={hud.boneDev < 0.001 ? 'ok' : 'warn'}
              />
              <Stat
                label="Contact slip"
                value={`${hud.slip.toFixed(2)} cm/s`}
                sub="peak, loaded feet"
                tone={hud.slip < 0.5 ? 'ok' : 'warn'}
              />
              <Stat
                label="Stance IK clamps"
                value={String(hud.stanceClamps)}
                sub="target beyond reach"
                tone={hud.stanceClamps === 0 ? 'ok' : 'warn'}
              />
              <Stat label="COM vs support" value={comText} sub="sagittal projection" tone={comTone} />
              <Stat
                label="Chain residual"
                value={`${hud.chainRes.toFixed(2)}%`}
                sub="segment-length error"
                tone={hud.chainRes < 6 ? 'ok' : 'warn'}
              />
              <Stat
                label="Root speed"
                value={`${hud.rootSpeed.toFixed(2)} m/s`}
                sub={`L ${hud.contact[0] ? '●' : '○'}  R ${hud.contact[1] ? '●' : '○'}  contact`}
                tone="info"
              />
            </div>

            <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                <h3 className="text-sm font-semibold text-white">Curve inspector</h3>
                <select
                  value={chartKey}
                  onChange={(e) => setChartKey(e.target.value)}
                  className="rounded-md border border-slate-700 bg-slate-900 px-2 py-1 text-xs text-slate-200 outline-none focus:border-sky-400"
                >
                  {sampled.series.map((s) => (
                    <option key={s.key} value={s.key}>
                      {s.label} ({s.unit})
                    </option>
                  ))}
                </select>
              </div>
              <CurveChart series={series} progress={hud.progress} phases={phases} duration={T} />
              <p className="mt-2 text-xs leading-relaxed text-slate-500">
                Sampled from the same solver that drives the viewport. Check{' '}
                <span className="text-slate-300">“Foot speed vs ground”</span>: it sits on zero for the whole stance.
              </p>
            </div>
          </div>
        </div>

        <SpecPanel key={anim} spec={spec} rom={sampled.rom} />

        <footer className="pb-8 pt-2 text-center text-xs text-slate-600">
          The rig is a neutral proxy for visualising the animation layer: joint rotations, root motion, IK contacts and
          physics. It carries no character design.
        </footer>
      </main>
    </div>
  );
}
