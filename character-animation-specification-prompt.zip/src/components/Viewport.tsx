import { useEffect, useRef } from 'react';
import {
  AnimId,
  DURATION,
  L,
  PHASES,
  Skel,
  V2,
  boneDeviation,
  buildSkeleton,
  computeCOM,
  computeSupport,
  contactPoint,
  evalPose,
  legAngles,
  makeChains,
  pivotSlip,
  resetChains,
  stepChains,
} from '../lib/rig';

export interface Overlays {
  com: boolean;
  support: boolean;
  secondary: boolean;
  trails: boolean;
  labels: boolean;
}
export interface Hud {
  progress: number;
  time: number;
  phase: string;
  phaseColor: string;
  rootSpeed: number;
  contact: [boolean, boolean];
  comOffsetCm: number | null;
  supportKind: 'inside' | 'outside' | 'airborne';
  boneDev: number;
  slip: number;
  stanceClamps: number;
  chainRes: number;
  comY: number;
  hipY: number;
}

interface Props {
  anim: AnimId;
  playing: boolean;
  speed: number;
  overlays: Overlays;
  seek: { f: number; n: number };
  onHud: (h: Hud) => void;
}

const SCALE: Record<AnimId, number> = { idle: 2.0, walk: 2.0, run: 2.0, jump: 2.55 };

export default function Viewport(props: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const propsRef = useRef(props);
  propsRef.current = props;

  useEffect(() => {
    const canvas = canvasRef.current!;
    const wrap = wrapRef.current!;
    const ctx = canvas.getContext('2d')!;
    let W = 800;
    let H = 480;
    const resize = () => {
      const r = wrap.getBoundingClientRect();
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      W = Math.max(300, r.width);
      H = Math.max(300, r.height);
      canvas.width = W * dpr;
      canvas.height = H * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(wrap);

    const st = {
      anim: propsRef.current.anim as AnimId,
      t: 0,
      dist: 0,
      chains: makeChains(),
      seekN: propsRef.current.seek.n,
      prevCP: [null, null] as (V2 | null)[],
      prevHT: [null, null] as ({ h: V2; t: V2; p: number } | null)[],
      prevDist: 0,
      prevContact: [false, false],
      markers: [] as number[],
      slip: 0,
      stanceClamps: 0,
      trails: { hip: [] as V2[], foot: [] as V2[], com: [] as V2[] },
      comPrev: null as V2 | null,
      comVel: [0, 0] as V2,
      lastHud: 0,
    };
    const init = (anim: AnimId) => {
      st.anim = anim;
      st.t = 0;
      st.dist = 0;
      st.markers = [];
      st.prevCP = [null, null];
      st.prevHT = [null, null];
      st.prevDist = 0;
      st.prevContact = [false, false];
      st.slip = 0;
      st.stanceClamps = 0;
      st.trails = { hip: [], foot: [], com: [] };
      st.comPrev = null;
      const sk = buildSkeleton(evalPose(anim, 0));
      resetChains(st.chains, sk, 0);
    };
    init(st.anim);

    let last = performance.now();
    let raf = 0;

    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      const P = propsRef.current;
      const dtReal = Math.min(0.05, (now - last) / 1000);
      last = now;
      if (P.anim !== st.anim) init(P.anim);
      const T = DURATION[st.anim];

      if (P.seek.n !== st.seekN) {
        st.seekN = P.seek.n;
        st.t = P.seek.f * T;
        const sk0 = buildSkeleton(evalPose(st.anim, st.t));
        resetChains(st.chains, sk0, st.dist);
        st.prevCP = [null, null];
        st.prevHT = [null, null];
        st.comPrev = null;
      }

      const dt = P.playing ? dtReal * P.speed : 0;
      let skel: Skel | null = null;
      if (dt > 0) {
        const n = Math.max(1, Math.ceil(dt / (1 / 120)));
        const h = dt / n;
        for (let k = 0; k < n; k++) {
          st.t = (st.t + h) % T;
          const pose = evalPose(st.anim, st.t);
          st.dist += pose.speed * h;
          skel = buildSkeleton(pose);
          stepChains(st.chains, skel, st.dist, h);
        }
      }
      if (!skel) skel = buildSkeleton(evalPose(st.anim, st.t));
      const pose = skel.pose;

      // ---------- measurements
      const cp: V2[] = [0, 1].map((i) => {
        const c = contactPoint(skel!, i);
        return [c[0] + st.dist, c[1]] as V2;
      });
      for (let i = 0; i < 2; i++) {
        const c = pose.feet[i].contact;
        if (c && !st.prevContact[i]) {
          st.markers.push(cp[i][0]);
          if (st.markers.length > 14) st.markers.shift();
        }
        const ph = st.prevHT[i];
        if (dt > 0 && c && st.prevContact[i] && ph) {
          const v = pivotSlip(skel, i, ph.h, ph.t, ph.p, st.dist - st.prevDist) / dt;
          st.slip = Math.max(st.slip, v);
        }
        st.prevHT[i] = {
          h: [skel.heel[i][0], skel.heel[i][1]],
          t: [skel.toe[i][0], skel.toe[i][1]],
          p: pose.feet[i].pitch,
        };
        if (c && skel.clamped[i] && dt > 0) st.stanceClamps++;
        st.prevCP[i] = cp[i];
        st.prevContact[i] = c;
      }
      st.prevDist = st.dist;
      if (dt > 0) st.slip *= Math.max(0, 1 - dtReal * 0.8);
      const com = computeCOM(skel);
      const sup = computeSupport(skel);
      if (dt > 0 && st.comPrev) {
        const a = Math.min(1, dtReal * 10);
        st.comVel = [
          st.comVel[0] + ((com[0] - st.comPrev[0]) / dt + pose.speed - st.comVel[0]) * a,
          st.comVel[1] + ((com[1] - st.comPrev[1]) / dt - st.comVel[1]) * a,
        ];
      }
      st.comPrev = com;
      if (dt > 0) {
        const push = (arr: V2[], p: V2) => {
          arr.push(p);
          if (arr.length > 110) arr.shift();
        };
        push(st.trails.hip, [skel.hip[0] + st.dist, skel.hip[1]]);
        push(st.trails.foot, [skel.ankle[0][0] + st.dist, skel.ankle[0][1]]);
      }

      // ---------- render
      const S = (H * 0.8) / SCALE[st.anim];
      const gy = H * 0.84;
      const cx = W * 0.5;
      const camX = pose.speed > 0 ? st.dist : 0;
      const X = (x: number, world = false) => cx + ((world ? x : x + st.dist) - camX) * S;
      const Y = (y: number) => gy - (y + L.ankleH) * S;
      const pt = (p: V2): [number, number] => [X(p[0]), Y(p[1])];

      const bg = ctx.createLinearGradient(0, 0, 0, H);
      bg.addColorStop(0, '#0b1220');
      bg.addColorStop(1, '#111c33');
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, W, H);

      // vertical scale guide
      ctx.strokeStyle = 'rgba(148,163,184,0.07)';
      ctx.lineWidth = 1;
      for (let m = 0.5; m < 3; m += 0.5) {
        const yy = gy - m * S;
        ctx.beginPath();
        ctx.moveTo(0, yy);
        ctx.lineTo(W, yy);
        ctx.stroke();
      }
      // ground
      ctx.fillStyle = '#0a1120';
      ctx.fillRect(0, gy, W, H - gy);
      ctx.strokeStyle = '#475569';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, gy);
      ctx.lineTo(W, gy);
      ctx.stroke();
      const x0 = camX - cx / S;
      const x1 = camX + (W - cx) / S;
      ctx.strokeStyle = '#334155';
      ctx.lineWidth = 1;
      ctx.fillStyle = '#475569';
      ctx.font = '10px ui-monospace, monospace';
      for (let k = Math.floor(x0 * 2); k <= Math.ceil(x1 * 2); k++) {
        const sx = X(k / 2, true);
        ctx.beginPath();
        ctx.moveTo(sx, gy);
        ctx.lineTo(sx, gy + (k % 2 === 0 ? 14 : 7));
        ctx.stroke();
        if (k % 2 === 0) ctx.fillText(`${k / 2} m`, sx + 3, gy + 26);
      }
      // footprint markers (they stay fixed to the ground → proof of no sliding)
      ctx.strokeStyle = '#34d399';
      ctx.lineWidth = 2;
      for (const m of st.markers) {
        const sx = X(m, true);
        if (sx < -10 || sx > W + 10) continue;
        ctx.beginPath();
        ctx.moveTo(sx, gy - 6);
        ctx.lineTo(sx, gy + 6);
        ctx.stroke();
      }
      // support span
      if (P.overlays.support && sup.grounded) {
        ctx.strokeStyle = 'rgba(45,212,191,0.95)';
        ctx.lineWidth = 6;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(X(sup.min), gy + 1);
        ctx.lineTo(X(sup.max), gy + 1);
        ctx.stroke();
      }

      const line = (a: V2, b: V2, w: number, c: string) => {
        const [ax, ay] = pt(a);
        const [bx, by] = pt(b);
        ctx.strokeStyle = c;
        ctx.lineWidth = w * S;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(ax, ay);
        ctx.lineTo(bx, by);
        ctx.stroke();
      };
      const dot = (p: V2, r: number, fill: string, stroke?: string) => {
        const [x, y] = pt(p);
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fillStyle = fill;
        ctx.fill();
        if (stroke) {
          ctx.strokeStyle = stroke;
          ctx.lineWidth = 1.5;
          ctx.stroke();
        }
      };
      const foot = (i: number, color: string) => {
        const a = pt(skel!.ankle[i]);
        const h = pt(skel!.heel[i]);
        const t = pt(skel!.toe[i]);
        ctx.beginPath();
        ctx.moveTo(a[0], a[1]);
        ctx.lineTo(h[0], h[1]);
        ctx.lineTo(t[0], t[1]);
        ctx.closePath();
        ctx.fillStyle = color;
        ctx.strokeStyle = color;
        ctx.lineWidth = 0.03 * S;
        ctx.lineJoin = 'round';
        ctx.fill();
        ctx.stroke();
      };
      const leg = (i: number, bone: string, joint: string) => {
        line(skel!.hip, skel!.knee[i], 0.065, bone);
        line(skel!.knee[i], skel!.ankle[i], 0.05, bone);
        foot(i, bone);
        dot(skel!.knee[i], 0.03 * S, joint);
        dot(skel!.ankle[i], 0.022 * S, joint);
      };
      const arm = (i: number, bone: string, joint: string) => {
        line(skel!.sh, skel!.elbow[i], 0.045, bone);
        line(skel!.elbow[i], skel!.wrist[i], 0.035, bone);
        dot(skel!.elbow[i], 0.02 * S, joint);
        dot(skel!.wrist[i], 0.022 * S, bone);
      };

      // trails
      if (P.overlays.trails) {
        const drawTrail = (arr: V2[], c: string) => {
          ctx.strokeStyle = c;
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          arr.forEach((p, i) => {
            const x = X(p[0], true);
            const y = Y(p[1]);
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          });
          ctx.stroke();
        };
        drawTrail(st.trails.hip, 'rgba(56,189,248,0.55)');
        drawTrail(st.trails.foot, 'rgba(251,191,36,0.55)');
      }

      // far side
      arm(1, '#475569', '#64748b');
      leg(1, '#64748b', '#94a3b8');

      // secondary chains
      if (P.overlays.secondary) {
        for (const c of st.chains) {
          ctx.strokeStyle = c.color;
          ctx.lineWidth = c.width * S;
          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';
          ctx.globalAlpha = 0.9;
          ctx.beginPath();
          c.pts.forEach((p, i) => {
            const x = X(p.x, true);
            const y = Y(p.y);
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          });
          ctx.stroke();
          ctx.globalAlpha = 1;
          c.pts.forEach((p, i) => {
            if (i === 0) return;
            ctx.beginPath();
            ctx.arc(X(p.x, true), Y(p.y), 2.2, 0, Math.PI * 2);
            ctx.fillStyle = '#0b1220';
            ctx.fill();
          });
        }
      }

      // torso, neck, head
      line(skel.hip, skel.l1, 0.085, '#cbd5e1');
      line(skel.l1, skel.sh, 0.1, '#e2e8f0');
      line(skel.sh, skel.neck, 0.04, '#e2e8f0');
      {
        const [hx, hy] = pt(skel.head);
        ctx.beginPath();
        ctx.arc(hx, hy, L.headR * S, 0, Math.PI * 2);
        ctx.fillStyle = '#e2e8f0';
        ctx.fill();
        // gaze indicator
        const f: V2 = [Math.cos((pose.head * Math.PI) / 180), -Math.sin((pose.head * Math.PI) / 180)];
        ctx.strokeStyle = '#0f172a';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(hx, hy);
        ctx.lineTo(hx + f[0] * L.headR * S * 0.8, hy - f[1] * L.headR * S * 0.8);
        ctx.stroke();
      }
      dot(skel.hip, 0.035 * S, '#38bdf8', '#0b1220');
      dot(skel.sh, 0.03 * S, '#38bdf8', '#0b1220');

      // near side
      leg(0, '#f1f5f9', '#38bdf8');
      arm(0, '#e2e8f0', '#38bdf8');

      // contact rings & clamp warnings
      for (let i = 0; i < 2; i++) {
        if (pose.feet[i].contact) {
          const [x, y] = pt(contactPoint(skel, i));
          ctx.beginPath();
          ctx.arc(x, y, 7, 0, Math.PI * 2);
          ctx.strokeStyle = '#34d399';
          ctx.lineWidth = 2;
          ctx.stroke();
        }
        if (skel.clamped[i]) {
          const [x, y] = pt(skel.ankle[i]);
          ctx.beginPath();
          ctx.arc(x, y, 9, 0, Math.PI * 2);
          ctx.strokeStyle = '#f87171';
          ctx.setLineDash([3, 3]);
          ctx.lineWidth = 1.5;
          ctx.stroke();
          ctx.setLineDash([]);
        }
      }

      // COM
      if (P.overlays.com) {
        const [x, y] = pt(com);
        ctx.setLineDash([4, 4]);
        ctx.strokeStyle = 'rgba(251,191,36,0.7)';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x, gy);
        ctx.stroke();
        ctx.setLineDash([]);
        // COM velocity vector in the ground frame (1 m/s = 0.15 m on screen)
        const ax = x + st.comVel[0] * 0.15 * S;
        const ay = y - st.comVel[1] * 0.15 * S;
        ctx.strokeStyle = '#fb923c';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(ax, ay);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(x, y, 8, 0, Math.PI * 2);
        ctx.fillStyle = '#fff';
        ctx.fill();
        ctx.strokeStyle = '#0b1220';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.fillStyle = '#0b1220';
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.arc(x, y, 8, 0, Math.PI / 2);
        ctx.closePath();
        ctx.moveTo(x, y);
        ctx.arc(x, y, 8, Math.PI, Math.PI * 1.5);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#fbbf24';
        ctx.font = '10px ui-monospace, monospace';
        ctx.fillText('COM', x + 12, y - 8);
      }

      // joint labels
      if (P.overlays.labels) {
        ctx.font = '11px ui-monospace, monospace';
        for (let i = 0; i < 2; i++) {
          const a = legAngles(skel, i);
          const [kx, ky] = pt(skel.knee[i]);
          ctx.fillStyle = i === 0 ? '#7dd3fc' : '#94a3b8';
          ctx.fillText(`knee ${a.knee.toFixed(0)}°`, kx + 12, ky + 4);
        }
        const a0 = legAngles(skel, 0);
        const [hx, hy] = pt(skel.hip);
        ctx.fillStyle = '#7dd3fc';
        ctx.fillText(`hip ${a0.hip.toFixed(0)}°`, hx - 62, hy + 4);
        const [lx, ly] = pt(skel.l1);
        ctx.fillText(`trunk ${pose.lumbar.toFixed(1)}°`, lx - 78, ly);
      }

      // ---------- HUD (throttled)
      if (now - st.lastHud > 70) {
        st.lastHud = now;
        const prog = (st.t % T) / T;
        const ph = PHASES[st.anim].find((p) => prog >= p.from && prog < p.to) ?? PHASES[st.anim][0];
        let off: number | null = null;
        let kind: Hud['supportKind'] = 'airborne';
        if (sup.grounded) {
          if (com[0] >= sup.min && com[0] <= sup.max) {
            off = 0;
            kind = 'inside';
          } else {
            off = (com[0] < sup.min ? com[0] - sup.min : com[0] - sup.max) * 100;
            kind = 'outside';
          }
        }
        let res = 0;
        for (const c of st.chains) res = Math.max(res, c.residual);
        P.onHud({
          progress: prog,
          time: st.t,
          phase: ph.name,
          phaseColor: ph.color,
          rootSpeed: pose.speed,
          contact: [pose.feet[0].contact, pose.feet[1].contact],
          comOffsetCm: off,
          supportKind: kind,
          boneDev: boneDeviation(skel),
          slip: st.slip * 100,
          stanceClamps: st.stanceClamps,
          chainRes: res,
          comY: com[1],
          hipY: skel.hip[1],
        });
      }
    };
    raf = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, []);

  return (
    <div ref={wrapRef} className="relative h-[440px] w-full overflow-hidden rounded-xl sm:h-[500px]">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />
    </div>
  );
}
