import { PhaseDef, Series } from '../lib/rig';

interface Props {
  series: Series;
  progress: number;
  phases: PhaseDef[];
  duration: number;
}

export default function CurveChart({ series, progress, phases, duration }: Props) {
  const W = 600;
  const H = 190;
  const pad = { l: 44, r: 12, t: 12, b: 24 };
  const v = series.values;
  let min = Math.min(...v);
  let max = Math.max(...v);
  if (max - min < 1e-6) {
    max += 1;
    min -= 1;
  }
  const span = max - min;
  min -= span * 0.08;
  max += span * 0.08;
  const iw = W - pad.l - pad.r;
  const ih = H - pad.t - pad.b;
  const X = (f: number) => pad.l + f * iw;
  const Y = (val: number) => pad.t + (1 - (val - min) / (max - min)) * ih;
  const path = v.map((val, i) => `${i === 0 ? 'M' : 'L'}${X(i / v.length).toFixed(1)},${Y(val).toFixed(1)}`).join(' ');
  const cur = v[Math.min(v.length - 1, Math.floor(progress * v.length))];
  const ticks = 4;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label={series.label}>
      {phases.map((p, i) => (
        <rect
          key={i}
          x={X(p.from)}
          y={pad.t}
          width={(p.to - p.from) * iw}
          height={ih}
          fill={p.color}
          opacity={i % 2 === 0 ? 0.1 : 0.05}
        />
      ))}
      {Array.from({ length: ticks + 1 }).map((_, i) => {
        const val = min + ((max - min) * i) / ticks;
        return (
          <g key={i}>
            <line x1={pad.l} x2={W - pad.r} y1={Y(val)} y2={Y(val)} stroke="#1e293b" />
            <text x={pad.l - 6} y={Y(val) + 3} textAnchor="end" fontSize="10" fill="#64748b" fontFamily="ui-monospace,monospace">
              {Math.abs(val) >= 10 ? val.toFixed(0) : val.toFixed(2)}
            </text>
          </g>
        );
      })}
      {min < 0 && max > 0 && <line x1={pad.l} x2={W - pad.r} y1={Y(0)} y2={Y(0)} stroke="#475569" strokeDasharray="3 3" />}
      {[0, 0.25, 0.5, 0.75, 1].map((f) => (
        <text key={f} x={X(f)} y={H - 6} textAnchor="middle" fontSize="10" fill="#64748b" fontFamily="ui-monospace,monospace">
          {(f * duration).toFixed(2)}s
        </text>
      ))}
      <path d={path} fill="none" stroke="#38bdf8" strokeWidth="2" strokeLinejoin="round" />
      <line x1={X(progress)} x2={X(progress)} y1={pad.t} y2={pad.t + ih} stroke="#fbbf24" strokeWidth="1.5" />
      <circle cx={X(progress)} cy={Y(cur)} r="4.5" fill="#fbbf24" stroke="#0b1220" strokeWidth="1.5" />
    </svg>
  );
}
