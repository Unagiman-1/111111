import { useState } from 'react';
import { GLOBAL_RULES, Spec, toMarkdown } from '../lib/specs';
import { cn } from '../utils/cn';

const TABS = [
  { id: 'phases', label: 'Phase breakdown' },
  { id: 'weight', label: 'Weight & balance' },
  { id: 'secondary', label: 'Secondary motion' },
  { id: 'antic', label: 'Anticipation / follow-through' },
  { id: 'chain', label: 'Kinetic chain' },
  { id: 'qc', label: 'Contacts & QC' },
] as const;
type TabId = (typeof TABS)[number]['id'];

function Bullets({ items }: { items: string[] }) {
  return (
    <ul className="space-y-3">
      {items.map((t, i) => (
        <li key={i} className="flex gap-3 text-sm leading-relaxed text-slate-300">
          <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-sky-400" />
          <span>{t}</span>
        </li>
      ))}
    </ul>
  );
}

export default function SpecPanel({ spec, rom }: { spec: Spec; rom: { joint: string; min: number; max: number }[] }) {
  const [tab, setTab] = useState<TabId>('phases');
  const [copied, setCopied] = useState(false);

  const md = () => toMarkdown(spec, rom);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(md());
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch {
      download();
    }
  };
  const download = () => {
    const blob = new Blob([md()], { type: 'text/markdown' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${spec.id}-animation-spec.md`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <section className="rounded-2xl border border-slate-800 bg-slate-900/60">
      <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-800 p-5 sm:p-6">
        <div className="max-w-3xl">
          <h2 className="text-xl font-semibold text-white">{spec.title}</h2>
          <p className="mt-2 text-sm leading-relaxed text-slate-400">{spec.summary}</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={copy}
            className="rounded-lg bg-sky-500 px-3.5 py-2 text-sm font-medium text-slate-950 transition hover:bg-sky-400"
          >
            {copied ? 'Copied ✓' : 'Copy spec (Markdown)'}
          </button>
          <button
            onClick={download}
            className="rounded-lg border border-slate-700 px-3.5 py-2 text-sm font-medium text-slate-200 transition hover:bg-slate-800"
          >
            Download .md
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-px bg-slate-800 sm:grid-cols-3 lg:grid-cols-6">
        {spec.stats.map(([k, v]) => (
          <div key={k} className="bg-slate-900 px-4 py-3">
            <div className="text-[11px] uppercase tracking-wider text-slate-500">{k}</div>
            <div className="mt-0.5 font-mono text-sm text-slate-100">{v}</div>
          </div>
        ))}
      </div>

      <div className="flex gap-1 overflow-x-auto border-b border-slate-800 px-3 pt-3">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={cn(
              'shrink-0 rounded-t-lg px-3.5 py-2 text-sm font-medium transition',
              tab === t.id ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200',
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="p-5 sm:p-6">
        {tab === 'phases' && (
          <div className="space-y-6">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[820px] text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-800 text-[11px] uppercase tracking-wider text-slate-500">
                    <th className="py-2 pr-4 font-medium">Phase</th>
                    <th className="py-2 pr-4 font-medium">Frames @30</th>
                    <th className="py-2 pr-4 font-medium">Root / COM</th>
                    <th className="py-2 pr-4 font-medium">Joint rotations</th>
                    <th className="py-2 font-medium">Velocity curve</th>
                  </tr>
                </thead>
                <tbody className="align-top">
                  {spec.phases.map((p) => (
                    <tr key={p.name} className="border-b border-slate-800/70">
                      <td className="py-3 pr-4 font-medium text-white">{p.name}</td>
                      <td className="py-3 pr-4 font-mono text-xs text-sky-300">{p.frames}</td>
                      <td className="py-3 pr-4 text-slate-300">{p.root}</td>
                      <td className="py-3 pr-4 text-slate-300">{p.joints}</td>
                      <td className="py-3 text-slate-400">{p.curve}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div>
              <h3 className="mb-3 text-sm font-semibold text-white">
                Measured range of motion <span className="font-normal text-slate-500">(sampled from the live solver)</span>
              </h3>
              <div className="grid gap-px overflow-hidden rounded-lg bg-slate-800 sm:grid-cols-2 lg:grid-cols-3">
                {rom.map((r) => (
                  <div key={r.joint} className="flex items-center justify-between gap-3 bg-slate-900 px-4 py-2.5">
                    <span className="text-sm text-slate-400">{r.joint}</span>
                    <span className="font-mono text-sm text-slate-100">
                      {r.min.toFixed(0)}° … {r.max.toFixed(0)}°
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
        {tab === 'weight' && <Bullets items={spec.weight} />}
        {tab === 'secondary' && <Bullets items={spec.secondary} />}
        {tab === 'antic' && <Bullets items={spec.antic} />}
        {tab === 'chain' && (
          <ol className="relative space-y-4 border-l border-slate-700 pl-6">
            {spec.chain.map((c, i) => (
              <li key={i} className="relative">
                <span className="absolute -left-[31px] top-1 flex h-4 w-4 items-center justify-center rounded-full border border-sky-400 bg-slate-900 text-[9px] text-sky-300">
                  {i + 1}
                </span>
                <div className="flex flex-wrap items-baseline gap-x-3">
                  <span className="font-medium text-white">{c.step}</span>
                  <span className="rounded bg-slate-800 px-2 py-0.5 font-mono text-xs text-amber-300">{c.t}</span>
                </div>
                <p className="mt-1 text-sm text-slate-400">{c.detail}</p>
              </li>
            ))}
          </ol>
        )}
        {tab === 'qc' && (
          <div className="grid gap-8 lg:grid-cols-2">
            <div>
              <h3 className="mb-3 text-sm font-semibold text-white">Contact rules for this cycle</h3>
              <Bullets items={spec.contacts} />
            </div>
            <div>
              <h3 className="mb-3 text-sm font-semibold text-white">Locked-rig rules (all cycles)</h3>
              <Bullets items={GLOBAL_RULES} />
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
