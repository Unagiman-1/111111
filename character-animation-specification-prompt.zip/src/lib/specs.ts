import type { AnimId } from './rig';

export interface PhaseRow {
  name: string;
  frames: string;
  root: string;
  joints: string;
  curve: string;
}
export interface ChainStep {
  step: string;
  t: string;
  detail: string;
}
export interface Spec {
  id: AnimId;
  title: string;
  summary: string;
  stats: [string, string][];
  phases: PhaseRow[];
  weight: string[];
  secondary: string[];
  antic: string[];
  chain: ChainStep[];
  contacts: string[];
}

export const GLOBAL_RULES: string[] = [
  'Bone lengths are constants. No scale channel exists on any joint; only rotation (FK), root translation and IK targets are keyed.',
  'Legs are solved with analytic two-bone IK. If a target is out of reach, the target is projected onto the reachable sphere (0.998 × chain length) instead of stretching the chain.',
  'Foot locks use a pivot-compensated ankle offset (heel pivot on strike, flat foot, toe pivot on push-off) so the contact point has zero ground-relative velocity while loaded.',
  'Secondary chains are simulated with fixed-length Verlet constraints, then pushed out of torso, head and thigh capsules so nothing clips into the locked mesh.',
  'All timing below is written for 30 fps (1 frame = 33.3 ms). Interpolation is never linear on rotations.',
];

export const SPECS: Record<AnimId, Spec> = {
  idle: {
    id: 'idle',
    title: 'Idle · living stance',
    summary:
      'A continuous standing loop made from two overlapping oscillations: a slow 5 s weight shift between feet and a 2.5 s breathing wave that travels up the spine. Both feet stay locked to the ground; all life comes from the root, spine and secondary layers.',
    stats: [
      ['Loop length', '5.00 s · 150 f'],
      ['Weight shift', '1 cycle / 5 s'],
      ['Breath', '2 cycles / 5 s'],
      ['Foot contacts', 'both locked'],
      ['Root height', '0.912 – 0.918 m'],
      ['Root travel', '0 m/s'],
    ],
    phases: [
      {
        name: 'Load → forward foot',
        frames: 'f0 – f75',
        root: 'Root slides +2.5 cm toward the forward foot on a sine ease; vertical bob ±3 mm at breath rate.',
        joints:
          'Rear foot heel lifts to −6° plantar (toe pivot). Lumbar +0.5°, thorax +0.5°, head counter-rotates −0.4°. Knee of the unloaded leg gains ≈ 3° flexion.',
        curve: 'Sine in/out: velocity peaks at f37 and f112, zero at turn-arounds.',
      },
      {
        name: 'Load → rear foot',
        frames: 'f75 – f150',
        root: 'Root returns −2.5 cm; the weight hand-off completes before the heel drops.',
        joints: 'Forward foot heel lifts to −6° as the rear foot takes load; shoulders sway 4° with a 4-frame lag.',
        curve: 'Mirror of phase 1. The unloading foot is released only after load has transferred.',
      },
    ],
    weight: [
      'The root (pelvis) leads: it moves first, the spine and head follow. The centre of mass projection always remains inside the support span between the heel of the rear foot and the toe of the forward foot.',
      'Heel lift on the unloaded foot is driven by the weight-shift value, never by an independent oscillator, so foot pressure and COM always agree.',
      'Vertical root motion is limited to ±3 mm; any larger value would read as a bounce rather than breathing.',
    ],
    secondary: [
      'Light tail chain (7 nodes, 5 cm segments) hangs from the back of the head and responds to the 1° head counter-rotation with 2–3 frames of delay.',
      'Loose-fabric chain (8 nodes, 7 cm) sways with thorax pitch. Peak lateral displacement stays under 4 cm.',
      'Hanging gear chain (4 nodes) acts as a damped pendulum at ≈ 1.2 Hz, excited by the weight shift. It decays within 1.5 cycles.',
      'All chains are pushed out of the torso, head and thigh capsules, so nothing intersects the locked mesh.',
    ],
    antic: [
      'Every weight shift begins with a 2-frame pelvis pre-move (≈ 3 mm opposite to the travel direction) before the main slide.',
      'Settle: at each end of the shift, a 10 % overshoot is absorbed by the knee of the loaded leg over 6–8 frames. No hard stop.',
      'Arms are driven by the shift, so they trail the torso by 4 frames and hold small residual swing.',
    ],
    chain: [
      { step: '1 · Root / pelvis', t: 'f0', detail: 'Lateral/sagittal slide + 3 mm bob. This is the only driver.' },
      { step: '2 · Lumbar', t: '+0 f', detail: 'Follows pelvis; pitch = 1.5° + 0.7° breath + 0.5° shift.' },
      { step: '3 · Thorax', t: '+2 f', detail: 'Breath expansion (1.2° pitch wave) arrives 60 ms after lumbar.' },
      { step: '4 · Head', t: '+3 f', detail: 'Counter-rotates −0.8° to stabilise gaze; leaves the chain last.' },
      { step: '5 · Shoulder → elbow', t: '+4 f / +6 f', detail: 'Arms hang from inertia; elbow flexion breathes ±3° with extra lag.' },
    ],
    contacts: [
      'Both feet: 100 % contact, ground velocity 0.00 cm/s.',
      'Pitch ≤ 6° plantar; pivot-compensated, so the toe does not slide when the heel rises.',
      'QC: no IK clamp events, no bone length change, no secondary node below ground plane.',
    ],
  },

  walk: {
    id: 'walk',
    title: 'Walk · inverted-pendulum cycle',
    summary:
      'A 1.0 s symmetric walk cycle at 120 steps/min. The root vaults over each stance leg; the swing leg is launched backward before moving forward (toe-off tangent), and lands with the same velocity as the ground, so it never skids.',
    stats: [
      ['Cycle', '1.00 s · 30 f'],
      ['Root speed', '1.10 m/s'],
      ['Stance duty', '60 % (10 % double support)'],
      ['Stance travel', '0.66 m per foot'],
      ['Root height', '0.86 – 0.92 m'],
      ['Cadence', '120 steps/min'],
    ],
    phases: [
      {
        name: 'Contact / loading',
        frames: 'f0 – f4',
        root: 'Root at its lowest (≈ 0.86 m). Vertical velocity crosses zero downward→upward.',
        joints:
          'Heel strike with foot pitch +12° (toes up), leading hip ≈ 35° flexion, knee ≈ 24° flexion absorbing load. Opposite arm at max forward.',
        curve: 'Foot lands with ground-matched velocity (no skid). Knee flexion eases in over 3 f.',
      },
      {
        name: 'Mid-stance',
        frames: 'f4 – f9',
        root: 'Root rises to its apex (≈ 0.92 m) directly above the stance foot; forward lean 4° ± 1.2°.',
        joints: 'Hip ≈ 12° flexion, knee ≈ 24°, foot rolls flat. Swing leg passes under the body with knee ≈ 55°.',
        curve: 'Root vertical velocity peaks at ≈ f6.5 and returns to zero at the apex.',
      },
      {
        name: 'Terminal stance',
        frames: 'f9 – f15',
        root: 'Root descends as the body falls forward onto the front foot.',
        joints: 'Hip extends toward ≈ 9° flexion, heel rises, foot pitch 0 → −20°. Trunk pitches forward 1–2°.',
        curve: 'Ease-in: gravity-driven fall, acceleration builds toward f15.',
      },
      {
        name: 'Pre-swing push-off',
        frames: 'f15 – f18',
        root: 'Double support. The root continues at constant ground speed.',
        joints: 'Toe pivot, foot pitch to −48° (ankle plantarflexes ≈ 4° past neutral), knee flexes 24° → 45°. Hip is extended behind the line of the root.',
        curve: 'Short, strong ankle plantar-flexion impulse; the toe stays world-locked until release.',
      },
      {
        name: 'Swing',
        frames: 'f18 – f25',
        root: 'Single support on the opposite leg; root rising.',
        joints:
          'Foot moves backward ≈ 4 cm then accelerates forward. Peak foot clearance 9 cm at f24. Knee flexion peaks ≈ 55–60°, hip flexes 35°.',
        curve: 'Hermite curve with toe-off and landing tangents equal to the ground speed.',
      },
      {
        name: 'Terminal swing',
        frames: 'f25 – f30',
        root: 'Root lowers into the next contact.',
        joints: 'Knee extends to ≈ 24°, foot pitches up to +12° ahead of strike, thigh decelerates.',
        curve: 'Ease-out: the leg decelerates, no snapping, no hyperextension.',
      },
    ],
    weight: [
      'The root rises over the stance leg and falls into double support: two 6 cm vertical cycles per stride.',
      'The stance foot is the pivot. The hips are always inside the stride envelope; legs never reach more than 99.8 % of their length.',
      'Trunk lean is 4° with a ±1.2° oscillation at twice the cadence, so the upper body leans into every foot strike.',
      'Single support spans 40 % of the cycle, so the COM is permitted to move outside the foot only during double support.',
    ],
    secondary: [
      'Light tail: horizontal drag trails behind the root at 1.1 m/s and vertical lag of ≈ 3 f at each root peak. Peak amplitude ±6 cm.',
      'Loose fabric: delayed 4–5 f from thorax pitch and gets a secondary wave on each heel strike (vertical deceleration spike).',
      'Hanging gear: pendulum that swings ≈ 8° at 2× cadence, 90° out of phase with the root. Damping 0.994 / step.',
      'Collision: torso, head and both thighs are capsules (r = 10, 12, 8 cm). Nodes are projected outside after every constraint pass.',
    ],
    antic: [
      'Swing anticipation: before the foot goes forward, it moves 4 cm backward (Hermite toe-off tangent) and the knee flexes 20°.',
      'Heel-strike anticipation: the foot pitches up to +12° and the knee starts extending 4 f before contact.',
      'Follow-through: elbows lag shoulders by 12 % of cycle (3.6 f); head and thorax lag the lumbar by 1–3 f.',
      'Settle: the foot rolls from heel to flat over 4.5 f, preventing a stomp. In swing the foot follows the shin with a relaxed ≈ 8° ankle.',
    ],
    chain: [
      { step: '1 · Foot / ground', t: 'f0', detail: 'Strike. Ground reaction launches the vault; the foot is the fixed point.' },
      { step: '2 · Knee → hip → root', t: 'f0 – f4', detail: 'Knee yields 24°, then the hip and root rise over the stance foot.' },
      { step: '3 · Lumbar', t: '+0 f', detail: 'Pitch oscillation 1.2° at 2× cadence.' },
      { step: '4 · Thorax', t: '+1.2 f', detail: 'Lags lumbar by 4 % of the cycle.' },
      { step: '5 · Head', t: '+2.7 f', detail: 'Counter-pitches 0.5° to hold the horizon.' },
      { step: '6 · Shoulder', t: '+1.5 f', detail: 'Swings 22° opposite to the same-side leg, 6° forward bias.' },
      { step: '7 · Elbow', t: '+3.6 f more', detail: 'Elbow flexion 22° ± 14° trails the shoulder: classic follow-through.' },
    ],
    contacts: [
      'Stance foot ground velocity: 0.0 cm/s for 100 % of stance, verified live in the HUD.',
      'Ground-match landing: swing tangent = −ground speed at w = 1.',
      'QC: no IK clamp in stance, bone length error < 1e-10 %, chain residual < 0.5 %.',
    ],
  },

  run: {
    id: 'run',
    title: 'Run · spring-mass cycle',
    summary:
      'A 0.72 s jogging cycle (167 steps/min) with true flight phases. The root follows a ballistic arc in flight and compresses through the stance leg; the vertical curve is C1-matched at touchdown so there is no velocity pop.',
    stats: [
      ['Cycle', '0.72 s · 21.6 f'],
      ['Root speed', '2.38 m/s'],
      ['Stance duty', '35 % · flight 15 %'],
      ['Flight time', '≈ 0.108 s'],
      ['Root height', '0.81 – 0.86 m'],
      ['Trunk lean', '13° ± 2°'],
    ],
    phases: [
      {
        name: 'Absorb (touchdown)',
        frames: 'f0 – f2.5',
        root: 'Touchdown at 0.85 m, falling at 0.5 m/s. Root compresses by 4.3 cm over the stance.',
        joints: 'Mid-foot strike (+4°), hip ≈ 35° flexion, knee 35° → 60° flexion absorbing impact. Opposite arm at peak forward.',
        curve: 'Ease-out: knee flexion rate decays as the leg loads.',
      },
      {
        name: 'Mid-stance',
        frames: 'f2.5 – f5',
        root: 'Lowest point, over the foot; forward lean 13°.',
        joints: 'Knee ≈ 55–60° flexion, ankle dorsiflexion peak ≈ 30°, hip ≈ 20° flexion.',
        curve: 'Root velocity crosses zero at the minimum.',
      },
      {
        name: 'Propel',
        frames: 'f5 – f7.5',
        root: 'Root rises and accelerates forward-up. Foot stays pinned until toe-off.',
        joints: 'Hip extends, knee extends 60° → 35°, foot pitch to −55°. Heel rises, toe pivot.',
        curve: 'Ease-in on push-off: power peaks right before release.',
      },
      {
        name: 'Flight',
        frames: 'f7.5 – f10.8',
        root: 'Ballistic parabola: apex rise 1.4 cm, no thrust. Both feet off the ground.',
        joints: 'Trailing leg heel-kicks, knee ≈ 100–110° at mid-swing. Lead leg reaches forward, knee extends. Arms continue.',
        curve: 'Constant gravitational acceleration, 9.81 m/s².',
      },
    ],
    weight: [
      'The root follows a spring-mass pattern: it falls 1.4 cm in flight, compresses 4.3 cm in stance, and recovers. The two curves are slope-matched at touchdown.',
      'Forward lean of 13° keeps the COM ahead of the stance foot at touchdown and behind it at toe-off, which makes the body fall onto the next step.',
      'The foot lands under, not ahead of, the root (≈ 30 cm forward for 85 cm leg length), which limits braking.',
      'Landing foot moves at ground speed, so there is no skid on touchdown.',
    ],
    secondary: [
      'Light tail: streams back 15–20 cm in flight, then drops 6–8 cm on each touchdown with a 2–3 f delay.',
      'Loose fabric: bigger amplitude (±12 cm) and a clear whip on each push-off; the chain follows the root deceleration.',
      'Hanging gear: bounces vertically out of phase with the root (1 f lag) and settles within 6–8 f.',
      'Collision capsules keep every node outside torso, head and thighs, including at the 13° lean.',
    ],
    antic: [
      'Heel-kick anticipation: the trailing leg flexes the knee to ≈ 105° before swinging forward; this is the wind-up of the swing.',
      'Touchdown anticipation: the foot is pulled back toward ground speed (swing tangent) and the ankle pre-dorsiflexes 2 f before contact.',
      'Follow-through: elbows lag shoulders by 12 % of cycle; trunk follows pelvis by ≈ 1 f; head is stabilised against the lean.',
    ],
    chain: [
      { step: '1 · Foot / ground', t: 'f0', detail: 'Mid-foot touchdown, impact absorbed at ankle and knee.' },
      { step: '2 · Knee → hip', t: 'f0 – f2.5', detail: 'Knee flexion 35° → 60° while the hip decelerates the root.' },
      { step: '3 · Root', t: 'f2.5', detail: 'Compression minimum, then re-acceleration.' },
      { step: '4 · Lumbar → thorax → head', t: '+0 / +0.9 / +2 f', detail: 'Pitch pulses of ±2° with a 1–2 f lag per segment.' },
      { step: '5 · Shoulder → elbow', t: '+1 f / +2.6 f more', detail: 'Arms drive at 46° opposite to the leg; elbow ≈ 92° ± 16°.' },
    ],
    contacts: [
      'Stance foot: 0 cm/s ground velocity for the whole 35 % of the cycle.',
      'Flight is a pure parabola; no foot is below the ground plane at any frame.',
      'QC: IK clamp is permitted only in late swing; any clamp in stance is a failure.',
    ],
  },

  jump: {
    id: 'jump',
    title: 'Jump · crouch, launch, land',
    summary:
      'A standing jump in 2.7 s. A long anticipation crouch with arm counter-swing, an accelerating drive, a ballistic flight with a leg tuck, a decelerating landing absorb and a damped-spring settle. Feet stay world-locked before take-off and after landing.',
    stats: [
      ['Loop length', '2.70 s · 81 f'],
      ['Take-off speed', '2.63 m/s'],
      ['Flight time', '0.55 s · 16.5 f'],
      ['Apex rise', '≈ 0.35 m'],
      ['Crouch depth', '0.62 m root height'],
      ['Landing speed', '2.77 m/s'],
    ],
    phases: [
      {
        name: 'Anticipation',
        frames: 'f0 – f18',
        root: 'Root drops 0.915 → 0.62 m and shifts 9 cm back over the feet.',
        joints: 'Knees flex to ≈ 100°, hips flex, trunk leans to 30°, arms swing back to −55° by f13.5 (leading the root).',
        curve: 'Smooth in/out, arms reach the peak 4.5 f before the root bottoms out.',
      },
      {
        name: 'Drive',
        frames: 'f18 – f24.6',
        root: 'Root accelerates up to 0.97 m (a rise onto the toes) in 0.22 s.',
        joints: 'Hip → knee → ankle extend in sequence. Arms swing to 150°. Trunk 30° → 6°.',
        curve: 'Power ease t^1.65: accelerates all the way to launch, with end slope = take-off velocity.',
      },
      {
        name: 'Flight',
        frames: 'f24.6 – f41',
        root: 'Pure parabola with v₀ = 2.63 m/s and g = 9.81 m/s².',
        joints: 'Legs tuck 0.30 m (knee flex ≈ 90–100°), arms reach 170°, ankle plantarflexed to −35°, then toes reach to −5° just before contact.',
        curve: 'Constant acceleration, no keyed motion on the root.',
      },
      {
        name: 'Landing',
        frames: 'f41 – f47.7',
        root: 'Falls 0.93 → 0.60 m while decelerating from 2.77 m/s to 0.',
        joints: 'Forefoot contact (−5°), then flat. Knees 90°+, trunk to 26°, arms 95° → 35°.',
        curve: 'Hermite with start slope = landing velocity and end slope 0: a true brake.',
      },
      {
        name: 'Settle',
        frames: 'f47.7 – f81',
        root: 'Spring recovery 0.60 → 0.915 m, damping ratio 0.7, 12 rad/s; overshoot ≈ 1.4 cm.',
        joints: 'Knees extend, trunk back to 2°, arms return with a small overshoot.',
        curve: 'Critically-damped-like spring, no hard stop.',
      },
    ],
    weight: [
      'During the crouch, the root moves 9 cm behind the feet; the COM stays within the support span and then shifts forward in the drive, so the jump is a controlled fall upward.',
      'Take-off: the COM leaves in line with the balls of the feet. Landing: the COM lands 3–10 cm ahead of the feet and the forward lean absorbs it.',
      'In flight, the COM trajectory is a pure parabola; tuck and arm motion move the limbs relative to the COM, not the COM itself.',
      'On landing, ground contact is full-foot within 3 frames; the foot positions are identical to the take-off position, so no sliding or re-planting.',
    ],
    secondary: [
      'Light tail: lags the launch by 3 f, floats up at the apex, falls and whips forward at the landing deceleration.',
      'Loose fabric: sweeps upward in the drive (inertia), floats during flight, then folds over the landing compression.',
      'Hanging gear: unweights at the apex and slams down at landing, rebounding twice before it settles (≈ 14 f).',
      'Capsule collision stops all three chains from sinking into the torso and thighs during the 30° forward lean.',
    ],
    antic: [
      'Anticipation: arms lead the crouch by 4.5 f, so the body visibly prepares before the main drop; the crouch takes 18 f.',
      'Launch overshoot: the root rises onto the toes (0.97 m) before leaving the ground, so the extension is not truncated.',
      'Follow-through: arms continue to 170° after take-off. Elbows lag shoulders by 6 f.',
      'Landing settle: the root undershoots and recovers with a 1.4 cm overshoot, and the arms and trunk follow with 1–3 f delays.',
    ],
    chain: [
      { step: '1 · Arms (lead)', t: 'f9 → f13.5', detail: 'Counter-swing back: weight is loaded before the root moves.' },
      { step: '2 · Ankle / knee / hip (drive)', t: 'f18 → f24.6', detail: 'Extend ankle→knee→hip in a proximal-to-distal wave.' },
      { step: '3 · Lumbar', t: 'f18', detail: '30° → 6°, driven by the pelvis.' },
      { step: '4 · Thorax', t: '+1.2 f', detail: 'Lag 40 ms.' },
      { step: '5 · Head', t: '+2.7 f', detail: 'Lag 90 ms, 0.4× lean, 4° extra pitch in flight for gaze.' },
      { step: '6 · Arms (follow)', t: '+0.9 f / +1.8 f', detail: 'Shoulder follows the thorax; elbow trails the shoulder by 60 ms.' },
    ],
    contacts: [
      'Pre-takeoff and post-landing contacts: 0 cm/s, identical foot positions.',
      'Heel rises through a toe pivot during the drive (0 → −35°), so the toe does not slip at launch.',
      'QC: take-off and landing IK stays within 99.8 % of leg length; the flight tuck does not change bone length.',
    ],
  },
};

export function toMarkdown(spec: Spec, rom: { joint: string; min: number; max: number }[]): string {
  const L: string[] = [];
  L.push(`# ${spec.title}`, '', spec.summary, '', '## Locked-rig rules');
  GLOBAL_RULES.forEach((r) => L.push(`- ${r}`));
  L.push('', '## Parameters');
  spec.stats.forEach(([k, v]) => L.push(`- **${k}:** ${v}`));
  L.push('', '## Phase breakdown', '', '| Phase | Frames | Root / COM | Joint rotations | Velocity curve |', '|---|---|---|---|---|');
  spec.phases.forEach((p) => L.push(`| ${p.name} | ${p.frames} | ${p.root} | ${p.joints} | ${p.curve} |`));
  L.push('', '## Measured range of motion (from the rig solver)', '', '| Joint | Min | Max |', '|---|---|---|');
  rom.forEach((r) => L.push(`| ${r.joint} | ${r.min.toFixed(1)}° | ${r.max.toFixed(1)}° |`));
  const sec = (t: string, a: string[]) => {
    L.push('', `## ${t}`);
    a.forEach((x) => L.push(`- ${x}`));
  };
  sec('Weight and balance', spec.weight);
  sec('Secondary motion', spec.secondary);
  sec('Anticipation and follow-through', spec.antic);
  L.push('', '## Kinetic chain', '');
  spec.chain.forEach((c) => L.push(`1. **${c.step}** (${c.t}): ${c.detail}`));
  sec('Contacts and QC', spec.contacts);
  return L.join('\n');
}
