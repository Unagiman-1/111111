// Rigid-rig animation engine (2D sagittal view, y-up, metres, degrees for angles).
// Bone lengths are constants: there is NO scale channel anywhere in this file.
// Every pose is expressed as rotations + root translation + IK targets only.

export type V2 = [number, number];
export type AnimId = 'idle' | 'walk' | 'run' | 'jump';

export const D2R = Math.PI / 180;
export const R2D = 180 / Math.PI;
export const G = 9.81;

export const L = {
  thigh: 0.47,
  shin: 0.47,
  lumbar: 0.24,
  thorax: 0.26,
  neck: 0.09,
  headR: 0.11,
  uarm: 0.3,
  farm: 0.27,
  heel: 0.06,
  toe: 0.12,
  ankleH: 0.07,
};
export const LEG = L.thigh + L.shin;

export const clamp = (x: number, a: number, b: number) => Math.min(b, Math.max(a, x));
export const ss = (x: number) => {
  const t = clamp(x, 0, 1);
  return t * t * (3 - 2 * t);
};
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const dir = (aDeg: number): V2 => [Math.sin(aDeg * D2R), Math.cos(aDeg * D2R)]; // 0° = up, + = forward
const rot = (v: V2, aDeg: number): V2 => {
  const c = Math.cos(aDeg * D2R);
  const s = Math.sin(aDeg * D2R);
  return [v[0] * c - v[1] * s, v[0] * s + v[1] * c];
};

export interface Foot {
  x: number;
  y: number; // ankle height above ankle-ground baseline
  pitch: number; // deg, + = toes up
  contact: boolean;
  follow?: number; // 0..1: blend of foot orientation toward "relaxed ankle follows the shin"
}
export interface Arm {
  sh: number; // shoulder angle from hanging, + = forward
  el: number; // elbow flexion, + = forearm forward
}
export interface Pose {
  hip: V2;
  feet: [Foot, Foot];
  lumbar: number; // absolute segment angles from vertical (+ = forward lean)
  thorax: number;
  head: number;
  arms: [Arm, Arm];
  speed: number; // ground speed of the root (m/s) - world scrolls under planted feet
  tag: string;
}

export const DURATION: Record<AnimId, number> = { idle: 5, walk: 1.0, run: 0.72, jump: 2.7 };

export interface PhaseDef {
  name: string;
  from: number; // normalized
  to: number;
  color: string;
}
const pc = ['#38bdf8', '#34d399', '#fbbf24', '#f87171', '#a78bfa', '#f472b6', '#2dd4bf', '#fb923c'];
export const PHASES: Record<AnimId, PhaseDef[]> = {
  idle: [
    { name: 'Load → forward foot', from: 0, to: 0.5, color: pc[0] },
    { name: 'Load → rear foot', from: 0.5, to: 1, color: pc[1] },
  ],
  walk: [
    { name: 'Contact / loading', from: 0, to: 0.12, color: pc[0] },
    { name: 'Mid-stance', from: 0.12, to: 0.3, color: pc[1] },
    { name: 'Terminal stance', from: 0.3, to: 0.5, color: pc[2] },
    { name: 'Pre-swing push-off', from: 0.5, to: 0.6, color: pc[3] },
    { name: 'Swing', from: 0.6, to: 0.85, color: pc[4] },
    { name: 'Terminal swing', from: 0.85, to: 1, color: pc[5] },
  ],
  run: [
    { name: 'Absorb A', from: 0, to: 0.12, color: pc[0] },
    { name: 'Mid A', from: 0.12, to: 0.24, color: pc[1] },
    { name: 'Propel A', from: 0.24, to: 0.35, color: pc[2] },
    { name: 'Flight', from: 0.35, to: 0.5, color: pc[3] },
    { name: 'Absorb B', from: 0.5, to: 0.62, color: pc[0] },
    { name: 'Mid B', from: 0.62, to: 0.74, color: pc[1] },
    { name: 'Propel B', from: 0.74, to: 0.85, color: pc[2] },
    { name: 'Flight', from: 0.85, to: 1, color: pc[3] },
  ],
  jump: [
    { name: 'Anticipation', from: 0, to: 0.6 / 2.7, color: pc[0] },
    { name: 'Drive', from: 0.6 / 2.7, to: 0.82 / 2.7, color: pc[2] },
    { name: 'Flight', from: 0.82 / 2.7, to: 1.37 / 2.7, color: pc[4] },
    { name: 'Landing', from: 1.37 / 2.7, to: 1.59 / 2.7, color: pc[3] },
    { name: 'Settle', from: 1.59 / 2.7, to: 1, color: pc[1] },
  ],
};

// ---------------------------------------------------------------- foot helpers
/** Ankle offset that keeps the pivot point (toe for pitch<0, heel for pitch>0) at its flat-foot ground position. */
export function footAdj(pitchDeg: number): V2 {
  const p = pitchDeg * D2R;
  const c = Math.cos(p);
  const s = Math.sin(p);
  if (p <= 0) {
    const tx = L.toe * c + L.ankleH * s;
    const ty = L.toe * s - L.ankleH * c;
    return [L.toe - tx, -L.ankleH - ty];
  }
  const hx = -L.heel * c + L.ankleH * s;
  const hy = -L.heel * s - L.ankleH * c;
  return [-L.heel - hx, -L.ankleH - hy];
}

const hermite = (p0: number, p1: number, m0: number, m1: number, t: number) => {
  const t2 = t * t;
  const t3 = t2 * t;
  return (2 * t3 - 3 * t2 + 1) * p0 + (t3 - 2 * t2 + t) * m0 + (-2 * t3 + 3 * t2) * p1 + (t3 - t2) * m1;
};

// ---------------------------------------------------------------- gait
interface GaitDef {
  T: number;
  duty: number;
  stride: number;
  lift: number;
  strike: number;
  toeoff: number;
  toeStart: number;
}
export const WALK: GaitDef = { T: 1.0, duty: 0.6, stride: 0.66, lift: 0.09, strike: 12, toeoff: 48, toeStart: 0.65 };
export const RUN: GaitDef = { T: 0.72, duty: 0.35, stride: 0.6, lift: 0.28, strike: 4, toeoff: 55, toeStart: 0.6 };
const RUN_HEND = 0.85;
const RUN_FLIGHT = (0.5 - RUN.duty) * RUN.T;
const RUN_APEX = (G * RUN_FLIGHT * RUN_FLIGHT) / 8;
const RUN_DIP = ((4 * RUN_APEX) / RUN_FLIGHT) * ((RUN.duty * RUN.T) / Math.PI); // C1-matched with ballistic arc

export const gaitSpeed = (g: GaitDef) => g.stride / (g.duty * g.T);

function gaitFoot(g: GaitDef, u: number): Foot {
  const { duty, stride } = g;
  let x: number, y: number, pitch: number, contact: boolean;
  if (u < duty) {
    const s = u / duty;
    pitch = g.strike * (1 - ss(s / 0.15)) - g.toeoff * ss((s - g.toeStart) / (1 - g.toeStart));
    x = stride / 2 - stride * s; // exactly cancels root travel → zero world velocity
    y = 0;
    contact = true;
  } else {
    const w = (u - duty) / (1 - duty);
    // tangents equal the ground-speed tangent: toe-off and landing velocity match the treadmill
    const m = (-stride * (1 - duty)) / duty;
    x = hermite(-stride / 2, stride / 2, m, m, w);
    y = g.lift * Math.sin(Math.PI * w);
    pitch = -g.toeoff * (1 - ss(w / 0.45)) + g.strike * ss((w - 0.6) / 0.4);
    contact = false;
  }
  const a = footAdj(pitch);
  const follow = contact ? 0 : Math.pow(Math.sin(Math.PI * ((u - duty) / (1 - duty))), 0.6);
  return { x: x + a[0], y: y + a[1], pitch, contact, follow };
}

function gaitPose(kind: 'walk' | 'run', t: number): Pose {
  const g = kind === 'walk' ? WALK : RUN;
  const p = (((t / g.T) % 1) + 1) % 1;
  let h: number;
  if (kind === 'walk') {
    h = 0.89 + 0.03 * Math.cos(4 * Math.PI * (p - g.duty / 2));
  } else {
    const q = p % 0.5;
    if (q < g.duty) h = RUN_HEND - RUN_DIP * Math.sin((Math.PI * q) / g.duty);
    else {
      const f = (q - g.duty) / (0.5 - g.duty);
      h = RUN_HEND + 4 * RUN_APEX * f * (1 - f);
    }
  }
  const fA = gaitFoot(g, p);
  const fB = gaitFoot(g, (p + 0.5) % 1);

  const walk = kind === 'walk';
  const base = walk ? 4 : 13;
  const a2 = walk ? 1.2 : 2.0;
  const osc = (ph: number) => a2 * Math.cos(4 * Math.PI * (ph - 0.05));
  const lumbar = base + osc(p);
  const thorax = base + (walk ? 2 : 3) + osc(p - 0.04) * 1.2;
  const head = base * 0.3 - osc(p - 0.09) * 0.5;

  const amp = walk ? 22 : 46;
  const bias = walk ? 6 : 8;
  const armSh = (ph: number) => amp * Math.cos(2 * Math.PI * (ph - 0.05));
  const elBase = walk ? 22 : 92;
  const elAmp = walk ? 14 : 16;
  const arm = (ph: number): Arm => {
    const sh = bias - armSh(ph); // arm A swings opposite to leg A
    const lagged = -armSh(ph - 0.12) / amp;
    return { sh, el: elBase + elAmp * lagged };
  };
  return {
    hip: [0, h],
    feet: [fA, fB],
    lumbar,
    thorax,
    head,
    arms: [arm(p), arm(p + 0.5)],
    speed: gaitSpeed(g),
    tag: kind,
  };
}

// ---------------------------------------------------------------- idle
function idlePose(t: number): Pose {
  const ph = t / DURATION.idle;
  const sh = Math.sin(2 * Math.PI * ph);
  const br = (q: number) => Math.sin(2 * Math.PI * 2 * q);
  const pA = -6 * Math.max(0, -sh);
  const pB = -6 * Math.max(0, sh);
  const mk = (x: number, pitch: number): Foot => {
    const a = footAdj(pitch);
    return { x: x + a[0], y: a[1], pitch, contact: true };
  };
  const swayArm = (s: number, ph0: number): Arm => ({
    sh: 5 + 3 * Math.sin(2 * Math.PI * 2 * (ph - ph0) - 0.8) + 4 * Math.sin(2 * Math.PI * (ph - ph0 - 0.04)) * s,
    el: 12 + 3 * br(ph - ph0 - 0.03),
  });
  return {
    hip: [0.025 * sh, 0.915 + 0.003 * br(ph)],
    feet: [mk(0.07, pA), mk(-0.07, pB)],
    lumbar: 1.5 + 0.7 * br(ph) + 0.5 * sh,
    thorax: 2.2 + 1.2 * br(ph - 0.02) + 0.5 * sh,
    head: 1.0 - 0.8 * br(ph - 0.05) - 0.4 * sh,
    arms: [swayArm(1, 0), swayArm(-1, 0.015)],
    speed: 0,
    tag: 'idle',
  };
}

// ---------------------------------------------------------------- jump (keyframed channels + ballistic flight)
type Ease = 'smooth' | 'in' | 'out' | 'spring' | 'lin';
interface Key {
  t: number;
  v: number;
  e?: Ease;
}
const SPRING_Z = 0.7;
const SPRING_W = 12;
function springF(tau: number) {
  const wd = SPRING_W * Math.sqrt(1 - SPRING_Z * SPRING_Z);
  return (
    1 -
    Math.exp(-SPRING_Z * SPRING_W * tau) *
      (Math.cos(wd * tau) + ((SPRING_Z * SPRING_W) / wd) * Math.sin(wd * tau))
  );
}
function easeF(e: Ease, s: number, dur: number) {
  switch (e) {
    case 'in':
      return Math.pow(clamp(s, 0, 1), 1.65);
    case 'out':
      return 1 - Math.pow(1 - clamp(s, 0, 1), 2);
    case 'lin':
      return s;
    case 'spring':
      return springF(s * dur);
    default:
      return ss(s);
  }
}
function sampleKeys(keys: Key[], t: number) {
  if (t <= keys[0].t) return keys[0].v;
  for (let i = 1; i < keys.length; i++) {
    if (t < keys[i].t) {
      const a = keys[i - 1];
      const b = keys[i];
      const dur = b.t - a.t;
      return lerp(a.v, b.v, easeF(b.e ?? 'smooth', (t - a.t) / dur, dur));
    }
  }
  return keys[keys.length - 1].v;
}

const J_T = { antEnd: 0.6, driveEnd: 0.82, flightEnd: 1.37, landEnd: 1.59 };
const J_STAND = 0.915;
const J_CROUCH = 0.62;
const J_TOP = 0.97; // take-off hip height (rise onto toes)
const J_LAND_CONTACT = 0.93;
const J_FLIGHT = J_T.flightEnd - J_T.driveEnd;
const J_VY = (0.5 * G * J_FLIGHT * J_FLIGHT - (J_TOP - J_LAND_CONTACT)) / J_FLIGHT;
const J_LAND_BOTTOM = 0.6;

const K_LEAN: Key[] = [
  { t: 0, v: 2 },
  { t: 0.6, v: 30 },
  { t: 0.82, v: 6, e: 'in' },
  { t: 1.37, v: 14 },
  { t: 1.59, v: 26, e: 'out' },
  { t: 2.7, v: 2, e: 'spring' },
];
const K_ARM: Key[] = [
  { t: 0, v: 5 },
  { t: 0.45, v: -55 },
  { t: 0.6, v: -55 },
  { t: 0.82, v: 150, e: 'in' },
  { t: 1.1, v: 170, e: 'out' },
  { t: 1.37, v: 95 },
  { t: 1.59, v: 35, e: 'out' },
  { t: 2.7, v: 5, e: 'spring' },
];
const K_ELB: Key[] = [
  { t: 0, v: 10 },
  { t: 0.6, v: 25 },
  { t: 0.82, v: 12 },
  { t: 1.1, v: 8 },
  { t: 1.37, v: 30 },
  { t: 1.59, v: 45 },
  { t: 2.7, v: 10, e: 'spring' },
];
const K_HIPX: Key[] = [
  { t: 0, v: 0 },
  { t: 0.6, v: -0.09 },
  { t: 0.82, v: 0.03, e: 'in' },
  { t: 1.37, v: 0.03 },
  { t: 1.59, v: 0.1, e: 'out' },
  { t: 2.7, v: 0, e: 'spring' },
];
const K_PITCH: Key[] = [
  { t: 0, v: 0 },
  { t: 0.7, v: 0 },
  { t: 0.82, v: -35 },
  { t: 1.05, v: -35 },
  { t: 1.3, v: -8 },
  { t: 1.37, v: -5 },
  { t: 1.45, v: 0 },
  { t: 2.7, v: 0 },
];

function jumpHip(t: number): number {
  if (t < J_T.antEnd) return lerp(J_STAND, J_CROUCH, ss(t / J_T.antEnd));
  if (t < J_T.driveEnd) return lerp(J_CROUCH, J_TOP, Math.pow((t - J_T.antEnd) / (J_T.driveEnd - J_T.antEnd), 1.65));
  if (t < J_T.flightEnd) {
    const tau = t - J_T.driveEnd;
    return J_TOP + J_VY * tau - 0.5 * G * tau * tau;
  }
  if (t < J_T.landEnd) {
    const dur = J_T.landEnd - J_T.flightEnd;
    const s = (t - J_T.flightEnd) / dur;
    const m0 = (J_VY - G * J_FLIGHT) * dur;
    return hermite(J_LAND_CONTACT, J_LAND_BOTTOM, m0, 0, s);
  }
  const tau = t - J_T.landEnd;
  return lerp(J_LAND_BOTTOM, J_STAND, springF(tau));
}

function jumpPose(t: number): Pose {
  const hipY = jumpHip(t);
  const hipX = sampleKeys(K_HIPX, t);
  const pitch = sampleKeys(K_PITCH, t);
  const adj = footAdj(pitch);
  const fly = t >= J_T.driveEnd && t < J_T.flightEnd;
  const mk = (fx: number): Foot => {
    if (!fly) return { x: fx + adj[0], y: adj[1], pitch, contact: true };
    const f = (t - J_T.driveEnd) / J_FLIGHT;
    const adj0 = footAdj(sampleKeys(K_PITCH, J_T.driveEnd))[1];
    const adj1 = footAdj(sampleKeys(K_PITCH, J_T.flightEnd))[1];
    const d0 = J_TOP - adj0;
    const d1 = J_LAND_CONTACT - adj1;
    const d = lerp(d0, d1, f) - 0.3 * Math.sin(Math.PI * f); // tuck: leg flexes, bones stay rigid
    return {
      x: fx + adj[0] + 0.12 * Math.sin(Math.PI * f),
      y: hipY - d,
      pitch,
      contact: false,
    };
  };
  const lean = (dt: number) => sampleKeys(K_LEAN, t - dt);
  const armAt = (dt: number, lead: number): Arm => ({
    sh: sampleKeys(K_ARM, t - dt - lead),
    el: sampleKeys(K_ELB, t - dt - lead - 0.06), // forearm lags upper arm
  });
  return {
    hip: [hipX, hipY],
    feet: [mk(0.07), mk(-0.07)],
    lumbar: lean(0),
    thorax: lean(0.04) * 1.1,
    head: lean(0.09) * 0.4 - (fly ? 4 : 0),
    arms: [armAt(0, 0), armAt(0, 0.03)],
    speed: 0,
    tag: 'jump',
  };
}

export function evalPose(anim: AnimId, t: number): Pose {
  switch (anim) {
    case 'idle':
      return idlePose(((t % DURATION.idle) + DURATION.idle) % DURATION.idle);
    case 'walk':
      return gaitPose('walk', t);
    case 'run':
      return gaitPose('run', t);
    default:
      return jumpPose(clamp(((t % DURATION.jump) + DURATION.jump) % DURATION.jump, 0, DURATION.jump - 1e-6));
  }
}

// ---------------------------------------------------------------- skeleton (FK + two-bone IK)
export interface Skel {
  hip: V2;
  knee: [V2, V2];
  ankle: [V2, V2];
  heel: [V2, V2];
  toe: [V2, V2];
  l1: V2;
  sh: V2;
  neck: V2;
  head: V2;
  headAng: number;
  lumbarAng: number;
  thoraxAng: number;
  elbow: [V2, V2];
  wrist: [V2, V2];
  clamped: [boolean, boolean];
  pose: Pose;
}

function ik(hip: V2, target: V2, l1: number, l2: number) {
  const dx = target[0] - hip[0];
  const dy = target[1] - hip[1];
  const d = Math.hypot(dx, dy) || 1e-6;
  const maxD = (l1 + l2) * 0.998;
  const minD = Math.abs(l1 - l2) + 0.02;
  const dc = clamp(d, minD, maxD);
  const end: V2 = [hip[0] + (dx / d) * dc, hip[1] + (dy / d) * dc];
  const a = Math.atan2(dy, dx);
  const alpha = Math.acos(clamp((l1 * l1 + dc * dc - l2 * l2) / (2 * l1 * dc), -1, 1));
  const th = a + alpha; // knee bends forward
  const knee: V2 = [hip[0] + l1 * Math.cos(th), hip[1] + l1 * Math.sin(th)];
  return { knee, end, clamped: Math.abs(dc - d) > 1e-6 };
}

const RELAXED_ANKLE = 8; // deg dorsiflexion of a free (swinging) foot

export function buildSkeleton(src: Pose): Skel {
  const pose: Pose = { ...src, feet: [src.feet[0], src.feet[1]] };
  const hip = pose.hip;
  const knee: V2[] = [];
  const ankle: V2[] = [];
  const heel: V2[] = [];
  const toe: V2[] = [];
  const clamped: boolean[] = [];
  for (let i = 0; i < 2; i++) {
    let f = pose.feet[i];
    const r = ik(hip, [f.x, f.y], L.thigh, L.shin);
    if (f.follow) {
      const shinA = Math.atan2(r.end[0] - r.knee[0], -(r.end[1] - r.knee[1])) * R2D;
      f = { ...f, pitch: lerp(f.pitch, RELAXED_ANKLE + shinA, f.follow) };
      pose.feet[i] = f;
    }
    knee.push(r.knee);
    ankle.push(r.end);
    clamped.push(r.clamped);
    const h = rot([-L.heel, -L.ankleH], f.pitch);
    const tt = rot([L.toe, -L.ankleH], f.pitch);
    heel.push([r.end[0] + h[0], r.end[1] + h[1]]);
    toe.push([r.end[0] + tt[0], r.end[1] + tt[1]]);
  }
  const dl = dir(pose.lumbar);
  const l1: V2 = [hip[0] + dl[0] * L.lumbar, hip[1] + dl[1] * L.lumbar];
  const dt = dir(pose.thorax);
  const sh: V2 = [l1[0] + dt[0] * L.thorax, l1[1] + dt[1] * L.thorax];
  const dh = dir(pose.head);
  const neck: V2 = [sh[0] + dh[0] * L.neck, sh[1] + dh[1] * L.neck];
  const head: V2 = [neck[0] + dh[0] * L.headR, neck[1] + dh[1] * L.headR];
  const elbow: V2[] = [];
  const wrist: V2[] = [];
  for (let i = 0; i < 2; i++) {
    const a = pose.arms[i];
    const u = dir(180 - a.sh); // 180° = hanging
    // dir(): 0°=up. Hanging down = 180°, forward swing reduces the angle.
    const e: V2 = [sh[0] + u[0] * L.uarm, sh[1] + u[1] * L.uarm];
    const f = dir(180 - a.sh - a.el);
    elbow.push(e);
    wrist.push([e[0] + f[0] * L.farm, e[1] + f[1] * L.farm]);
  }
  return {
    hip,
    knee: [knee[0], knee[1]],
    ankle: [ankle[0], ankle[1]],
    heel: [heel[0], heel[1]],
    toe: [toe[0], toe[1]],
    l1,
    sh,
    neck,
    head,
    headAng: pose.head,
    lumbarAng: pose.lumbar,
    thoraxAng: pose.thorax,
    elbow: [elbow[0], elbow[1]],
    wrist: [wrist[0], wrist[1]],
    clamped: [clamped[0], clamped[1]],
    pose,
  };
}

const dist = (a: V2, b: V2) => Math.hypot(a[0] - b[0], a[1] - b[1]);

/** Maximum relative deviation of any primary bone from its rest length (should be ~0). */
export function boneDeviation(s: Skel): number {
  const pairs: [V2, V2, number][] = [];
  for (let i = 0; i < 2; i++) {
    pairs.push([s.hip, s.knee[i], L.thigh], [s.knee[i], s.ankle[i], L.shin]);
    pairs.push([s.sh, s.elbow[i], L.uarm], [s.elbow[i], s.wrist[i], L.farm]);
  }
  pairs.push([s.hip, s.l1, L.lumbar], [s.l1, s.sh, L.thorax], [s.sh, s.neck, L.neck]);
  let m = 0;
  for (const [a, b, l] of pairs) m = Math.max(m, Math.abs(dist(a, b) - l) / l);
  return m * 100;
}

export interface Angles {
  hip: number; // flexion +
  knee: number; // flexion +
  ankle: number; // dorsiflexion +
  shoulder: number;
  elbow: number;
  trunk: number;
}
export function legAngles(s: Skel, i: number): Angles {
  const t = Math.atan2(s.knee[i][0] - s.hip[0], -(s.knee[i][1] - s.hip[1])) * R2D;
  const a = Math.atan2(s.ankle[i][0] - s.knee[i][0], -(s.ankle[i][1] - s.knee[i][1])) * R2D;
  return {
    hip: t,
    knee: t - a,
    ankle: s.pose.feet[i].pitch - a,
    shoulder: s.pose.arms[i].sh,
    elbow: s.pose.arms[i].el,
    trunk: s.pose.lumbar,
  };
}

// ---------------------------------------------------------------- centre of mass & support
const mid = (a: V2, b: V2): V2 => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
export function computeCOM(s: Skel): V2 {
  const parts: [V2, number][] = [
    [mid(s.hip, s.sh), 0.497],
    [s.head, 0.081],
  ];
  for (let i = 0; i < 2; i++) {
    parts.push([mid(s.hip, s.knee[i]), 0.1], [mid(s.knee[i], s.ankle[i]), 0.0465]);
    parts.push([mid(s.ankle[i], s.toe[i]), 0.0145]);
    parts.push([mid(s.sh, s.elbow[i]), 0.028], [mid(s.elbow[i], s.wrist[i]), 0.022]);
  }
  let x = 0;
  let y = 0;
  let m = 0;
  for (const [p, w] of parts) {
    x += p[0] * w;
    y += p[1] * w;
    m += w;
  }
  return [x / m, y / m];
}

export interface Support {
  min: number;
  max: number;
  grounded: boolean;
}
export function computeSupport(s: Skel): Support {
  const gy = -L.ankleH + 0.012;
  let min = Infinity;
  let max = -Infinity;
  for (let i = 0; i < 2; i++) {
    if (!s.pose.feet[i].contact) continue;
    for (const p of [s.heel[i], s.toe[i]]) {
      if (p[1] <= gy) {
        min = Math.min(min, p[0]);
        max = Math.max(max, p[0]);
      }
    }
  }
  return { min, max, grounded: isFinite(min) };
}

/** Contact pivot point of a foot: heel when toes are up, toe otherwise. */
export const contactPoint = (s: Skel, i: number): V2 => (s.pose.feet[i].pitch > 0 ? s.heel[i] : s.toe[i]);

/** Displacement (m) of last frame's grounded pivot point (heel if its pitch was > 0, else toe) since the previous frame. */
export function pivotSlip(s: Skel, i: number, prevHeel: V2, prevToe: V2, prevPitch: number, dDist: number): number {
  const heel = prevPitch > 0;
  const cur = heel ? s.heel[i] : s.toe[i];
  const prv = heel ? prevHeel : prevToe;
  return Math.hypot(cur[0] + dDist - prv[0], cur[1] - prv[1]);
}

// ---------------------------------------------------------------- secondary motion (Verlet chains)
export interface P2 {
  x: number;
  y: number;
}
export interface Chain {
  id: 'hair' | 'cloth' | 'gear';
  label: string;
  color: string;
  pts: P2[];
  prev: P2[];
  seg: number;
  damp: number;
  grav: number;
  stiff: number;
  width: number;
  residual: number;
}

export function makeChains(): Chain[] {
  const mk = (
    id: Chain['id'],
    label: string,
    color: string,
    n: number,
    seg: number,
    damp: number,
    grav: number,
    stiff: number,
    width: number,
  ): Chain => ({
    id,
    label,
    color,
    pts: Array.from({ length: n }, () => ({ x: 0, y: 0 })),
    prev: Array.from({ length: n }, () => ({ x: 0, y: 0 })),
    seg,
    damp,
    grav,
    stiff,
    width,
    residual: 0,
  });
  return [
    mk('hair', 'Chain A · light tail', '#fbbf24', 7, 0.05, 0.992, 0.8, 0.03, 0.02),
    mk('cloth', 'Chain B · loose fabric', '#f472b6', 8, 0.07, 0.99, 1.0, 0.012, 0.035),
    mk('gear', 'Chain C · hanging gear', '#2dd4bf', 4, 0.07, 0.994, 1.0, 0, 0.03),
  ];
}

function anchorFor(c: Chain, s: Skel, ox: number): { a: V2; rest: V2 } {
  const w = (v: V2): V2 => [v[0] + ox, v[1]];
  if (c.id === 'hair') {
    const f = rot([1, 0], -s.headAng);
    const u = dir(s.headAng);
    const hc = s.head;
    const a: V2 = [hc[0] + f[0] * -0.095 + u[0] * 0.03, hc[1] + f[1] * -0.095 + u[1] * 0.03];
    const r = [-0.6 * f[0] - 0.8 * u[0], -0.6 * f[1] - 0.8 * u[1]] as V2;
    return { a: w(a), rest: r };
  }
  if (c.id === 'cloth') {
    const u = dir(s.thoraxAng);
    const f: V2 = [u[1], -u[0]];
    const a: V2 = [s.sh[0] - f[0] * 0.09 + u[0] * -0.03, s.sh[1] - f[1] * 0.09 + u[1] * -0.03];
    const r: V2 = [-0.5 * f[0] - 0.85 * u[0], -0.5 * f[1] - 0.85 * u[1]];
    return { a: w(a), rest: r };
  }
  const u = dir(s.lumbarAng);
  const f: V2 = [u[1], -u[0]];
  const a: V2 = [s.hip[0] - f[0] * 0.1 + u[0] * 0.05, s.hip[1] - f[1] * 0.1 + u[1] * 0.05];
  const r: V2 = [-0.3 * f[0] - 0.95 * u[0], -0.3 * f[1] - 0.95 * u[1]];
  return { a: w(a), rest: r };
}

export function resetChains(chains: Chain[], s: Skel, ox: number) {
  for (const c of chains) {
    const { a, rest } = anchorFor(c, s, ox);
    const n = Math.hypot(rest[0], rest[1]);
    for (let i = 0; i < c.pts.length; i++) {
      const x = a[0] + (rest[0] / n) * c.seg * i;
      const y = a[1] + (rest[1] / n) * c.seg * i;
      c.pts[i].x = c.prev[i].x = x;
      c.pts[i].y = c.prev[i].y = y;
    }
  }
}

function pushOutCapsule(p: P2, a: V2, b: V2, r: number) {
  const abx = b[0] - a[0];
  const aby = b[1] - a[1];
  const l2 = abx * abx + aby * aby || 1e-9;
  const t = clamp(((p.x - a[0]) * abx + (p.y - a[1]) * aby) / l2, 0, 1);
  const cx = a[0] + abx * t;
  const cy = a[1] + aby * t;
  const dx = p.x - cx;
  const dy = p.y - cy;
  const d = Math.hypot(dx, dy);
  if (d < r) {
    const k = d < 1e-6 ? 0 : r / d;
    if (k === 0) {
      p.y = cy + r;
    } else {
      p.x = cx + dx * k;
      p.y = cy + dy * k;
    }
  }
}

export function stepChains(chains: Chain[], s: Skel, ox: number, dt: number) {
  const W = (v: V2): V2 => [v[0] + ox, v[1]];
  const torsoA = W(s.hip);
  const torsoB = W(s.sh);
  const headC = W(s.head);
  const thighs = [W(s.knee[0]), W(s.knee[1])];
  const groundY = -L.ankleH + 0.012;
  for (const c of chains) {
    const { a, rest } = anchorFor(c, s, ox);
    const rn = Math.hypot(rest[0], rest[1]);
    const n = c.pts.length;
    for (let i = 1; i < n; i++) {
      const p = c.pts[i];
      const q = c.prev[i];
      const vx = (p.x - q.x) * c.damp;
      const vy = (p.y - q.y) * c.damp;
      q.x = p.x;
      q.y = p.y;
      p.x += vx;
      p.y += vy - G * c.grav * dt * dt;
    }
    for (let it = 0; it < 8; it++) {
      c.pts[0].x = a[0];
      c.pts[0].y = a[1];
      // soft rest-shape bias (fades along the chain)
      if (it === 0 && c.stiff > 0) {
        for (let i = 1; i < n; i++) {
          const k = c.stiff * (1 - (i - 1) / n);
          const tx = a[0] + (rest[0] / rn) * c.seg * i;
          const ty = a[1] + (rest[1] / rn) * c.seg * i;
          c.pts[i].x += (tx - c.pts[i].x) * k;
          c.pts[i].y += (ty - c.pts[i].y) * k;
        }
      }
      for (let i = 0; i < n - 1; i++) {
        const p = c.pts[i];
        const q = c.pts[i + 1];
        const dx = q.x - p.x;
        const dy = q.y - p.y;
        const d = Math.hypot(dx, dy) || 1e-9;
        const diff = (d - c.seg) / d;
        if (i === 0) {
          q.x -= dx * diff;
          q.y -= dy * diff;
        } else {
          p.x += dx * diff * 0.5;
          p.y += dy * diff * 0.5;
          q.x -= dx * diff * 0.5;
          q.y -= dy * diff * 0.5;
        }
      }
      for (let i = 1; i < n; i++) {
        const p = c.pts[i];
        pushOutCapsule(p, torsoA, torsoB, 0.1);
        pushOutCapsule(p, headC, headC, 0.12);
        pushOutCapsule(p, W(s.hip), thighs[0], 0.08);
        pushOutCapsule(p, W(s.hip), thighs[1], 0.08);
        if (p.y < groundY) {
          p.y = groundY;
          c.prev[i].x = p.x - (p.x - c.prev[i].x) * 0.6;
        }
      }
    }
    // final distance pass so the chain leaves the step with (near-)exact segment lengths
    for (let pass = 0; pass < 3; pass++) {
      c.pts[0].x = a[0];
      c.pts[0].y = a[1];
      for (let i = 0; i < n - 1; i++) {
        const p = c.pts[i];
        const q = c.pts[i + 1];
        const dx = q.x - p.x;
        const dy = q.y - p.y;
        const d = Math.hypot(dx, dy) || 1e-9;
        const diff = (d - c.seg) / d;
        const w = i === 0 ? 1 : 0.5;
        if (i > 0) {
          p.x += dx * diff * w;
          p.y += dy * diff * w;
        }
        q.x -= dx * diff * w;
        q.y -= dy * diff * w;
      }
    }
    let res = 0;
    for (let i = 0; i < n - 1; i++) {
      const d = Math.hypot(c.pts[i + 1].x - c.pts[i].x, c.pts[i + 1].y - c.pts[i].y);
      res = Math.max(res, Math.abs(d - c.seg) / c.seg);
    }
    c.residual = res * 100;
  }
}

// ---------------------------------------------------------------- sampling for charts / ROM
export interface Series {
  key: string;
  label: string;
  unit: string;
  values: number[];
}
export interface Sampled {
  n: number;
  series: Series[];
  rom: { joint: string; min: number; max: number }[];
}
export function sampleAnimation(anim: AnimId, n = 240): Sampled {
  const T = DURATION[anim];
  const dt = T / n;
  const sk: Skel[] = [];
  for (let i = 0; i <= n; i++) sk.push(buildSkeleton(evalPose(anim, (i / n) * T)));
  const hipY: number[] = [];
  const hipVy: number[] = [];
  const hipA: number[] = [];
  const kneeA: number[] = [];
  const ankA: number[] = [];
  const footSpd: number[] = [];
  const comY: number[] = [];
  const shA: number[] = [];
  const elA: number[] = [];
  const lean: number[] = [];
  const speed = evalPose(anim, 0).speed;
  for (let i = 0; i < n; i++) {
    const s = sk[i];
    const nx = sk[i + 1];
    const a = legAngles(s, 0);
    hipY.push(s.hip[1]);
    hipVy.push((nx.hip[1] - s.hip[1]) / dt);
    hipA.push(a.hip);
    kneeA.push(a.knee);
    ankA.push(a.ankle);
    shA.push(a.shoulder);
    elA.push(a.elbow);
    lean.push(a.trunk);
    comY.push(computeCOM(s)[1]);
    const vx = (nx.ankle[0][0] - s.ankle[0][0]) / dt + speed;
    const vy = (nx.ankle[0][1] - s.ankle[0][1]) / dt;
    footSpd.push(Math.hypot(vx, vy));
  }
  const rng = (v: number[]) => ({ min: Math.min(...v), max: Math.max(...v) });
  return {
    n,
    series: [
      { key: 'hipY', label: 'Root height', unit: 'm', values: hipY },
      { key: 'hipVy', label: 'Root vertical velocity', unit: 'm/s', values: hipVy },
      { key: 'comY', label: 'COM height', unit: 'm', values: comY },
      { key: 'hip', label: 'Hip flexion (leg A)', unit: '°', values: hipA },
      { key: 'knee', label: 'Knee flexion (leg A)', unit: '°', values: kneeA },
      { key: 'ankle', label: 'Ankle dorsiflexion (leg A)', unit: '°', values: ankA },
      { key: 'foot', label: 'Foot speed vs ground (leg A)', unit: 'm/s', values: footSpd },
    ],
    rom: [
      { joint: 'Hip flexion (+) / extension (−)', ...rng(hipA) },
      { joint: 'Knee flexion', ...rng(kneeA) },
      { joint: 'Ankle dorsi (+) / plantar (−)', ...rng(ankA) },
      { joint: 'Shoulder swing (+ fwd)', ...rng(shA) },
      { joint: 'Elbow flexion', ...rng(elA) },
      { joint: 'Trunk lean (lumbar)', ...rng(lean) },
    ],
  };
}
