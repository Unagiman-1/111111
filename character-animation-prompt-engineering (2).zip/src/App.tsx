import { useCallback, useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  ArrowUpRight,
  Bone,
  Check,
  ChevronRight,
  Crosshair,
  Download,
  ExternalLink,
  Footprints,
  Hand,
  Info,
  Pause,
  Play,
  RotateCcw,
  ShieldCheck,
  X,
} from "lucide-react";
import { CharacterRenderer } from "./animation/renderer";
import { solveRig, type SolvedRig } from "./animation/rig";
import { CLIPS, getClip, type Clip, type ClipId, type Pose } from "./animation/clips";
import {
  ContactTracker,
  SOURCE_HASH,
  boneLengthDeviation,
  formatChain,
  liveChecks,
  runFullAudit,
  verifySourceHash,
  type AuditCheck,
  type AuditReport,
} from "./animation/audit";
import { distance } from "./animation/math";

const referenceUrl = "https://drive.google.com/file/d/14vFlhs8xsn4F0-IbFR9ejSDNpLB2PUgT/view?usp=sharing";

type LiveState = {
  checks: AuditCheck[];
  contactL: boolean;
  contactR: boolean;
  comMargin: number;
  supportLabel: string;
  slipCm: number;
  deviation: number;
  hairAngle: number;
  coatAngle: number;
};

type GraphSample = {
  handSpeed: number;
  footSpeed: number;
  contactL: boolean;
  contactR: boolean;
};

type GraphData = {
  data: GraphSample[];
  maxSpeed: number;
};

const computeGraph = (clip: Clip): GraphData => {
  const samples = 96;
  const data: GraphSample[] = [];
  let previous = solveRig(clip.sample(0).rig);
  for (let index = 0; index <= samples; index++) {
    const phase = index / samples;
    const solved = solveRig(clip.sample(phase % 1).rig);
    const handSpeed = distance(solved.handR.wrist, previous.handR.wrist);
    const footSpeed = Math.max(distance(solved.footL.toe, previous.footL.toe), distance(solved.footR.toe, previous.footR.toe));
    data.push({
      handSpeed,
      footSpeed,
      contactL: solved.footL.contact,
      contactR: solved.footR.contact,
    });
    previous = solved;
  }
  const maxSpeed = Math.max(1e-6, ...data.map((sample) => Math.max(sample.handSpeed, sample.footSpeed)));
  return { data, maxSpeed };
};

const buildSpecText = (clip: Clip) => {
  const phases = clip.phases
    .map((item, index) => {
      const start = (item.start * clip.duration * clip.fps).toFixed(0);
      const end = (item.end * clip.duration * clip.fps).toFixed(0);
      return `${index + 1}. ${item.label.toUpperCase()} — frames ${start}–${end}\n${item.description}`;
    })
    .join("\n\n");
  return `ALTUSHKA / MOTION LAB — ANIMATION SPECIFICATION
Clip: ${clip.name}
Duration: ${clip.duration.toFixed(2)}s at ${clip.fps} fps
Loop: ${clip.loop ? "yes" : "no"}

INTENT
${clip.spec.intent}

WEIGHT & BALANCE
${clip.spec.weight}

KINETIC CHAIN
${clip.spec.chain}

SECONDARY MOTION
${clip.spec.secondary}

ANTICIPATION & FOLLOW-THROUGH
${clip.spec.anticipation}

CONTACT & CURVES
${clip.spec.contact}

PHASE BREAKDOWN
${phases}

NON-NEGOTIABLE CONSTRAINTS
- Original local bone scales and lengths stay fixed.
- No stretch IK, mesh scaling, or bone elongation.
- Planted heel, sole, or toe stays fixed in world space.
- Source texture, mesh, clothing, and anatomy are untouched.

SOURCE
Original full-body artwork: /reference/source-altushka.webp
SHA-256: ${SOURCE_HASH}
The supplied archive contains 2D artwork and procedural mesh motion, not a skeletal rig. This lab adds an animation layer to the full-body source; the joint-level instructions are conditional on a compatible rig.
`;
};

const buildReportText = (report: AuditReport, clip: Clip) => {
  const checks = report.checks
    .map((check) => `[${check.status.toUpperCase()}] ${check.label}: ${check.value}\n${check.detail}`)
    .join("\n\n");
  return `ALTUSHKA / MOTION LAB — AUDIT REPORT
Clip: ${clip.name}
Timestamp: ${new Date(report.timestamp).toISOString()}

CHECKS
${checks}

EDGE STRAIN
Max: ${(report.edgeStrain.max * 100).toFixed(3)}%
Mean: ${(report.edgeStrain.mean * 100).toFixed(3)}%
95th percentile: ${(report.edgeStrain.p95 * 100).toFixed(3)}%
Samples: ${report.edgeStrain.samples}

BONE LENGTH DEVIATION
${(report.boneLengthDeviation * 100).toFixed(4)}%

LOOP SEAM
Position: ${(report.loopSeam.position * 1000).toFixed(3)} mm
Angle: ${((report.loopSeam.angle * 180) / Math.PI).toFixed(3)}°

KINETIC CHAIN
${formatChain(report.kineticChain)}

SECONDARY / ANTICIPATION
Hair & coat lag: ${report.secondaryLagFrames.toFixed(2)} frames
Anticipation: ${report.anticipationFrames.toFixed(2)} frames
Follow-through: ${report.followThroughFrames.toFixed(2)} frames

SOURCE
SHA-256: ${report.sourceHash}
Verified: ${report.sourceHashVerified ? "yes" : "no"}
Expected: ${SOURCE_HASH}

The animation layer does not repaint, rescale, or replace the source character.
`;
};

const downloadText = (filename: string, text: string) => {
  const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
};

export default function App() {
  const [clipId, setClipId] = useState<ClipId>("idle");
  const [playing, setPlaying] = useState(true);
  const [speed, setSpeed] = useState(1);
  const [phase, setPhase] = useState(0);
  const [time, setTime] = useState(0);
  const [activePhase, setActivePhase] = useState(0);
  const [live, setLive] = useState<LiveState | null>(null);
  const [showRig, setShowRig] = useState(false);
  const [showPhysics, setShowPhysics] = useState(true);
  const [report, setReport] = useState<AuditReport | null>(null);
  const [auditState, setAuditState] = useState<"idle" | "running" | "done" | "error">("idle");
  const [sourceHash, setSourceHash] = useState(SOURCE_HASH);
  const [sourceVerified, setSourceVerified] = useState<boolean | null>(null);
  const [renderError, setRenderError] = useState<string | null>(null);
  const [rendererReady, setRendererReady] = useState(false);
  const [fps, setFps] = useState(0);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const overlayRef = useRef<HTMLCanvasElement>(null);
  const rendererRef = useRef<CharacterRenderer | null>(null);
  const trackerRef = useRef(new ContactTracker());
  const clipRef = useRef<Clip>(getClip("idle"));
  const phaseRef = useRef(0);
  const playingRef = useRef(true);
  const speedRef = useRef(1);
  const showRigRef = useRef(false);
  const showPhysicsRef = useRef(true);
  const solvedRef = useRef<SolvedRig | null>(null);
  const poseRef = useRef<Pose | null>(null);
  const lastTimeRef = useRef(0);
  const lastUiRef = useRef(0);
  const fpsTimeRef = useRef(0);
  const frameCountRef = useRef(0);

  const clip = getClip(clipId);
  const graph = useMemo(() => computeGraph(clip), [clip]);
  const specText = useMemo(() => buildSpecText(clip), [clip]);
  const reportText = useMemo(() => (report ? buildReportText(report, clip) : ""), [report, clip]);

  useEffect(() => {
    playingRef.current = playing;
  }, [playing]);

  useEffect(() => {
    speedRef.current = speed;
  }, [speed]);

  useEffect(() => {
    showRigRef.current = showRig;
  }, [showRig]);

  useEffect(() => {
    showPhysicsRef.current = showPhysics;
  }, [showPhysics]);

  useEffect(() => {
    clipRef.current = getClip(clipId);
    phaseRef.current = 0;
    setPhase(0);
    setTime(0);
    setActivePhase(0);
    trackerRef.current.reset();
    setReport(null);
    setAuditState("idle");
  }, [clipId]);

  useEffect(() => {
    let cancelled = false;
    verifySourceHash().then((result) => {
      if (cancelled) return;
      setSourceHash(result.hash || SOURCE_HASH);
      setSourceVerified(result.verified);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const renderer = new CharacterRenderer(canvas);
    rendererRef.current = renderer;
    let cancelled = false;
    let raf = 0;

    const drawOverlay = (solved: SolvedRig) => {
      const overlay = overlayRef.current;
      if (!overlay) return;
      const width = overlay.clientWidth;
      const height = overlay.clientHeight;
      if (!width || !height) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const pixelWidth = Math.round(width * dpr);
      const pixelHeight = Math.round(height * dpr);
      if (overlay.width !== pixelWidth || overlay.height !== pixelHeight) {
        overlay.width = pixelWidth;
        overlay.height = pixelHeight;
      }
      const context = overlay.getContext("2d");
      if (!context) return;
      context.setTransform(dpr, 0, 0, dpr, 0, 0);
      context.clearRect(0, 0, width, height);
      const toScreen = (point: { x: number; y: number }) => ({ x: point.x * width, y: point.y * height });

      if (showRigRef.current) {
        context.save();
        context.lineCap = "round";
        context.lineJoin = "round";
        for (const bone of solved.bones) {
          if (!bone.parent) continue;
          const parent = solved.bones.find((candidate) => candidate.name === bone.parent);
          if (!parent) continue;
          const start = toScreen(parent.world);
          const end = toScreen(bone.world);
          context.strokeStyle = "rgba(5, 10, 14, .55)";
          context.lineWidth = 4;
          context.beginPath();
          context.moveTo(start.x, start.y);
          context.lineTo(end.x, end.y);
          context.stroke();
          context.strokeStyle = bone.name.startsWith("foot") || bone.name.startsWith("hand") ? "rgba(221, 160, 167, .92)" : "rgba(127, 212, 214, .92)";
          context.lineWidth = 1.5;
          context.beginPath();
          context.moveTo(start.x, start.y);
          context.lineTo(end.x, end.y);
          context.stroke();
        }
        for (const bone of solved.bones) {
          const point = toScreen(bone.world);
          context.beginPath();
          context.arc(point.x, point.y, 2.3, 0, Math.PI * 2);
          context.fillStyle = bone.name === "head" || bone.name === "hair" ? "rgba(221, 160, 167, .95)" : "rgba(127, 212, 214, .95)";
          context.fill();
        }
        context.restore();
      }

      if (showPhysicsRef.current) {
        const groundY = Math.max(solved.footL.toe.y, solved.footR.toe.y);
        const ground = toScreen({ x: 0, y: groundY });
        context.save();
        context.strokeStyle = "rgba(143, 206, 154, .8)";
        context.lineWidth = 2;
        context.beginPath();
        context.moveTo(solved.support.left * width, ground.y);
        context.lineTo(solved.support.right * width, ground.y);
        context.stroke();
        for (const foot of [solved.footL, solved.footR]) {
          const point = toScreen(foot.toe);
          context.beginPath();
          context.arc(point.x, point.y, 4, 0, Math.PI * 2);
          context.fillStyle = foot.contact ? "rgba(143, 206, 154, .95)" : "rgba(210, 177, 110, .85)";
          context.fill();
          context.strokeStyle = "rgba(5, 10, 14, .6)";
          context.lineWidth = 1;
          context.stroke();
        }
        const com = toScreen({ x: solved.com.x, y: groundY });
        context.strokeStyle = "rgba(221, 160, 167, .95)";
        context.lineWidth = 1.5;
        context.beginPath();
        context.moveTo(com.x - 6, com.y);
        context.lineTo(com.x + 6, com.y);
        context.moveTo(com.x, com.y - 6);
        context.lineTo(com.x, com.y + 6);
        context.stroke();
        context.beginPath();
        context.arc(com.x, com.y, 8, 0, Math.PI * 2);
        context.strokeStyle = "rgba(221, 160, 167, .45)";
        context.stroke();
        context.font = "500 9px 'IBM Plex Mono', monospace";
        context.fillStyle = "rgba(143, 206, 154, .9)";
        context.fillText("SUPPORT", solved.support.left * width, ground.y - 8);
        context.fillStyle = "rgba(221, 160, 167, .9)";
        context.fillText("COM", com.x + 10, com.y - 8);
        context.restore();
      }
    };

    const loop = (now: number) => {
      const delta = Math.min((now - lastTimeRef.current) / 1000, 0.1);
      lastTimeRef.current = now;
      if (playingRef.current) {
        phaseRef.current = (phaseRef.current + (delta * speedRef.current) / clipRef.current.duration) % 1;
      }
      const pose = clipRef.current.sample(phaseRef.current);
      const solved = solveRig(pose.rig);
      solvedRef.current = solved;
      poseRef.current = pose;
      renderer.render(solved.bones);
      trackerRef.current.update(solved);
      drawOverlay(solved);
      frameCountRef.current += 1;
      if (now - fpsTimeRef.current > 500) {
        setFps(Math.round((frameCountRef.current * 1000) / (now - fpsTimeRef.current)));
        frameCountRef.current = 0;
        fpsTimeRef.current = now;
      }
      if (now - lastUiRef.current > 100) {
        lastUiRef.current = now;
        const checks = liveChecks(solved, trackerRef.current);
        const index = clipRef.current.phases.findIndex((item) => phaseRef.current >= item.start && phaseRef.current < item.end);
        setPhase(phaseRef.current);
        setTime(pose.time);
        setActivePhase(index < 0 ? 0 : index);
        setLive({
          checks,
          contactL: solved.footL.contact,
          contactR: solved.footR.contact,
          comMargin: solved.support.margin * 170,
          supportLabel: solved.support.label,
          slipCm: trackerRef.current.maxSlip * 170,
          deviation: boneLengthDeviation(solved),
          hairAngle: solved.localAngles.hair,
          coatAngle: solved.localAngles.coat,
        });
      }
      raf = requestAnimationFrame(loop);
    };

    const start = () => {
      if (cancelled) return;
      setRendererReady(true);
      lastTimeRef.current = performance.now();
      fpsTimeRef.current = lastTimeRef.current;
      raf = requestAnimationFrame(loop);
    };

    if (renderer.error) {
      setRenderError(renderer.error);
      start();
    } else {
      renderer
        .loadTexture("/reference/altushka-rig.png")
        .then(start)
        .catch((error: unknown) => {
          if (cancelled) return;
          setRenderError(error instanceof Error ? error.message : "Unable to load the character texture.");
          start();
        });
    }

    return () => {
      cancelled = true;
      cancelAnimationFrame(raf);
      renderer.dispose();
      rendererRef.current = null;
    };
  }, []);

  const togglePlay = useCallback(() => setPlaying((value) => !value), []);

  const changeClip = useCallback((id: ClipId) => {
    setClipId(id);
    setPlaying(true);
  }, []);

  const scrub = useCallback((value: number) => {
    setPlaying(false);
    phaseRef.current = value;
    setPhase(value);
    const pose = clipRef.current.sample(value);
    setTime(pose.time);
    const index = clipRef.current.phases.findIndex((item) => value >= item.start && value < item.end);
    setActivePhase(index < 0 ? 0 : index);
  }, []);

  const jumpToPhase = useCallback((start: number) => {
    setPlaying(false);
    phaseRef.current = start;
    setPhase(start);
    const pose = clipRef.current.sample(start);
    setTime(pose.time);
    const index = clipRef.current.phases.findIndex((item) => start >= item.start && start < item.end);
    setActivePhase(index < 0 ? 0 : index);
  }, []);

  const reset = useCallback(() => {
    setPlaying(false);
    phaseRef.current = 0;
    setPhase(0);
    setTime(0);
    setActivePhase(0);
    trackerRef.current.reset();
    setReport(null);
    setAuditState("idle");
  }, []);

  const runAudit = useCallback(() => {
    setAuditState("running");
    document.getElementById("audit")?.scrollIntoView({ behavior: "smooth", block: "start" });
    window.setTimeout(() => {
      const solved = solvedRef.current;
      if (!solved) {
        setAuditState("error");
        return;
      }
      runFullAudit(clipRef.current, solved, trackerRef.current)
        .then((result) => {
          setReport(result);
          setAuditState("done");
        })
        .catch(() => setAuditState("error"));
    }, 80);
  }, []);

  const downloadSpec = useCallback(() => downloadText(`altushka-${clip.id}-spec.txt`, specText), [clip.id, specText]);
  const downloadReport = useCallback(() => {
    if (report) downloadText(`altushka-${clip.id}-audit.txt`, reportText);
  }, [clip.id, report, reportText]);

  const phaseLabel = clip.phases[activePhase]?.label ?? clip.phases[0].label;
  const checks = report?.checks ?? live?.checks ?? [];

  return (
    <div className="app-shell" id="top">
      <header className="topbar">
        <a className="brand" href="#top" aria-label="Altushka Motion Lab, back to top">
          <span className="brand-mark">A</span>
          <span className="brand-name">
            ALTUSHKA <small>MOTION LAB</small>
          </span>
        </a>

        <div className="clip-switch" role="group" aria-label="Animation clip">
          {CLIPS.map((item) => (
            <button
              key={item.id}
              type="button"
              className={clipId === item.id ? "active" : ""}
              onClick={() => changeClip(item.id)}
              aria-pressed={clipId === item.id}
            >
              {item.id === "idle" ? <Activity size={14} /> : item.id === "march" ? <Footprints size={14} /> : <Hand size={14} />}
              <span>{item.shortName}</span>
            </button>
          ))}
        </div>

        <div className="transport">
          <button className="transport-play" type="button" onClick={togglePlay} aria-label={playing ? "Pause animation" : "Play animation"}>
            {playing ? <Pause size={15} fill="currentColor" /> : <Play size={15} fill="currentColor" />}
          </button>
          <div className="transport-time">
            <span>{time.toFixed(2)}</span>
            <small>/ {clip.duration.toFixed(2)}s</small>
          </div>
          <div className="speed-switch" role="group" aria-label="Playback speed">
            {[0.5, 1, 1.5].map((value) => (
              <button key={value} type="button" className={speed === value ? "active" : ""} onClick={() => setSpeed(value)} aria-pressed={speed === value}>
                {value}×
              </button>
            ))}
          </div>
          <button className="icon-button" type="button" onClick={reset} aria-label="Reset clip">
            <RotateCcw size={15} />
          </button>
        </div>

        <div className="topbar-actions">
          <a className="source-link" href={referenceUrl} target="_blank" rel="noreferrer">
            Source file <ArrowUpRight size={13} />
          </a>
          <button className="audit-button" type="button" onClick={runAudit} disabled={auditState === "running"}>
            <ShieldCheck size={15} />
            <span>{auditState === "running" ? "Auditing..." : "Run audit"}</span>
          </button>
        </div>
      </header>

      <main>
        <section className="workspace" aria-label="Animation workspace">
          <div className="scene">
            <div className="scene-bg" />
            <div className="scene-grid" />
            <div className="scene-glow" />
            <div className="scene-topline">
              <div className="scene-live">
                <span className="live-dot" /> LIVE <small>24 FPS TIMING</small>
              </div>
              <div className="scene-title">
                <span>{clip.name}</span>
                <small>{phaseLabel}</small>
              </div>
              <div className="scene-source">
                <Check size={12} /> SOURCE / UNCHANGED
              </div>
            </div>

            <div className="character-stage">
              <div className="character-shadow" />
              <div className="character-frame">
                <canvas ref={canvasRef} className="character-canvas" aria-label="Animated full-body character" />
                <canvas ref={overlayRef} className="character-overlay" aria-hidden="true" />
                {!rendererReady && !renderError && (
                  <div className="scene-loading">
                    <span className="spinner" /> Loading animation layer
                  </div>
                )}
                {renderError && (
                  <div className="scene-error">
                    <AlertTriangle size={18} />
                    <div>
                      <strong>WebGL2 unavailable</strong>
                      <p>{renderError} The rig and audit still run on the CPU.</p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="scene-ground" />
            <div className="scene-readout">
              <div>
                <span>PHASE</span>
                <strong>{(phase * 100).toFixed(0)}%</strong>
              </div>
              <div>
                <span>CONTACT</span>
                <strong>
                  <i className={live?.contactL ? "on" : ""} />L <i className={live?.contactR ? "on" : ""} />R
                </strong>
              </div>
              <div>
                <span>COM</span>
                <strong>{live ? `${live.comMargin.toFixed(1)} cm` : "—"}</strong>
              </div>
              <div>
                <span>SLIP</span>
                <strong>{live ? `${live.slipCm.toFixed(2)} cm` : "—"}</strong>
              </div>
            </div>
            <div className="scene-toggles">
              <button type="button" className={showRig ? "active" : ""} onClick={() => setShowRig((value) => !value)} aria-pressed={showRig}>
                <Bone size={13} /> Rig
              </button>
              <button type="button" className={showPhysics ? "active" : ""} onClick={() => setShowPhysics((value) => !value)} aria-pressed={showPhysics}>
                <Crosshair size={13} /> Physics
              </button>
            </div>
          </div>

          <aside className="sidebar" aria-label="Animation controls and measurements">
            <div className="sidebar-scroll">
              <div className="clip-header">
                <div className="section-kicker">
                  <span className="short-line" /> ANIMATION LAYER / 01
                </div>
                <h2>{clip.name}</h2>
                <p>{clip.description}</p>
                <div className="clip-meta">
                  <span>{clip.duration.toFixed(2)}s</span>
                  <i />
                  <span>{clip.fps} FPS</span>
                  <i />
                  <span>LOOP</span>
                </div>
              </div>

              <div className="timeline-card">
                <div className="timeline-head">
                  <span>CYCLE TIMELINE</span>
                  <span>
                    {time.toFixed(2)}s / {clip.duration.toFixed(2)}s
                  </span>
                </div>
                <div className="phase-track">
                  {clip.phases.map((item, index) => (
                    <button
                      key={`${item.label}-${index}`}
                      type="button"
                      className={activePhase === index ? "active" : ""}
                      style={{ flex: item.end - item.start }}
                      onClick={() => jumpToPhase(item.start)}
                    >
                      <span>{item.label}</span>
                    </button>
                  ))}
                </div>
                <div className="contact-track" aria-hidden="true">
                  <div className="contact-row left">
                    {graph.data.map((sample, index) =>
                      sample.contactL ? <i key={index} style={{ left: `${(index / (graph.data.length - 1)) * 100}%` }} /> : null,
                    )}
                  </div>
                  <div className="contact-row right">
                    {graph.data.map((sample, index) =>
                      sample.contactR ? <i key={index} style={{ left: `${(index / (graph.data.length - 1)) * 100}%` }} /> : null,
                    )}
                  </div>
                </div>
                <div className="scrubber-row">
                  <button className="play-button" type="button" onClick={togglePlay} aria-label={playing ? "Pause animation" : "Play animation"}>
                    {playing ? <Pause size={15} fill="currentColor" /> : <Play size={15} fill="currentColor" />}
                  </button>
                  <input
                    className="scrubber"
                    type="range"
                    min="0"
                    max="1"
                    step="0.001"
                    value={phase}
                    onChange={(event) => scrub(Number(event.target.value))}
                    aria-label="Scrub animation phase"
                    style={{ "--progress": `${phase * 100}%` } as CSSProperties}
                  />
                  <span className="scrub-value">{(phase * 100).toFixed(0)}%</span>
                </div>
                <div className="timeline-legend">
                  <span>
                    <i className="legend-contact left" /> LEFT CONTACT
                  </span>
                  <span>
                    <i className="legend-contact right" /> RIGHT CONTACT
                  </span>
                  <span>
                    <i className="legend-swing" /> SWING
                  </span>
                </div>
              </div>

              <div className="phase-list">
                {clip.phases.map((item, index) => (
                  <button key={`${item.label}-${index}`} type="button" className={activePhase === index ? "active" : ""} onClick={() => jumpToPhase(item.start)}>
                    <span className="phase-index">0{index + 1}</span>
                    <div>
                      <strong>{item.label}</strong>
                      <small>
                        {(item.start * clip.duration).toFixed(2)}s – {(item.end * clip.duration).toFixed(2)}s
                      </small>
                      <p>{item.description}</p>
                    </div>
                    <ChevronRight size={14} />
                  </button>
                ))}
              </div>

              <div className="metrics-card">
                <div className="metrics-head">
                  <span>LIVE MEASUREMENTS</span>
                  <span className="live-pill">
                    <i /> LIVE
                  </span>
                </div>
                <div className="metrics-grid">
                  <div className="metric">
                    <span>BONE LOCK</span>
                    <strong>{live ? `${(live.deviation * 100).toFixed(3)}%` : "—"}</strong>
                    <small>length deviation</small>
                  </div>
                  <div className="metric">
                    <span>CONTACT SLIP</span>
                    <strong>{live ? `${live.slipCm.toFixed(2)} cm` : "—"}</strong>
                    <small>stance foot drift</small>
                  </div>
                  <div className="metric">
                    <span>COM MARGIN</span>
                    <strong>{live ? `${live.comMargin.toFixed(1)} cm` : "—"}</strong>
                    <small>{live?.supportLabel ?? "support"}</small>
                  </div>
                  <div className="metric">
                    <span>RENDER</span>
                    <strong>{fps} fps</strong>
                    <small>display refresh</small>
                  </div>
                  <div className="metric">
                    <span>HAIR LAG</span>
                    <strong>{live ? `${((live.hairAngle * 180) / Math.PI).toFixed(1)}°` : "—"}</strong>
                    <small>secondary rotation</small>
                  </div>
                  <div className="metric">
                    <span>COAT LAG</span>
                    <strong>{live ? `${((live.coatAngle * 180) / Math.PI).toFixed(1)}°` : "—"}</strong>
                    <small>secondary rotation</small>
                  </div>
                </div>
              </div>

              <div className="toggle-card">
                <div className="toggle-row">
                  <div>
                    <strong>Rig overlay</strong>
                    <small>Show the skeleton and joint chain</small>
                  </div>
                  <button type="button" className={showRig ? "switch on" : "switch"} onClick={() => setShowRig((value) => !value)} aria-pressed={showRig} aria-label="Toggle rig overlay">
                    <span />
                  </button>
                </div>
                <div className="toggle-row">
                  <div>
                    <strong>Physics overlay</strong>
                    <small>Contact points, support, center of mass</small>
                  </div>
                  <button
                    type="button"
                    className={showPhysics ? "switch on" : "switch"}
                    onClick={() => setShowPhysics((value) => !value)}
                    aria-pressed={showPhysics}
                    aria-label="Toggle physics overlay"
                  >
                    <span />
                  </button>
                </div>
              </div>

              <div className="source-card">
                <div className="source-thumb">
                  <img src="/reference/source-preview.jpg" alt="Original full-body source artwork" />
                  <span>SOURCE / UNCHANGED</span>
                </div>
                <div className="source-copy">
                  <strong>Original full-body artwork</strong>
                  <p>The only texture used by the animation layer. No repaint, no rescale, no mesh replacement.</p>
                  <div className="hash-row">
                    <span>SHA-256</span>
                    <code>{sourceHash}</code>
                  </div>
                  <div className="source-status">
                    {sourceVerified === null ? (
                      <>
                        <span className="spinner small" /> Verifying source
                      </>
                    ) : sourceVerified ? (
                      <>
                        <Check size={12} /> Source hash verified
                      </>
                    ) : (
                      <>
                        <AlertTriangle size={12} /> Hash not verified in this context
                      </>
                    )}
                  </div>
                  <div className="source-links">
                    <a href="/reference/altushka.png" target="_blank" rel="noreferrer">
                      Full source <ArrowUpRight size={12} />
                    </a>
                    <a href={referenceUrl} target="_blank" rel="noreferrer">
                      Drive file <ExternalLink size={12} />
                    </a>
                  </div>
                </div>
              </div>

              <button className="run-audit" type="button" onClick={runAudit} disabled={auditState === "running"}>
                <ShieldCheck size={16} /> {auditState === "running" ? "Running audit..." : "Run full audit"} <ArrowRight size={14} />
              </button>
            </div>
          </aside>
        </section>

        <section id="audit" className="brief-section">
          <div className="brief-inner">
            <div className="brief-header">
              <div>
                <div className="section-kicker">
                  <span className="short-line" /> 02 / TECHNICAL BRIEF
                </div>
                <h2>
                  Motion, <em>measured.</em>
                </h2>
              </div>
              <p>The animation layer only. The source character, texture, mesh, clothing, and proportions are untouched.</p>
            </div>

            <div className="brief-grid">
              <div className="spec-panel">
                <div className="panel-head">
                  <div>
                    <span className="section-kicker">ACTIVE CLIP / {clip.shortName.toUpperCase()}</span>
                    <h3>{clip.name}</h3>
                  </div>
                  <div className="spec-stamp">
                    24 FPS<small>LOOP</small>
                  </div>
                </div>
                <p className="spec-intent">{clip.spec.intent}</p>
                <div className="spec-list">
                  <div className="spec-item">
                    <span>WEIGHT &amp; BALANCE</span>
                    <p>{clip.spec.weight}</p>
                  </div>
                  <div className="spec-item">
                    <span>KINETIC CHAIN</span>
                    <p>{clip.spec.chain}</p>
                  </div>
                  <div className="spec-item">
                    <span>SECONDARY MOTION</span>
                    <p>{clip.spec.secondary}</p>
                  </div>
                  <div className="spec-item">
                    <span>ANTICIPATION / FOLLOW-THROUGH</span>
                    <p>{clip.spec.anticipation}</p>
                  </div>
                  <div className="spec-item">
                    <span>CONTACT &amp; CURVES</span>
                    <p>{clip.spec.contact}</p>
                  </div>
                </div>

                <div className="phase-breakdown">
                  <div className="subhead">
                    <span>PHASE BREAKDOWN</span>
                    <span>FRAME RANGES</span>
                  </div>
                  {clip.phases.map((item, index) => (
                    <div className="breakdown-row" key={`${item.label}-${index}`}>
                      <span className="breakdown-index">0{index + 1}</span>
                      <div>
                        <strong>{item.label}</strong>
                        <small>
                          {(item.start * clip.duration * clip.fps).toFixed(0)}–{(item.end * clip.duration * clip.fps).toFixed(0)}f
                        </small>
                        <p>{item.description}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="constraint-box">
                  <div className="subhead">
                    <span>NON-NEGOTIABLE</span>
                    <span>LOCKED</span>
                  </div>
                  <ul>
                    <li>
                      <Check size={13} /> Original local bone scales and lengths stay fixed.
                    </li>
                    <li>
                      <Check size={13} /> No stretch IK, mesh scaling, or bone elongation.
                    </li>
                    <li>
                      <Check size={13} /> Planted heel, sole, or toe stays fixed in world space.
                    </li>
                    <li>
                      <Check size={13} /> Source texture, mesh, clothing, and anatomy are untouched.
                    </li>
                  </ul>
                </div>

                <div className="source-note">
                  <Info size={14} />
                  <p>
                    The supplied archive contains 2D artwork and procedural mesh motion, not a skeletal rig. This lab adds an animation layer to the
                    full-body source; the joint-level instructions are conditional on a compatible rig.
                  </p>
                </div>

                <div className="spec-actions">
                  <button type="button" onClick={downloadSpec}>
                    <Download size={14} /> Download spec
                  </button>
                  <button type="button" onClick={reset}>
                    <RotateCcw size={14} /> Back to first frame
                  </button>
                </div>
              </div>

              <div className="audit-panel">
                <div className="panel-head">
                  <div>
                    <span className="section-kicker">AUDIT / LIVE + FULL</span>
                    <h3>Does it hold up?</h3>
                  </div>
                  <button className="audit-run" type="button" onClick={runAudit} disabled={auditState === "running"}>
                    <ShieldCheck size={15} /> {auditState === "running" ? "Running..." : "Run audit"}
                  </button>
                </div>
                <div className="audit-state-row">
                  <span className={`audit-state ${auditState}`}>
                    {auditState === "running"
                      ? "Computing edge strain and loop seam..."
                      : auditState === "done"
                        ? "Full audit complete"
                        : auditState === "error"
                          ? "Audit could not complete"
                          : "Live checks are running"}
                  </span>
                  {report && <span className="audit-time">{new Date(report.timestamp).toLocaleTimeString()}</span>}
                </div>

                <div className="check-list">
                  {checks.map((check) => (
                    <div className="check-row" key={check.id}>
                      <div className={`check-icon ${check.status}`}>
                        {check.status === "pass" ? <Check size={13} /> : check.status === "warn" ? <AlertTriangle size={13} /> : <X size={13} />}
                      </div>
                      <div className="check-copy">
                        <div>
                          <strong>{check.label}</strong>
                          <span className={`status ${check.status}`}>{check.status}</span>
                        </div>
                        <p>{check.detail}</p>
                      </div>
                      <div className="check-value">{check.value}</div>
                    </div>
                  ))}
                  {!checks.length && <div className="check-empty">Waiting for the first animation frame...</div>}
                </div>

                <div className="audit-metrics">
                  <div>
                    <span>EDGE STRAIN</span>
                    <strong>{report ? `${(report.edgeStrain.max * 100).toFixed(2)}%` : "—"}</strong>
                    <small>max / {report ? `${(report.edgeStrain.mean * 100).toFixed(3)}%` : "run audit"}</small>
                  </div>
                  <div>
                    <span>LOOP SEAM</span>
                    <strong>{report ? `${(report.loopSeam.position * 1000).toFixed(2)} mm` : "—"}</strong>
                    <small>{report ? `${((report.loopSeam.angle * 180) / Math.PI).toFixed(2)}°` : "run audit"}</small>
                  </div>
                  <div>
                    <span>KINETIC CHAIN</span>
                    <strong>{report ? formatChain(report.kineticChain) : "—"}</strong>
                    <small>propagation lag</small>
                  </div>
                  <div>
                    <span>SOURCE HASH</span>
                    <strong>{report?.sourceHashVerified ? "verified" : "pending"}</strong>
                    <small>{report?.sourceHash.slice(0, 16) ?? sourceHash.slice(0, 16)}…</small>
                  </div>
                </div>

                <div className="graph-card">
                  <div className="graph-head">
                    <span>VELOCITY / CONTACT</span>
                    <div className="graph-legend">
                      <span>
                        <i className="legend-hand" /> HAND
                      </span>
                      <span>
                        <i className="legend-foot" /> FOOT
                      </span>
                      <span>
                        <i className="legend-contact left" /> L CONTACT
                      </span>
                      <span>
                        <i className="legend-contact right" /> R CONTACT
                      </span>
                    </div>
                  </div>
                  <svg className="velocity-graph" viewBox="0 0 600 150" role="img" aria-label="Hand and foot velocity curves with contact intervals">
                    {[0, 1, 2, 3, 4].map((line) => (
                      <line key={line} x1="0" y1={20 + line * 22} x2="600" y2={20 + line * 22} className="graph-grid" />
                    ))}
                    {graph.data.map((sample, index) =>
                      sample.contactL ? (
                        <rect
                          key={`l${index}`}
                          x={(index / (graph.data.length - 1)) * 600}
                          y="112"
                          width={600 / (graph.data.length - 1) + 0.5}
                          height="7"
                          className="contact-left"
                        />
                      ) : null,
                    )}
                    {graph.data.map((sample, index) =>
                      sample.contactR ? (
                        <rect
                          key={`r${index}`}
                          x={(index / (graph.data.length - 1)) * 600}
                          y="122"
                          width={600 / (graph.data.length - 1) + 0.5}
                          height="7"
                          className="contact-right"
                        />
                      ) : null,
                    )}
                    <polyline
                      className="graph-hand"
                      points={graph.data
                        .map((sample, index) => `${(index / (graph.data.length - 1)) * 600},${110 - (sample.handSpeed / graph.maxSpeed) * 85}`)
                        .join(" ")}
                    />
                    <polyline
                      className="graph-foot"
                      points={graph.data
                        .map((sample, index) => `${(index / (graph.data.length - 1)) * 600},${110 - (sample.footSpeed / graph.maxSpeed) * 85}`)
                        .join(" ")}
                    />
                    <line x1="0" y1="110" x2="600" y2="110" className="graph-axis" />
                    <text x="0" y="145" className="graph-label">
                      0%
                    </text>
                    <text x="280" y="145" className="graph-label">
                      50%
                    </text>
                    <text x="570" y="145" className="graph-label">
                      100%
                    </text>
                  </svg>
                  <p className="graph-note">
                    Hand and foot speed are measured from the solved rig. Contact intervals are sampled from the clip; the stance foot is fixed in
                    world space.
                  </p>
                </div>

                <div className="audit-actions">
                  <button type="button" onClick={downloadReport} disabled={!report}>
                    <Download size={14} /> Download audit
                  </button>
                  <button type="button" onClick={runAudit} disabled={auditState === "running"}>
                    <RotateCcw size={14} /> Re-run
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <a className="footer-brand" href="#top">
          <span>A</span> ALTUSHKA / MOTION LAB
        </a>
        <span className="footer-note">ANIMATION LAYER ONLY · SOURCE MODEL UNCHANGED</span>
        <span className="footer-hash">SHA-256 {sourceHash.slice(0, 24)}…</span>
        <a href="#top">
          BACK TO TOP <ArrowRight size={12} />
        </a>
      </footer>
    </div>
  );
}
