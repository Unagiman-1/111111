import { computeMeshWeights, type BoneTransform } from "./rig";

const COLS = 64;
const ROWS = 96;
const MAX_BONES = 24;

const VERTEX_SHADER = `#version 300 es
precision highp float;
in vec2 a_position;
in vec2 a_uv;
in vec4 a_boneIndices;
in vec4 a_boneWeights;
uniform vec4 u_qr[${MAX_BONES}];
uniform vec4 u_qd[${MAX_BONES}];
out vec2 v_uv;

vec4 qmul(vec4 a, vec4 b) {
  return vec4(
    a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
    a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
    a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w,
    a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z
  );
}

vec3 qrotate(vec3 v, vec4 q) {
  vec3 t = 2.0 * cross(q.xyz, v);
  return v + q.w * t + cross(q.xyz, t);
}

void main() {
  vec4 qr = vec4(0.0);
  vec4 qd = vec4(0.0);
  for (int i = 0; i < 4; i++) {
    int index = int(a_boneIndices[i]);
    float weight = a_boneWeights[i];
    qr += u_qr[index] * weight;
    qd += u_qd[index] * weight;
  }
  qr = normalize(qr);
  vec4 translation = 2.0 * qmul(qd, vec4(-qr.x, -qr.y, -qr.z, qr.w));
  vec3 p = qrotate(vec3(a_position, 0.0), qr) + translation.xyz;
  gl_Position = vec4(p.x * 2.0 - 1.0, 1.0 - p.y * 2.0, 0.0, 1.0);
  v_uv = a_uv;
}
`;

const FRAGMENT_SHADER = `#version 300 es
precision mediump float;
in vec2 v_uv;
uniform sampler2D u_texture;
out vec4 outColor;
void main() {
  outColor = texture(u_texture, v_uv);
}
`;

const compileShader = (gl: WebGL2RenderingContext, type: number, source: string) => {
  const shader = gl.createShader(type);
  if (!shader) throw new Error("Unable to create shader");
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    const log = gl.getShaderInfoLog(shader);
    gl.deleteShader(shader);
    throw new Error(`Shader compile failed: ${log ?? "unknown error"}`);
  }
  return shader;
};

const createProgram = (gl: WebGL2RenderingContext) => {
  const vertex = compileShader(gl, gl.VERTEX_SHADER, VERTEX_SHADER);
  const fragment = compileShader(gl, gl.FRAGMENT_SHADER, FRAGMENT_SHADER);
  const program = gl.createProgram();
  if (!program) throw new Error("Unable to create program");
  gl.attachShader(program, vertex);
  gl.attachShader(program, fragment);
  gl.linkProgram(program);
  gl.deleteShader(vertex);
  gl.deleteShader(fragment);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    const log = gl.getProgramInfoLog(program);
    gl.deleteProgram(program);
    throw new Error(`Program link failed: ${log ?? "unknown error"}`);
  }
  return program;
};

type MeshData = {
  vertexBuffer: WebGLBuffer;
  indexBuffer: WebGLBuffer;
  indexCount: number;
  positionLocation: number;
  uvLocation: number;
  boneIndexLocation: number;
  boneWeightLocation: number;
};

export class CharacterRenderer {
  readonly canvas: HTMLCanvasElement;
  private gl: WebGL2RenderingContext | null = null;
  private program: WebGLProgram | null = null;
  private mesh: MeshData | null = null;
  private texture: WebGLTexture | null = null;
  private qrLocation: WebGLUniformLocation | null = null;
  private qdLocation: WebGLUniformLocation | null = null;
  private textureLocation: WebGLUniformLocation | null = null;
  private qrData = new Float32Array(MAX_BONES * 4);
  private qdData = new Float32Array(MAX_BONES * 4);
  private lastWidth = 0;
  private lastHeight = 0;
  private ready = false;
  error: string | null = null;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const gl = canvas.getContext("webgl2", {
      alpha: true,
      premultipliedAlpha: true,
      antialias: true,
      depth: false,
      stencil: false,
      preserveDrawingBuffer: false,
    });
    if (!gl) {
      this.error = "WebGL2 is unavailable in this browser.";
      return;
    }
    this.gl = gl;
    try {
      this.program = createProgram(gl);
      this.qrLocation = gl.getUniformLocation(this.program, "u_qr[0]");
      this.qdLocation = gl.getUniformLocation(this.program, "u_qd[0]");
      this.textureLocation = gl.getUniformLocation(this.program, "u_texture");
      this.mesh = this.createMesh(gl);
      gl.disable(gl.DEPTH_TEST);
      gl.disable(gl.CULL_FACE);
      gl.enable(gl.BLEND);
      gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
      gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
      this.ready = true;
    } catch (error) {
      this.error = error instanceof Error ? error.message : "Unable to initialize the renderer.";
      this.gl = null;
    }
  }

  private createMesh(gl: WebGL2RenderingContext): MeshData {
    const vertexCount = (COLS + 1) * (ROWS + 1);
    const weights = computeMeshWeights(COLS, ROWS);
    const data = new Float32Array(vertexCount * 12);
    let cursor = 0;
    for (let row = 0; row <= ROWS; row++) {
      for (let col = 0; col <= COLS; col++) {
        const u = col / COLS;
        const v = row / ROWS;
        const weight = weights[row * (COLS + 1) + col];
        data[cursor++] = u;
        data[cursor++] = v;
        data[cursor++] = u;
        data[cursor++] = v;
        data[cursor++] = weight.indices[0];
        data[cursor++] = weight.indices[1];
        data[cursor++] = weight.indices[2];
        data[cursor++] = weight.indices[3];
        data[cursor++] = weight.weights[0];
        data[cursor++] = weight.weights[1];
        data[cursor++] = weight.weights[2];
        data[cursor++] = weight.weights[3];
      }
    }
    const indices = new Uint16Array(COLS * ROWS * 6);
    let indexCursor = 0;
    for (let row = 0; row < ROWS; row++) {
      for (let col = 0; col < COLS; col++) {
        const a = row * (COLS + 1) + col;
        const b = a + 1;
        const c = a + COLS + 1;
        const d = c + 1;
        const boneA = weights[a].indices[0];
        const boneB = weights[b].indices[0];
        const boneC = weights[c].indices[0];
        const boneD = weights[d].indices[0];
        if (boneA !== boneB || boneA !== boneC || boneA !== boneD) continue;
        indices[indexCursor++] = a;
        indices[indexCursor++] = b;
        indices[indexCursor++] = c;
        indices[indexCursor++] = b;
        indices[indexCursor++] = d;
        indices[indexCursor++] = c;
      }
    }
    const vertexBuffer = gl.createBuffer();
    const indexBuffer = gl.createBuffer();
    if (!vertexBuffer || !indexBuffer) throw new Error("Unable to allocate mesh buffers");
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indices, gl.STATIC_DRAW);
    if (!this.program) throw new Error("Program unavailable");
    const positionLocation = gl.getAttribLocation(this.program, "a_position");
    const uvLocation = gl.getAttribLocation(this.program, "a_uv");
    const boneIndexLocation = gl.getAttribLocation(this.program, "a_boneIndices");
    const boneWeightLocation = gl.getAttribLocation(this.program, "a_boneWeights");
    return { vertexBuffer, indexBuffer, indexCount: indexCursor, positionLocation, uvLocation, boneIndexLocation, boneWeightLocation };
  }

  async loadTexture(source: string): Promise<void> {
    const gl = this.gl;
    if (!gl) return;
    const image = new Image();
    image.decoding = "async";
    image.src = source;
    await image.decode();
    const texture = gl.createTexture();
    if (!texture) throw new Error("Unable to create texture");
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
    this.texture = texture;
  }

  private resize() {
    const gl = this.gl;
    if (!gl) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.max(1, Math.round(this.canvas.clientWidth * dpr));
    const height = Math.max(1, Math.round(this.canvas.clientHeight * dpr));
    if (width !== this.lastWidth || height !== this.lastHeight) {
      this.canvas.width = width;
      this.canvas.height = height;
      this.lastWidth = width;
      this.lastHeight = height;
    }
    gl.viewport(0, 0, width, height);
  }

  render(transforms: BoneTransform[]) {
    const gl = this.gl;
    if (!gl || !this.program || !this.mesh || !this.texture || !this.ready) return;
    this.resize();
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.useProgram(this.program);
    for (let index = 0; index < MAX_BONES; index++) {
      const transform = transforms[index];
      const dual = transform?.dual ?? { real: { x: 0, y: 0, z: 0, w: 1 }, dual: { x: 0, y: 0, z: 0, w: 0 } };
      const offset = index * 4;
      this.qrData[offset] = dual.real.x;
      this.qrData[offset + 1] = dual.real.y;
      this.qrData[offset + 2] = dual.real.z;
      this.qrData[offset + 3] = dual.real.w;
      this.qdData[offset] = dual.dual.x;
      this.qdData[offset + 1] = dual.dual.y;
      this.qdData[offset + 2] = dual.dual.z;
      this.qdData[offset + 3] = dual.dual.w;
    }
    if (this.qrLocation) gl.uniform4fv(this.qrLocation, this.qrData);
    if (this.qdLocation) gl.uniform4fv(this.qdLocation, this.qdData);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, this.texture);
    if (this.textureLocation) gl.uniform1i(this.textureLocation, 0);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.mesh.vertexBuffer);
    const stride = 12 * 4;
    gl.enableVertexAttribArray(this.mesh.positionLocation);
    gl.vertexAttribPointer(this.mesh.positionLocation, 2, gl.FLOAT, false, stride, 0);
    gl.enableVertexAttribArray(this.mesh.uvLocation);
    gl.vertexAttribPointer(this.mesh.uvLocation, 2, gl.FLOAT, false, stride, 2 * 4);
    gl.enableVertexAttribArray(this.mesh.boneIndexLocation);
    gl.vertexAttribPointer(this.mesh.boneIndexLocation, 4, gl.FLOAT, false, stride, 4 * 4);
    gl.enableVertexAttribArray(this.mesh.boneWeightLocation);
    gl.vertexAttribPointer(this.mesh.boneWeightLocation, 4, gl.FLOAT, false, stride, 8 * 4);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.mesh.indexBuffer);
    gl.drawElements(gl.TRIANGLES, this.mesh.indexCount, gl.UNSIGNED_SHORT, 0);
  }

  dispose() {
    const gl = this.gl;
    if (!gl) return;
    if (this.mesh) {
      gl.deleteBuffer(this.mesh.vertexBuffer);
      gl.deleteBuffer(this.mesh.indexBuffer);
    }
    if (this.texture) gl.deleteTexture(this.texture);
    if (this.program) gl.deleteProgram(this.program);
    this.mesh = null;
    this.texture = null;
    this.program = null;
    this.gl = null;
  }
}
