import { clamp, easeInOut, fract, lerp, smoothstep, TAU } from "./math";
import type { RigPose } from "./rig";

export type ClipId = "idle" | "march" | "reach";

export type Pose = {
  rig: RigPose;
  clipId: ClipId;
  phase: number;
  time: number;
  label: string;
  secondaryLagFrames: number;
  anticipationFrames: number;
  followThroughFrames: number;
  notes: string;
};

export type ClipPhase = {
  label: string;
  start: number;
  end: number;
  description: string;
};

export type Clip = {
  id: ClipId;
  name: string;
  shortName: string;
  description: string;
  duration: number;
  fps: number;
  loop: boolean;
  sample: (phase: number) => Pose;
  phases: ClipPhase[];
  spec: {
    intent: string;
    weight: string;
    chain: string;
    secondary: string;
    anticipation: string;
    contact: string;
  };
};

const GROUND_Y = 0.96;
const ROOT_Y = 0.58;
const IDLE_L = { x: 0.34, y: GROUND_Y };
const IDLE_R = { x: 0.79, y: GROUND_Y };
const MARCH_L = { x: 0.42, y: GROUND_Y };
const MARCH_R = { x: 0.58, y: GROUND_Y };
const MARCH_LIFT = 0.06;
const MARCH_SWING_X = 0.5;
const REST_L_WRIST = { x: 0.23, y: 0.56 };
const REST_R_WRIST = { x: 0.77, y: 0.56 };
const CHEST_TARGET = { x: 0.62, y: 0.42 };

const baseRig = (): RigPose => ({
  root: { x: 0.5, y: ROOT_Y },
  rootAngle: 0,
  spineAngle: 0,
  chestAngle: 0,
  neckAngle: 0,
  headAngle: 0,
  hairAngle: 0,
  coatAngle: 0,
  shoulderLAngle: 0,
  shoulderRAngle: 0,
  handLTarget: { ...REST_L_WRIST },
  handRTarget: { ...REST_R_WRIST },
  handLAngle: 0,
  handRAngle: 0,
  footLTarget: { ...IDLE_L },
  footRTarget: { ...IDLE_R },
  footLAngle: 0,
  footRAngle: 0,
  contactL: true,
  contactR: true,
});

const idleHeadAngle = (phase: number, shift: number) =>
  0.022 * Math.sin(TAU * phase + 0.4) + 0.012 * shift + 0.006 * Math.sin(TAU * phase * 2 + 1.1);
const idleHipsAngle = (phase: number, shift: number) => 0.02 * shift + 0.004 * Math.sin(TAU * phase * 2 + 0.3);

const idleSample = (phase: number): Pose => {
  const rig = baseRig();
  const shift = Math.sin(TAU * phase);
  const breath = Math.cos(TAU * phase);
  rig.root = { x: 0.5 + 0.035 * shift, y: ROOT_Y + 0.003 * breath };
  rig.rootAngle = idleHipsAngle(phase, shift);
  rig.spineAngle = -0.016 * shift;
  rig.chestAngle = -0.01 * Math.sin(TAU * (phase - 0.04)) + 0.004 * Math.cos(TAU * (phase - 0.04));
  rig.neckAngle = 0.006 * Math.sin(TAU * (phase - 0.06));
  rig.headAngle = idleHeadAngle(phase - 0.08, shift);
  const lagPhase = 0.12 / 6;
  rig.hairAngle = -0.42 * idleHeadAngle(fract(phase - lagPhase), Math.sin(TAU * (phase - lagPhase))) + 0.008 * Math.sin(TAU * phase * 2 + 1.2);
  rig.coatAngle = -0.3 * idleHipsAngle(fract(phase - lagPhase), Math.sin(TAU * (phase - lagPhase))) + 0.006 * Math.sin(TAU * phase * 2 + 0.5);
  rig.shoulderLAngle = 0.008 * Math.sin(TAU * phase + 0.2);
  rig.shoulderRAngle = 0.008 * Math.sin(TAU * phase + 0.9);
  const adjust = Math.exp(-Math.pow((phase - 0.68) / 0.075, 2));
  rig.handLTarget = {
    x: REST_L_WRIST.x + 0.004 * Math.sin(TAU * phase + 0.5),
    y: REST_L_WRIST.y + 0.003 * Math.cos(TAU * phase),
  };
  rig.handRTarget = {
    x: REST_R_WRIST.x - 0.022 * adjust + 0.004 * Math.sin(TAU * phase + 1.1),
    y: REST_R_WRIST.y - 0.035 * adjust + 0.003 * Math.cos(TAU * phase + 0.8),
  };
  rig.handLAngle = 0.05 * Math.sin(TAU * phase + 0.3);
  rig.handRAngle = 0.05 * Math.sin(TAU * phase + 1.0) + 0.12 * adjust;
  rig.footLTarget = { ...IDLE_L };
  rig.footRTarget = { ...IDLE_R };
  rig.footLAngle = 0;
  rig.footRAngle = 0;
  rig.contactL = true;
  rig.contactR = true;
  return {
    rig,
    clipId: "idle",
    phase,
    time: phase * 6,
    label: shift >= 0 ? "Weight over left support" : "Weight over right support",
    secondaryLagFrames: 2.9,
    anticipationFrames: 3.2,
    followThroughFrames: 4.1,
    notes: "Both feet stay locked. The pelvis leads; the ribcage counter-rotates; the head and coat settle after the weight transfer.",
  };
};

const marchHipsAngle = (phase: number) => 0.022 * Math.sin(TAU * phase) + 0.006 * Math.sin(TAU * phase * 2 + 0.4);
const marchHeadAngle = (phase: number) => 0.012 * Math.sin(TAU * phase + 0.5) + 0.004 * Math.sin(TAU * phase * 2 + 1.2);

const marchSample = (phase: number): Pose => {
  const rig = baseRig();
  const leftStance = phase < 0.6;
  const rightStance = phase >= 0.5 || phase < 0.1;
  const leftSwing = phase >= 0.6;
  const rightSwing = phase >= 0.1 && phase < 0.5;
  const leftSwingPhase = leftSwing ? (phase - 0.6) / 0.4 : 0;
  const rightSwingPhase = rightSwing ? (phase - 0.1) / 0.4 : 0;
  const leftLift = leftSwing ? Math.sin(Math.PI * leftSwingPhase) : 0;
  const rightLift = rightSwing ? Math.sin(Math.PI * rightSwingPhase) : 0;
  const leftFoot = leftSwing
    ? { x: lerp(MARCH_L.x, MARCH_SWING_X, leftLift), y: GROUND_Y - MARCH_LIFT * leftLift }
    : { ...MARCH_L };
  const rightFoot = rightSwing
    ? { x: lerp(MARCH_R.x, MARCH_SWING_X, rightLift), y: GROUND_Y - MARCH_LIFT * rightLift }
    : { ...MARCH_R };

  let rootX: number;
  if (phase < 0.1) rootX = lerp(0.6, 0.4, easeInOut(phase / 0.1));
  else if (phase < 0.5) rootX = 0.4;
  else if (phase < 0.6) rootX = lerp(0.4, 0.6, easeInOut((phase - 0.5) / 0.1));
  else rootX = 0.6;

  const bob = 0.005 * Math.cos(TAU * phase);
  rig.root = { x: rootX, y: ROOT_Y + bob };
  rig.rootAngle = marchHipsAngle(phase);
  rig.spineAngle = -0.018 * Math.sin(TAU * phase);
  rig.chestAngle = -0.012 * Math.sin(TAU * (phase - 0.04)) + 0.004 * Math.cos(TAU * (phase - 0.04) * 2);
  rig.neckAngle = 0.005 * Math.sin(TAU * (phase - 0.06) + 0.4);
  rig.headAngle = marchHeadAngle(phase - 0.08);
  const lagPhase = 0.08 / 1;
  rig.hairAngle = -0.45 * marchHeadAngle(fract(phase - lagPhase)) + 0.01 * Math.sin(TAU * phase * 2 + 1.2);
  rig.coatAngle = -0.32 * marchHipsAngle(fract(phase - lagPhase)) + 0.008 * Math.sin(TAU * phase * 2 + 0.5);
  rig.shoulderLAngle = 0.012 * Math.sin(TAU * phase + 0.2);
  rig.shoulderRAngle = 0.012 * Math.sin(TAU * phase + 0.9);
  rig.handLTarget = {
    x: REST_L_WRIST.x - 0.022 * Math.cos(TAU * phase),
    y: REST_L_WRIST.y + 0.008 * Math.sin(TAU * phase + 0.4),
  };
  rig.handRTarget = {
    x: REST_R_WRIST.x + 0.022 * Math.cos(TAU * phase),
    y: REST_R_WRIST.y + 0.008 * Math.sin(TAU * phase + 0.9),
  };
  rig.handLAngle = 0.06 * Math.sin(TAU * phase + 0.3);
  rig.handRAngle = 0.06 * Math.sin(TAU * phase + 1.0);
  rig.footLTarget = leftFoot;
  rig.footRTarget = rightFoot;
  rig.footLAngle = leftSwing ? 0.16 * Math.sin(Math.PI * leftSwingPhase) : 0;
  rig.footRAngle = rightSwing ? 0.16 * Math.sin(Math.PI * rightSwingPhase) : 0;
  rig.contactL = leftStance;
  rig.contactR = rightStance;
  return {
    rig,
    clipId: "march",
    phase,
    time: phase * 1,
    label: leftStance ? "Left support / right swing" : "Right support / left swing",
    secondaryLagFrames: 1.9,
    anticipationFrames: 2.4,
    followThroughFrames: 2.4,
    notes: "A grounded march in place. The pelvis shifts over the planted foot during double support; the swing foot clears the floor without changing leg length.",
  };
};

const reachSample = (phase: number): Pose => {
  const rig = baseRig();
  const shift = Math.sin(TAU * phase);
  rig.root = { x: 0.5 + 0.008 * shift, y: ROOT_Y + 0.003 * Math.cos(TAU * phase) };
  rig.rootAngle = 0.012 * shift;
  rig.spineAngle = -0.01 * shift;
  rig.chestAngle = -0.012 * shift;
  rig.neckAngle = 0.004 * shift;
  rig.headAngle = 0.012 * Math.sin(TAU * phase + 0.4) + 0.04 * smoothstep(0.12, 0.3, phase) * (1 - smoothstep(0.7, 0.9, phase));
  const lagPhase = 0.12 / 4;
  rig.hairAngle = -0.42 * (0.012 * Math.sin(TAU * (phase - lagPhase) + 0.4) + 0.04 * smoothstep(0.12, 0.3, phase - lagPhase) * (1 - smoothstep(0.7, 0.9, phase - lagPhase))) + 0.008 * Math.sin(TAU * phase * 2 + 1.2);
  rig.coatAngle = -0.3 * 0.012 * Math.sin(TAU * (phase - lagPhase)) + 0.006 * Math.sin(TAU * phase * 2 + 0.5);
  rig.shoulderLAngle = 0.006 * Math.sin(TAU * phase + 0.2);
  rig.shoulderRAngle = 0.028 * smoothstep(0.05, 0.16, phase) * (1 - smoothstep(0.72, 0.9, phase));

  const reachIn = smoothstep(0.16, 0.34, phase);
  const reachOut = 1 - smoothstep(0.58, 0.8, phase);
  const reach = reachIn * reachOut;
  const adjustWindow = smoothstep(0.34, 0.4, phase) * (1 - smoothstep(0.52, 0.58, phase));
  const adjust = Math.sin(TAU * (phase - 0.34) / 0.24) * adjustWindow;
  rig.handRTarget = {
    x: lerp(REST_R_WRIST.x, CHEST_TARGET.x, reach) + 0.008 * adjust,
    y: lerp(REST_R_WRIST.y, CHEST_TARGET.y, reach) + 0.006 * adjust,
  };
  rig.handLTarget = {
    x: REST_L_WRIST.x + 0.003 * Math.sin(TAU * phase + 0.5),
    y: REST_L_WRIST.y + 0.002 * Math.cos(TAU * phase),
  };
  rig.handLAngle = 0.04 * Math.sin(TAU * phase + 0.3);
  rig.handRAngle = 0.22 * reach + 0.06 * adjust;
  rig.footLTarget = { ...IDLE_L };
  rig.footRTarget = { ...IDLE_R };
  rig.footLAngle = 0;
  rig.footRAngle = 0;
  rig.contactL = true;
  rig.contactR = true;
  return {
    rig,
    clipId: "reach",
    phase,
    time: phase * 4,
    label: reach > 0.2 ? "Right hand at chest / adjusting" : "Settling back to the side",
    secondaryLagFrames: 2.9,
    anticipationFrames: 4.8,
    followThroughFrames: 4.8,
    notes: "The chest and shoulder anticipate before the hand moves. The hand adjusts at the chest, then returns with a small overshoot while the torso settles.",
  };
};

export const CLIPS: Clip[] = [
  {
    id: "idle",
    name: "Living idle",
    shortName: "Idle",
    description: "A six-second weight shift with breathing, a slow look, and a small hand adjustment.",
    duration: 6,
    fps: 24,
    loop: true,
    sample: idleSample,
    phases: [
      { label: "Shift left", start: 0, end: 0.25, description: "The pelvis moves over the left support; the ribcage counter-rotates." },
      { label: "Settle", start: 0.25, end: 0.5, description: "The head and coat settle after the transfer; the feet stay locked." },
      { label: "Shift right", start: 0.5, end: 0.75, description: "Weight returns over the right support; the free hand adjusts." },
      { label: "Settle", start: 0.75, end: 1, description: "The shoulders and head release; the loop returns to the first frame." },
    ],
    spec: {
      intent: "A living idle, not a frozen pose. The character is always transferring weight, breathing, or looking.",
      weight: "The pelvis leads the weight shift by about 3.5% of body height. The center of mass stays inside the support interval; the feet never slide.",
      chain: "Hips → spine → chest → neck → head. The ribcage counter-rotates against the pelvis; the head stabilizes with a small delayed look.",
      secondary: "Hair and coat follow the head and pelvis with a 2.9-frame delay, driven by a damped follow-through. No independent controls are invented.",
      anticipation: "The head begins its look 3.2 frames before the hand adjustment; the shoulder lifts before the hand moves.",
      contact: "Both feet remain planted. The ankles and toes are fixed in world space; the knees and hips absorb the weight shift.",
    },
  },
  {
    id: "march",
    name: "Grounded march",
    shortName: "March",
    description: "A one-second march in place with double support, a clear swing phase, and a locked stance foot.",
    duration: 1,
    fps: 24,
    loop: true,
    sample: marchSample,
    phases: [
      { label: "Left contact", start: 0, end: 0.1, description: "The left foot contacts; the weight is still over the right foot." },
      { label: "Left support", start: 0.1, end: 0.5, description: "The pelvis travels over the left foot; the right leg swings through." },
      { label: "Right contact", start: 0.5, end: 0.6, description: "The right foot contacts; the weight transfers across double support." },
      { label: "Right support", start: 0.6, end: 1, description: "The pelvis travels over the right foot; the left leg swings through." },
    ],
    spec: {
      intent: "A grounded march in place. The source is front-facing, so the cycle shows the mechanics of contact, support, and swing without translating the root.",
      weight: "The pelvis shifts over the planted foot during double support. The center of mass stays inside the support interval; the swing leg is unloaded.",
      chain: "The planted hip leads, the knee follows, and the ankle stays locked. The pelvis rotates, the spine counter-rotates, and the arms swing opposite the legs.",
      secondary: "Hair and coat lag the head and pelvis by 1.9 frames. The swing foot's toe-off is a rotation, not a stretch.",
      anticipation: "The weight begins shifting 2.4 frames before the next contact; the swing foot accelerates away from the ground.",
      contact: "The stance foot is fixed in world space. The swing foot clears the floor by 6% of body height and lands with zero horizontal velocity.",
    },
  },
  {
    id: "reach",
    name: "Reach & adjust",
    shortName: "Reach",
    description: "A four-second action: anticipate, reach to the chest, adjust, and settle back with follow-through.",
    duration: 4,
    fps: 24,
    loop: true,
    sample: reachSample,
    phases: [
      { label: "Anticipation", start: 0, end: 0.16, description: "The chest and shoulder prepare; the hand is still at the side." },
      { label: "Reach", start: 0.16, end: 0.34, description: "The hand travels to the chest; the elbow folds; the head looks down." },
      { label: "Adjust", start: 0.34, end: 0.58, description: "The hand makes a small adjustment at the chest; the torso holds." },
      { label: "Return", start: 0.58, end: 1, description: "The hand returns with follow-through; the torso and head settle." },
    ],
    spec: {
      intent: "A small, believable action with a clear beginning, middle, and end. The feet stay planted while the upper body does the work.",
      weight: "The weight remains over the support interval. The chest and shoulder shift toward the acting side; the hips do not chase the hand.",
      chain: "Chest → shoulder → elbow → wrist → hand. The elbow folds first, the wrist follows, and the hand arrives last. The head looks down after the hand starts.",
      secondary: "The hair and coat lag the head and chest by 2.9 frames. The hand's return overshoots slightly before the torso settles.",
      anticipation: "The chest and shoulder start 4.8 frames before the hand. The hand does not lead the body.",
      contact: "Both feet stay locked. The arm is a two-bone IK chain with fixed lengths; an unreachable target is clamped, never stretched.",
    },
  },
];

export const getClip = (id: ClipId) => CLIPS.find((clip) => clip.id === id) ?? CLIPS[0];

export const clipPhaseLabel = (clip: Clip, phase: number) => {
  const found = clip.phases.find((item) => phase >= item.start && phase < item.end);
  return found?.label ?? clip.phases[clip.phases.length - 1].label;
};

export const clampPhase = (phase: number) => clamp(fract(phase), 0, 0.999999);
