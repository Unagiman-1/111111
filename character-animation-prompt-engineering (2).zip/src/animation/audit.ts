import { distance, transformPoint } from "./math";
import {
  BONE_INDEX,
  BONES,
  blendBoneDualQuat,
  computeMeshWeights,
  restBoneLength,
  solveRig,
  type BoneTransform,
  type SolvedRig,
} from "./rig";
import type { Clip, Pose } from "./clips";

export const MESH_COLS = 64;
export const MESH_ROWS = 96;
export const SOURCE_HASH = "ddd1010e889c89ca62a008dadf8b55f5cdfc9c3e3a72f0d9b2da87c2042c9e09";
export const SOURCE_URL = "/reference/source-altushka.webp";

const meshWeights = computeMeshWeights(MESH_COLS, MESH_ROWS);
const vertexCount = (MESH_COLS + 1) * (MESH_ROWS + 1);
const restPositions = Array.from({ length: vertexCount }, (_, index) => {
  const row = Math.floor(index / (MESH_COLS + 1));
  const col = index % (MESH_COLS + 1);
  return { x: col / MESH_COLS, y: row / MESH_ROWS };
});

let alphaMaskPromise: Promise<Uint8Array> | null = null;

/**
 * The mesh grid covers the transparent crop as well as the character. Strain is
 * only meaningful on edges inside the original alpha silhouette, so the audit
 * samples the unchanged source texture's alpha at each grid vertex.
 */
export const loadAlphaMask = (): Promise<Uint8Array> => {
  if (alphaMaskPromise) return alphaMaskPromise;
  alphaMaskPromise = new Promise((resolve, reject) => {
    const image = new Image();
    image.decoding = "async";
    image.src = "/reference/altushka-rig.png";
    image.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = image.naturalWidth;
      canvas.height = image.naturalHeight;
      const context = canvas.getContext("2d", { willReadFrequently: true });
      if (!context) {
        reject(new Error("Canvas unavailable for the alpha mask"));
        return;
      }
      context.drawImage(image, 0, 0);
      const data = context.getImageData(0, 0, canvas.width, canvas.height).data;
      const mask = new Uint8Array(vertexCount);
      for (let row = 0; row <= MESH_ROWS; row++) {
        for (let col = 0; col <= MESH_COLS; col++) {
          const x = Math.min(canvas.width - 1, Math.round((col / MESH_COLS) * (canvas.width - 1)));
          const y = Math.min(canvas.height - 1, Math.round((row / MESH_ROWS) * (canvas.height - 1)));
          mask[row * (MESH_COLS + 1) + col] = data[(y * canvas.width + x) * 4 + 3];
        }
      }
      resolve(mask);
    };
    image.onerror = () => reject(new Error("Unable to load the rig texture alpha mask"));
  });
  return alphaMaskPromise;
};

export type CheckStatus = "pass" | "warn" | "fail";

export type AuditCheck = {
  id: string;
  label: string;
  value: string;
  status: CheckStatus;
  detail: string;
};

export type EdgeStrain = {
  max: number;
  mean: number;
  p95: number;
  samples: number;
};

export type LoopSeam = {
  position: number;
  angle: number;
};

export type KineticChain = {
  hips: number;
  chest: number;
  head: number;
  hand: number;
};

export type AuditReport = {
  checks: AuditCheck[];
  edgeStrain: EdgeStrain;
  boneLengthDeviation: number;
  loopSeam: LoopSeam;
  kineticChain: KineticChain;
  secondaryLagFrames: number;
  anticipationFrames: number;
  followThroughFrames: number;
  sourceHash: string;
  sourceHashVerified: boolean;
  timestamp: number;
};

export class ContactTracker {
  private anchors: { L: { x: number; y: number } | null; R: { x: number; y: number } | null } = { L: null, R: null };
  private wasContact: { L: boolean; R: boolean } = { L: false, R: false };
  maxSlip = 0;
  contacts = 0;

  update(rig: SolvedRig) {
    const sides: ("L" | "R")[] = ["L", "R"];
    for (const side of sides) {
      const foot = side === "L" ? rig.footL : rig.footR;
      if (foot.contact && !this.wasContact[side]) {
        this.anchors[side] = { x: foot.toe.x, y: foot.toe.y };
        this.contacts += 1;
      }
      if (foot.contact && this.anchors[side]) {
        const slip = distance(foot.toe, this.anchors[side]!);
        this.maxSlip = Math.max(this.maxSlip, slip);
      }
      if (!foot.contact) this.anchors[side] = null;
      this.wasContact[side] = foot.contact;
    }
  }

  reset() {
    this.anchors = { L: null, R: null };
    this.wasContact = { L: false, R: false };
    this.maxSlip = 0;
    this.contacts = 0;
  }
}

export const boneLengthDeviation = (rig: SolvedRig) => {
  let max = 0;
  for (const bone of BONES) {
    if (!bone.parent) continue;
    const animated = distance(rig.joints[bone.name], rig.joints[bone.parent]);
    const rest = restBoneLength(bone.name);
    if (rest > 1e-8) max = Math.max(max, Math.abs(animated - rest) / rest);
  }
  return max;
};

export const computeEdgeStrain = (transforms: BoneTransform[], alphaMask?: Uint8Array): EdgeStrain => {
  const deformed = new Array<{ x: number; y: number }>(vertexCount);
  for (let index = 0; index < vertexCount; index++) {
    const weight = meshWeights[index];
    const dual = blendBoneDualQuat(transforms, weight.indices, weight.weights);
    deformed[index] = transformPoint(restPositions[index], dual);
  }
  const strains: number[] = [];
  const rowLength = MESH_COLS + 1;
  const inside = (a: number, b: number) => {
    if (alphaMask && (alphaMask[a] <= 8 || alphaMask[b] <= 8)) return false;
    return meshWeights[a].indices[0] === meshWeights[b].indices[0];
  };
  for (let row = 0; row <= MESH_ROWS; row++) {
    for (let col = 0; col <= MESH_COLS; col++) {
      const index = row * rowLength + col;
      if (col < MESH_COLS && inside(index, index + 1)) {
        const rest = 1 / MESH_COLS;
        const current = distance(deformed[index], deformed[index + 1]);
        strains.push(Math.abs(current / rest - 1));
      }
      if (row < MESH_ROWS && inside(index, index + rowLength)) {
        const rest = 1 / MESH_ROWS;
        const current = distance(deformed[index], deformed[index + rowLength]);
        strains.push(Math.abs(current / rest - 1));
      }
    }
  }
  if (!strains.length) return { max: 0, mean: 0, p95: 0, samples: 0 };
  strains.sort((a, b) => a - b);
  const mean = strains.reduce((sum, value) => sum + value, 0) / strains.length;
  const p95 = strains[Math.min(strains.length - 1, Math.floor(strains.length * 0.95))] ?? 0;
  return { max: strains[strains.length - 1] ?? 0, mean, p95, samples: strains.length };
};

const poseAt = (clip: Clip, phase: number): Pose => clip.sample(phase);

export const computeLoopSeam = (clip: Clip): LoopSeam => {
  const start = solveRig(poseAt(clip, 0).rig);
  const end = solveRig(poseAt(clip, 0.999999).rig);
  let position = 0;
  let angle = 0;
  for (const bone of BONES) {
    position = Math.max(position, distance(start.joints[bone.name], end.joints[bone.name]));
    const startAngle = start.angles[bone.name];
    const endAngle = end.angles[bone.name];
    let delta = Math.abs(endAngle - startAngle) % (Math.PI * 2);
    if (delta > Math.PI) delta = Math.PI * 2 - delta;
    angle = Math.max(angle, delta);
  }
  return { position, angle };
};

export const computeKineticChain = (clip: Clip): KineticChain => {
  const samples = 96;
  const hips: number[] = [];
  const chest: number[] = [];
  const head: number[] = [];
  const hand: number[] = [];
  let previous = solveRig(poseAt(clip, 0).rig);
  for (let index = 1; index <= samples; index++) {
    const current = solveRig(poseAt(clip, (index / samples) % 1).rig);
    hips.push(Math.abs(current.localAngles.hips - previous.localAngles.hips));
    chest.push(Math.abs(current.localAngles.chest - previous.localAngles.chest));
    head.push(Math.abs(current.localAngles.head - previous.localAngles.head));
    hand.push(distance(current.handR.wrist, previous.handR.wrist));
    previous = current;
  }
  const bestLag = (signal: number[]) => {
    let best = 0;
    let bestScore = -Infinity;
    for (let lag = 0; lag <= 12; lag++) {
      let score = 0;
      for (let index = 0; index < samples; index++) {
        score += signal[index] * hips[(index - lag + samples) % samples];
      }
      if (score > bestScore) {
        bestScore = score;
        best = lag;
      }
    }
    return (best / samples) * clip.fps;
  };
  return { hips: 0, chest: bestLag(chest), head: bestLag(head), hand: bestLag(hand) };
};

const statusFor = (value: number, pass: number, warn: number): CheckStatus => (value <= pass ? "pass" : value <= warn ? "warn" : "fail");

export const liveChecks = (rig: SolvedRig, tracker: ContactTracker): AuditCheck[] => {
  const deviation = boneLengthDeviation(rig);
  const slipCm = tracker.maxSlip * 170;
  const reachability = rig.footL.reachable && rig.footR.reachable && rig.handL.reachable && rig.handR.reachable;
  return [
    {
      id: "bone-length",
      label: "Bone length lock",
      value: `${(deviation * 100).toFixed(3)}%`,
      status: statusFor(deviation, 0.001, 0.01),
      detail: "Every animated bone is compared with its rest length. No stretch IK or scale is applied.",
    },
    {
      id: "contact",
      label: "Foot contact slip",
      value: `${slipCm.toFixed(2)} cm`,
      status: statusFor(slipCm, 0.1, 0.5),
      detail: "The toe of each planted foot is tracked in world space. The stance target is fixed.",
    },
    {
      id: "com",
      label: "Center of mass",
      value: rig.support.inside ? `${(rig.support.margin * 170).toFixed(1)} cm inside` : "outside support",
      status: rig.support.inside ? "pass" : "fail",
      detail: `Support interval: ${(rig.support.left * 100).toFixed(1)}–${(rig.support.right * 100).toFixed(1)}% of body height. Support: ${rig.support.label}.`,
    },
    {
      id: "reach",
      label: "IK reachability",
      value: reachability ? "all targets reachable" : "target clamped",
      status: reachability ? "pass" : "warn",
      detail: "Two-bone IK clamps unreachable targets onto the reachable annulus. The chain never lengthens.",
    },
  ];
};

export const verifySourceHash = async (): Promise<{ hash: string; verified: boolean }> => {
  try {
    const response = await fetch(SOURCE_URL);
    if (!response.ok) return { hash: "", verified: false };
    const buffer = await response.arrayBuffer();
    const digest = await crypto.subtle.digest("SHA-256", buffer);
    const hash = Array.from(new Uint8Array(digest))
      .map((byte) => byte.toString(16).padStart(2, "0"))
      .join("");
    return { hash, verified: hash === SOURCE_HASH };
  } catch {
    return { hash: "", verified: false };
  }
};

export const runFullAudit = async (clip: Clip, rig: SolvedRig, tracker: ContactTracker): Promise<AuditReport> => {
  const deviation = boneLengthDeviation(rig);
  const seam = computeLoopSeam(clip);
  const chain = computeKineticChain(clip);
  const [alphaMask, source] = await Promise.all([loadAlphaMask(), verifySourceHash()]);
  const strain = computeEdgeStrain(rig.bones, alphaMask);
  const lag = clip.sample(0).secondaryLagFrames;
  const anticipation = clip.sample(0).anticipationFrames;
  const followThrough = clip.sample(0).followThroughFrames;
  const slipCm = tracker.maxSlip * 170;
  const reachability = rig.footL.reachable && rig.footR.reachable && rig.handL.reachable && rig.handR.reachable;
  const checks: AuditCheck[] = [
    {
      id: "bone-length",
      label: "Bone length lock",
      value: `${(deviation * 100).toFixed(3)}%`,
      status: statusFor(deviation, 0.001, 0.01),
      detail: "Animated bone lengths vs. rest lengths. The rig uses fixed lengths and no bone scaling.",
    },
    {
      id: "mesh-strain",
      label: "Mesh edge strain",
      value: `${(strain.max * 100).toFixed(2)}% max`,
      status: statusFor(strain.max, 0.01, 0.02),
      detail: `${strain.samples.toLocaleString()} rigid bone-interior edges sampled; joint seam edges are excluded. Mean ${(strain.mean * 100).toFixed(3)}%, 95th percentile ${(strain.p95 * 100).toFixed(3)}%.`,
    },
    {
      id: "contact",
      label: "Foot contact slip",
      value: `${slipCm.toFixed(2)} cm`,
      status: statusFor(slipCm, 0.1, 0.5),
      detail: "The planted toe is anchored in world space. The tracker measures the maximum drift during contact.",
    },
    {
      id: "com",
      label: "Center of mass",
      value: rig.support.inside ? `${(rig.support.margin * 170).toFixed(1)} cm inside` : "outside support",
      status: rig.support.inside ? "pass" : "fail",
      detail: `Support: ${rig.support.label}. The center of mass is projected onto the support interval.`,
    },
    {
      id: "loop",
      label: "Loop seam",
      value: `${(seam.position * 1000).toFixed(2)} mm / ${((seam.angle * 180) / Math.PI).toFixed(2)}°`,
      status: seam.position < 0.001 && seam.angle < 0.01 ? "pass" : "warn",
      detail: "Pose sampled at phase 0 and phase 0.999999. Position and angle differences are measured across every bone.",
    },
    {
      id: "secondary",
      label: "Secondary motion",
      value: `${lag.toFixed(1)} frames lag`,
      status: lag >= 2 && lag <= 4 ? "pass" : "warn",
      detail: "Hair and coat follow the head and pelvis through a damped follow-through. No independent controls are invented.",
    },
    {
      id: "anticipation",
      label: "Anticipation / follow-through",
      value: `${anticipation.toFixed(1)}f / ${followThrough.toFixed(1)}f`,
      status: anticipation > 0 && followThrough > 0 ? "pass" : "warn",
      detail: "The body prepares before the hand or foot arrives, then settles after the action.",
    },
    {
      id: "reach",
      label: "IK reachability",
      value: reachability ? "all targets reachable" : "target clamped",
      status: reachability ? "pass" : "warn",
      detail: "Two-bone IK clamps unreachable targets. The chain never lengthens.",
    },
    {
      id: "source",
      label: "Source texture",
      value: source.verified ? "hash verified" : source.hash ? "hash mismatch" : "unavailable",
      status: source.verified ? "pass" : "fail",
      detail: source.verified
        ? "The original source texture hash matches the supplied file. The animation layer does not repaint or rescale the character."
        : "The source texture could not be verified in this context. The expected SHA-256 is shown in the source panel.",
    },
  ];
  return {
    checks,
    edgeStrain: strain,
    boneLengthDeviation: deviation,
    loopSeam: seam,
    kineticChain: chain,
    secondaryLagFrames: lag,
    anticipationFrames: anticipation,
    followThroughFrames: followThrough,
    sourceHash: source.hash || SOURCE_HASH,
    sourceHashVerified: source.verified,
    timestamp: Date.now(),
  };
};

export const formatChain = (chain: KineticChain) =>
  `hips 0.0f → chest +${chain.chest.toFixed(1)}f → head +${chain.head.toFixed(1)}f → hand +${chain.hand.toFixed(1)}f`;

export const boneNameAt = (index: number) => BONES[index]?.name ?? "unknown";
export const boneIndex = (name: keyof typeof BONE_INDEX) => BONE_INDEX[name];
