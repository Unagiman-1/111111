import {
  add,
  angleOf,
  blendDualQuats,
  distance,
  distanceToSegment,
  dualQuatFromTransform,
  length,
  midpoint,
  rotate,
  scale,
  solveTwoBoneIK,
  sub,
  type DualQuat,
  type Vec2,
} from "./math";

export const BONE_NAMES = [
  "hips",
  "spine",
  "chest",
  "neck",
  "head",
  "hair",
  "shoulderL",
  "elbowL",
  "wristL",
  "handL",
  "shoulderR",
  "elbowR",
  "wristR",
  "handR",
  "hipL",
  "kneeL",
  "ankleL",
  "footL",
  "hipR",
  "kneeR",
  "ankleR",
  "footR",
  "coat",
] as const;

export type BoneName = (typeof BONE_NAMES)[number];
export type BoneRegion = "head" | "neck" | "torso" | "arm" | "leg" | "coat";

export type BoneDef = {
  name: BoneName;
  parent: BoneName | null;
  rest: Vec2;
  region: BoneRegion;
  sigma: number;
  segmentEnd: Vec2;
};

const p = (x: number, y: number): Vec2 => ({ x, y });

/**
 * Rest joints are measured from the supplied full-body artwork. They describe
 * the animation layer only; the source texture is never repainted or rescaled.
 */
export const BONES: BoneDef[] = [
  { name: "hips", parent: null, rest: p(0.5, 0.549), region: "torso", sigma: 0.13, segmentEnd: p(0.5, 0.441) },
  { name: "spine", parent: "hips", rest: p(0.5, 0.441), region: "torso", sigma: 0.12, segmentEnd: p(0.5, 0.322) },
  { name: "chest", parent: "spine", rest: p(0.5, 0.322), region: "torso", sigma: 0.12, segmentEnd: p(0.5, 0.204) },
  { name: "neck", parent: "chest", rest: p(0.5, 0.204), region: "neck", sigma: 0.075, segmentEnd: p(0.5, 0.105) },
  { name: "head", parent: "neck", rest: p(0.5, 0.105), region: "head", sigma: 0.105, segmentEnd: p(0.5, 0.066) },
  { name: "hair", parent: "head", rest: p(0.5, 0.066), region: "head", sigma: 0.055, segmentEnd: p(0.5, 0.045) },
  { name: "shoulderL", parent: "chest", rest: p(0.365, 0.263), region: "arm", sigma: 0.075, segmentEnd: p(0.27, 0.421) },
  { name: "elbowL", parent: "shoulderL", rest: p(0.27, 0.421), region: "arm", sigma: 0.065, segmentEnd: p(0.23, 0.559) },
  { name: "wristL", parent: "elbowL", rest: p(0.23, 0.559), region: "arm", sigma: 0.055, segmentEnd: p(0.2, 0.6) },
  { name: "handL", parent: "wristL", rest: p(0.2, 0.6), region: "arm", sigma: 0.04, segmentEnd: p(0.19, 0.615) },
  { name: "shoulderR", parent: "chest", rest: p(0.635, 0.263), region: "arm", sigma: 0.075, segmentEnd: p(0.73, 0.421) },
  { name: "elbowR", parent: "shoulderR", rest: p(0.73, 0.421), region: "arm", sigma: 0.065, segmentEnd: p(0.77, 0.559) },
  { name: "wristR", parent: "elbowR", rest: p(0.77, 0.559), region: "arm", sigma: 0.055, segmentEnd: p(0.8, 0.6) },
  { name: "handR", parent: "wristR", rest: p(0.8, 0.6), region: "arm", sigma: 0.04, segmentEnd: p(0.81, 0.615) },
  { name: "hipL", parent: "hips", rest: p(0.4425, 0.549), region: "leg", sigma: 0.085, segmentEnd: p(0.3375, 0.737) },
  { name: "kneeL", parent: "hipL", rest: p(0.3375, 0.737), region: "leg", sigma: 0.075, segmentEnd: p(0.3075, 0.934) },
  { name: "ankleL", parent: "kneeL", rest: p(0.3075, 0.934), region: "leg", sigma: 0.055, segmentEnd: p(0.29, 0.964) },
  { name: "footL", parent: "ankleL", rest: p(0.29, 0.964), region: "leg", sigma: 0.045, segmentEnd: p(0.28, 0.98) },
  { name: "hipR", parent: "hips", rest: p(0.5575, 0.549), region: "leg", sigma: 0.085, segmentEnd: p(0.71, 0.737) },
  { name: "kneeR", parent: "hipR", rest: p(0.71, 0.737), region: "leg", sigma: 0.075, segmentEnd: p(0.7875, 0.954) },
  { name: "ankleR", parent: "kneeR", rest: p(0.7875, 0.954), region: "leg", sigma: 0.055, segmentEnd: p(0.8075, 0.984) },
  { name: "footR", parent: "ankleR", rest: p(0.8075, 0.984), region: "leg", sigma: 0.045, segmentEnd: p(0.82, 0.998) },
  { name: "coat", parent: "hips", rest: p(0.5, 0.6), region: "coat", sigma: 0.095, segmentEnd: p(0.5, 0.66) },
];

export const BONE_INDEX: Record<BoneName, number> = BONES.reduce((accumulator, bone, index) => {
  accumulator[bone.name] = index;
  return accumulator;
}, {} as Record<BoneName, number>);

export const REST = BONES.reduce((accumulator, bone) => {
  accumulator[bone.name] = bone.rest;
  return accumulator;
}, {} as Record<BoneName, Vec2>);

export const REST_LENGTH = {
  spine: distance(REST.spine, REST.hips),
  chest: distance(REST.chest, REST.spine),
  neck: distance(REST.neck, REST.chest),
  head: distance(REST.head, REST.neck),
  upperArmL: distance(REST.elbowL, REST.shoulderL),
  lowerArmL: distance(REST.wristL, REST.elbowL),
  handL: distance(REST.handL, REST.wristL),
  upperArmR: distance(REST.elbowR, REST.shoulderR),
  lowerArmR: distance(REST.wristR, REST.elbowR),
  handR: distance(REST.handR, REST.wristR),
  thighL: distance(REST.kneeL, REST.hipL),
  shinL: distance(REST.ankleL, REST.kneeL),
  footL: distance(REST.footL, REST.ankleL),
  thighR: distance(REST.kneeR, REST.hipR),
  shinR: distance(REST.ankleR, REST.kneeR),
  footR: distance(REST.footR, REST.ankleR),
};

export const REST_ANGLES = {
  shoulderL: angleOf(sub(REST.elbowL, REST.shoulderL)),
  elbowL: angleOf(sub(REST.wristL, REST.elbowL)),
  wristL: angleOf(sub(REST.handL, REST.wristL)),
  shoulderR: angleOf(sub(REST.elbowR, REST.shoulderR)),
  elbowR: angleOf(sub(REST.wristR, REST.elbowR)),
  wristR: angleOf(sub(REST.handR, REST.wristR)),
  hipL: angleOf(sub(REST.kneeL, REST.hipL)),
  kneeL: angleOf(sub(REST.ankleL, REST.kneeL)),
  ankleL: angleOf(sub(REST.footL, REST.ankleL)),
  hipR: angleOf(sub(REST.kneeR, REST.hipR)),
  kneeR: angleOf(sub(REST.ankleR, REST.kneeR)),
  ankleR: angleOf(sub(REST.footR, REST.ankleR)),
};

export type RigPose = {
  root: Vec2;
  rootAngle: number;
  spineAngle: number;
  chestAngle: number;
  neckAngle: number;
  headAngle: number;
  hairAngle: number;
  coatAngle: number;
  shoulderLAngle: number;
  shoulderRAngle: number;
  handLTarget: Vec2;
  handRTarget: Vec2;
  handLAngle: number;
  handRAngle: number;
  footLTarget: Vec2;
  footRTarget: Vec2;
  footLAngle: number;
  footRAngle: number;
  contactL: boolean;
  contactR: boolean;
};

export type BoneTransform = {
  name: BoneName;
  parent: BoneName | null;
  rest: Vec2;
  world: Vec2;
  angle: number;
  localAngle: number;
  dual: DualQuat;
};

export type FootState = {
  ankle: Vec2;
  toe: Vec2;
  angle: number;
  contact: boolean;
  reachable: boolean;
  target: Vec2;
};

export type HandState = {
  wrist: Vec2;
  hand: Vec2;
  angle: number;
  reachable: boolean;
  target: Vec2;
};

export type SupportState = {
  left: number;
  right: number;
  width: number;
  margin: number;
  inside: boolean;
  label: string;
};

export type SolvedRig = {
  bones: BoneTransform[];
  joints: Record<BoneName, Vec2>;
  angles: Record<BoneName, number>;
  localAngles: Record<BoneName, number>;
  footL: FootState;
  footR: FootState;
  handL: HandState;
  handR: HandState;
  com: Vec2;
  support: SupportState;
  headWorldAngle: number;
  hipsWorldAngle: number;
  chestWorldAngle: number;
};

const makeTransform = (bone: BoneDef, world: Vec2, angle: number, localAngle: number): BoneTransform => {
  const translation = sub(world, bone.rest);
  return {
    name: bone.name,
    parent: bone.parent,
    rest: bone.rest,
    world,
    angle,
    localAngle,
    dual: dualQuatFromTransform(angle, translation),
  };
};



export const solveRig = (pose: RigPose): SolvedRig => {
  const transforms: BoneTransform[] = new Array(BONES.length);
  const joints = {} as Record<BoneName, Vec2>;
  const angles = {} as Record<BoneName, number>;
  const localAngles = {} as Record<BoneName, number>;

  const set = (name: BoneName, world: Vec2, angle: number, localAngle: number) => {
    const index = BONE_INDEX[name];
    transforms[index] = makeTransform(BONES[index], world, angle, localAngle);
    joints[name] = world;
    angles[name] = angle;
    localAngles[name] = localAngle;
  };

  const hipsWorld = pose.root;
  const hipsAngle = pose.rootAngle;
  set("hips", hipsWorld, hipsAngle, pose.rootAngle);

  const spineWorld = add(hipsWorld, rotate(sub(REST.spine, REST.hips), hipsAngle));
  const spineAngle = hipsAngle + pose.spineAngle;
  set("spine", spineWorld, spineAngle, pose.spineAngle);

  const chestWorld = add(spineWorld, rotate(sub(REST.chest, REST.spine), spineAngle));
  const chestAngle = spineAngle + pose.chestAngle;
  set("chest", chestWorld, chestAngle, pose.chestAngle);

  const neckWorld = add(chestWorld, rotate(sub(REST.neck, REST.chest), chestAngle));
  const neckAngle = chestAngle + pose.neckAngle;
  set("neck", neckWorld, neckAngle, pose.neckAngle);

  const headWorld = add(neckWorld, rotate(sub(REST.head, REST.neck), neckAngle));
  const headAngle = neckAngle + pose.headAngle;
  set("head", headWorld, headAngle, pose.headAngle);

  const hairWorld = add(headWorld, rotate(sub(REST.hair, REST.head), headAngle));
  const hairAngle = headAngle + pose.hairAngle;
  set("hair", hairWorld, hairAngle, pose.hairAngle);

  const coatWorld = add(hipsWorld, rotate(sub(REST.coat, REST.hips), hipsAngle));
  const coatAngle = hipsAngle + pose.coatAngle;
  set("coat", coatWorld, coatAngle, pose.coatAngle);

  const shoulderLWorld = add(chestWorld, rotate(sub(REST.shoulderL, REST.chest), chestAngle + pose.shoulderLAngle));
  const shoulderRWorld = add(chestWorld, rotate(sub(REST.shoulderR, REST.chest), chestAngle + pose.shoulderRAngle));

  const armL = solveTwoBoneIK(shoulderLWorld, pose.handLTarget, REST_LENGTH.upperArmL, REST_LENGTH.lowerArmL, 1);
  const armR = solveTwoBoneIK(shoulderRWorld, pose.handRTarget, REST_LENGTH.upperArmR, REST_LENGTH.lowerArmR, -1);

  const shoulderLAngle = angleOf(sub(armL.joint, shoulderLWorld));
  const elbowLAngle = angleOf(sub(armL.end, armL.joint));
  const wristLAngle = REST_ANGLES.wristL + pose.handLAngle;
  const handLEnd = add(armL.end, rotate(sub(REST.handL, REST.wristL), wristLAngle));

  const shoulderRAngle = angleOf(sub(armR.joint, shoulderRWorld));
  const elbowRAngle = angleOf(sub(armR.end, armR.joint));
  const wristRAngle = REST_ANGLES.wristR + pose.handRAngle;
  const handREnd = add(armR.end, rotate(sub(REST.handR, REST.wristR), wristRAngle));

  const shoulderLWorldRotation = shoulderLAngle - REST_ANGLES.shoulderL;
  const elbowLWorldRotation = elbowLAngle - REST_ANGLES.shoulderL - REST_ANGLES.elbowL;
  const wristLWorldRotation = wristLAngle - REST_ANGLES.shoulderL - REST_ANGLES.elbowL - REST_ANGLES.wristL;
  set("shoulderL", shoulderLWorld, shoulderLWorldRotation, shoulderLAngle - (chestAngle + pose.shoulderLAngle) - REST_ANGLES.shoulderL);
  set("elbowL", armL.joint, elbowLWorldRotation, elbowLAngle - shoulderLAngle - REST_ANGLES.elbowL);
  set("wristL", armL.end, wristLWorldRotation, wristLAngle - elbowLAngle - REST_ANGLES.wristL);
  set("handL", handLEnd, wristLWorldRotation, 0);

  const shoulderRWorldRotation = shoulderRAngle - REST_ANGLES.shoulderR;
  const elbowRWorldRotation = elbowRAngle - REST_ANGLES.shoulderR - REST_ANGLES.elbowR;
  const wristRWorldRotation = wristRAngle - REST_ANGLES.shoulderR - REST_ANGLES.elbowR - REST_ANGLES.wristR;
  set("shoulderR", shoulderRWorld, shoulderRWorldRotation, shoulderRAngle - (chestAngle + pose.shoulderRAngle) - REST_ANGLES.shoulderR);
  set("elbowR", armR.joint, elbowRWorldRotation, elbowRAngle - shoulderRAngle - REST_ANGLES.elbowR);
  set("wristR", armR.end, wristRWorldRotation, wristRAngle - elbowRAngle - REST_ANGLES.wristR);
  set("handR", handREnd, wristRWorldRotation, 0);

  const hipLWorld = add(hipsWorld, rotate(sub(REST.hipL, REST.hips), hipsAngle));
  const hipRWorld = add(hipsWorld, rotate(sub(REST.hipR, REST.hips), hipsAngle));

  const legL = solveTwoBoneIK(hipLWorld, pose.footLTarget, REST_LENGTH.thighL, REST_LENGTH.shinL, 1);
  const legR = solveTwoBoneIK(hipRWorld, pose.footRTarget, REST_LENGTH.thighR, REST_LENGTH.shinR, -1);

  const hipLAngle = angleOf(sub(legL.joint, hipLWorld));
  const kneeLAngle = angleOf(sub(legL.end, legL.joint));
  const footLAngle = REST_ANGLES.ankleL + pose.footLAngle;
  const toeL = add(legL.end, rotate(sub(REST.footL, REST.ankleL), footLAngle));

  const hipRAngle = angleOf(sub(legR.joint, hipRWorld));
  const kneeRAngle = angleOf(sub(legR.end, legR.joint));
  const footRAngle = REST_ANGLES.ankleR + pose.footRAngle;
  const toeR = add(legR.end, rotate(sub(REST.footR, REST.ankleR), footRAngle));

  const hipLWorldRotation = hipLAngle - REST_ANGLES.hipL;
  const kneeLWorldRotation = kneeLAngle - REST_ANGLES.hipL - REST_ANGLES.kneeL;
  const ankleLWorldRotation = footLAngle - REST_ANGLES.hipL - REST_ANGLES.kneeL - REST_ANGLES.ankleL;
  set("hipL", hipLWorld, hipLWorldRotation, hipLAngle - hipsAngle - REST_ANGLES.hipL);
  set("kneeL", legL.joint, kneeLWorldRotation, kneeLAngle - hipLAngle - REST_ANGLES.kneeL);
  set("ankleL", legL.end, ankleLWorldRotation, footLAngle - kneeLAngle - REST_ANGLES.ankleL);
  set("footL", toeL, ankleLWorldRotation, 0);

  const hipRWorldRotation = hipRAngle - REST_ANGLES.hipR;
  const kneeRWorldRotation = kneeRAngle - REST_ANGLES.hipR - REST_ANGLES.kneeR;
  const ankleRWorldRotation = footRAngle - REST_ANGLES.hipR - REST_ANGLES.kneeR - REST_ANGLES.ankleR;
  set("hipR", hipRWorld, hipRWorldRotation, hipRAngle - hipsAngle - REST_ANGLES.hipR);
  set("kneeR", legR.joint, kneeRWorldRotation, kneeRAngle - hipRAngle - REST_ANGLES.kneeR);
  set("ankleR", legR.end, ankleRWorldRotation, footRAngle - kneeRAngle - REST_ANGLES.ankleR);
  set("footR", toeR, ankleRWorldRotation, 0);

  const com = {
    x:
      0.08 * midpoint(joints.head, joints.hair).x +
      0.45 * midpoint(joints.hips, joints.chest).x +
      0.05 * midpoint(joints.shoulderL, handLEnd).x +
      0.05 * midpoint(joints.shoulderR, handREnd).x +
      0.185 * midpoint(joints.hipL, toeL).x +
      0.185 * midpoint(joints.hipR, toeR).x,
    y:
      0.08 * midpoint(joints.head, joints.hair).y +
      0.45 * midpoint(joints.hips, joints.chest).y +
      0.05 * midpoint(joints.shoulderL, handLEnd).y +
      0.05 * midpoint(joints.shoulderR, handREnd).y +
      0.185 * midpoint(joints.hipL, toeL).y +
      0.185 * midpoint(joints.hipR, toeR).y,
  };

  const halfFoot = 0.026;
  const intervals: { left: number; right: number; label: string }[] = [];
  if (pose.contactL) intervals.push({ left: Math.min(legL.end.x, toeL.x) - halfFoot, right: Math.max(legL.end.x, toeL.x) + halfFoot, label: "left" });
  if (pose.contactR) intervals.push({ left: Math.min(legR.end.x, toeR.x) - halfFoot, right: Math.max(legR.end.x, toeR.x) + halfFoot, label: "right" });
  const supportLeft = intervals.length ? Math.min(...intervals.map((interval) => interval.left)) : 0;
  const supportRight = intervals.length ? Math.max(...intervals.map((interval) => interval.right)) : 0;
  const margin = intervals.length ? Math.min(com.x - supportLeft, supportRight - com.x) : -1;
  const support: SupportState = {
    left: supportLeft,
    right: supportRight,
    width: supportRight - supportLeft,
    margin,
    inside: intervals.length > 0 && margin >= 0,
    label: intervals.length === 2 ? "double support" : intervals.length === 1 ? `${intervals[0].label} support` : "airborne",
  };

  return {
    bones: transforms,
    joints,
    angles,
    localAngles,
    footL: { ankle: legL.end, toe: toeL, angle: footLAngle, contact: pose.contactL, reachable: legL.reachable, target: pose.footLTarget },
    footR: { ankle: legR.end, toe: toeR, angle: footRAngle, contact: pose.contactR, reachable: legR.reachable, target: pose.footRTarget },
    handL: { wrist: armL.end, hand: handLEnd, angle: wristLAngle, reachable: armL.reachable, target: pose.handLTarget },
    handR: { wrist: armR.end, hand: handREnd, angle: wristRAngle, reachable: armR.reachable, target: pose.handRTarget },
    com,
    support,
    headWorldAngle: headAngle,
    hipsWorldAngle: hipsAngle,
    chestWorldAngle: chestAngle,
  };
};

export const boneLength = (name: BoneName) => {
  const index = BONE_INDEX[name];
  const parent = BONES[index].parent;
  if (!parent) return 0;
  return distance(BONES[index].rest, BONES[BONE_INDEX[parent]].rest);
};

export const restBoneLength = (name: BoneName) => {
  const index = BONE_INDEX[name];
  const parent = BONES[index].parent;
  if (!parent) return 0;
  return length(sub(BONES[index].rest, BONES[BONE_INDEX[parent]].rest));
};

export type MeshWeight = { indices: [number, number, number, number]; weights: [number, number, number, number] };



export type BodyPart = "head" | "torso" | "armL" | "armR" | "legL" | "legR";

/**
 * Body parts are separate deformation islands. This prevents a triangle from
 * blending the arm into the leg where their silhouettes overlap in 2D. The
 * seams sit at the shoulder, hip, and neck, under the existing clothing.
 */
export const bodyPartAt = (vertex: Vec2): BodyPart => {
  const { x, y } = vertex;
  if (y < 0.26) return "head";
  if (y < 0.55) {
    if (x < 0.3) return "armL";
    if (x > 0.7) return "armR";
    return "torso";
  }
  if (x < 0.3) return "armL";
  if (x > 0.7) return "armR";
  if (x < 0.5) return "legL";
  return "legR";
};

const allowedBones = (part: BodyPart): BoneName[] => {
  switch (part) {
    case "head":
      return ["head", "hair", "neck"];
    case "torso":
      return ["hips", "spine", "chest", "neck", "coat"];
    case "armL":
      return ["shoulderL", "elbowL", "wristL", "handL"];
    case "armR":
      return ["shoulderR", "elbowR", "wristR", "handR"];
    case "legL":
      return ["hipL", "kneeL", "ankleL", "footL"];
    case "legR":
      return ["hipR", "kneeR", "ankleR", "footR"];
  }
};

export const computeMeshWeights = (cols: number, rows: number): MeshWeight[] => {
  const weights: MeshWeight[] = [];
  for (let row = 0; row <= rows; row++) {
    for (let col = 0; col <= cols; col++) {
      const vertex = { x: col / cols, y: row / rows };
      const allowed = allowedBones(bodyPartAt(vertex));
      let nearestIndex = BONE_INDEX[allowed[0]];
      let nearestDistance = Infinity;
      for (const name of allowed) {
        const bone = BONES[BONE_INDEX[name]];
        const d = distanceToSegment(vertex, bone.rest, bone.segmentEnd);
        if (d < nearestDistance) {
          nearestDistance = d;
          nearestIndex = BONE_INDEX[name];
        }
      }
      weights.push({ indices: [nearestIndex, 0, 0, 0], weights: [1, 0, 0, 0] });
    }
  }
  return weights;
};

export const blendBoneDualQuat = (transforms: BoneTransform[], indices: [number, number, number, number], weights: [number, number, number, number]) =>
  blendDualQuats([
    { value: transforms[indices[0]].dual, weight: weights[0] },
    { value: transforms[indices[1]].dual, weight: weights[1] },
    { value: transforms[indices[2]].dual, weight: weights[2] },
    { value: transforms[indices[3]].dual, weight: weights[3] },
  ]);

export const restJoint = (name: BoneName) => REST[name];

export const footRestVector = (side: "L" | "R") => sub(REST[side === "L" ? "footL" : "footR"], REST[side === "L" ? "ankleL" : "ankleR"]);
export const handRestVector = (side: "L" | "R") => sub(REST[side === "L" ? "handL" : "handR"], REST[side === "L" ? "wristL" : "wristR"]);

export const scaleVec = scale;
