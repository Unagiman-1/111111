export type Vec2 = { x: number; y: number };
export type Quat = { x: number; y: number; z: number; w: number };
export type DualQuat = { real: Quat; dual: Quat };

export const TAU = Math.PI * 2;
export const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const invLerp = (a: number, b: number, value: number) => (b === a ? 0 : (value - a) / (b - a));
export const smoothstep = (edge0: number, edge1: number, value: number) => {
  const t = clamp(invLerp(edge0, edge1, value), 0, 1);
  return t * t * (3 - 2 * t);
};
export const smootherstep = (edge0: number, edge1: number, value: number) => {
  const t = clamp(invLerp(edge0, edge1, value), 0, 1);
  return t * t * t * (t * (t * 6 - 15) + 10);
};
export const easeInOut = (t: number) => {
  const x = clamp(t, 0, 1);
  return x < 0.5 ? 2 * x * x : 1 - Math.pow(-2 * x + 2, 2) / 2;
};
export const easeOut = (t: number) => 1 - Math.pow(1 - clamp(t, 0, 1), 3);
export const easeIn = (t: number) => Math.pow(clamp(t, 0, 1), 3);
export const fract = (value: number) => value - Math.floor(value);
export const wrapPhase = (value: number) => fract(value);

export const vec = (x = 0, y = 0): Vec2 => ({ x, y });
export const add = (a: Vec2, b: Vec2): Vec2 => ({ x: a.x + b.x, y: a.y + b.y });
export const sub = (a: Vec2, b: Vec2): Vec2 => ({ x: a.x - b.x, y: a.y - b.y });
export const scale = (a: Vec2, amount: number): Vec2 => ({ x: a.x * amount, y: a.y * amount });
export const dot = (a: Vec2, b: Vec2) => a.x * b.x + a.y * b.y;
export const lengthSq = (a: Vec2) => a.x * a.x + a.y * a.y;
export const length = (a: Vec2) => Math.sqrt(lengthSq(a));
export const distance = (a: Vec2, b: Vec2) => length(sub(a, b));
export const normalize = (a: Vec2): Vec2 => {
  const l = length(a);
  return l > 1e-9 ? { x: a.x / l, y: a.y / l } : { x: 1, y: 0 };
};
export const rotate = (a: Vec2, angle: number): Vec2 => {
  const c = Math.cos(angle);
  const s = Math.sin(angle);
  return { x: a.x * c - a.y * s, y: a.x * s + a.y * c };
};
export const angleOf = (a: Vec2) => Math.atan2(a.y, a.x);
export const fromAngle = (angle: number, radius = 1): Vec2 => ({ x: Math.cos(angle) * radius, y: Math.sin(angle) * radius });
export const midpoint = (a: Vec2, b: Vec2): Vec2 => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });
export const lerpVec = (a: Vec2, b: Vec2, t: number): Vec2 => ({ x: lerp(a.x, b.x, t), y: lerp(a.y, b.y, t) });
export const clampVec = (a: Vec2, min: Vec2, max: Vec2): Vec2 => ({ x: clamp(a.x, min.x, max.x), y: clamp(a.y, min.y, max.y) });
export const moveTowards = (current: number, target: number, maxDelta: number) => {
  if (Math.abs(target - current) <= maxDelta) return target;
  return current + Math.sign(target - current) * maxDelta;
};

export const shortestAngle = (from: number, to: number) => {
  let delta = (to - from) % TAU;
  if (delta > Math.PI) delta -= TAU;
  if (delta < -Math.PI) delta += TAU;
  return delta;
};

export const damp = (current: number, target: number, smoothing: number, dt: number) =>
  lerp(current, target, 1 - Math.exp(-smoothing * dt));

export const distanceToSegment = (point: Vec2, a: Vec2, b: Vec2) => {
  const ab = sub(b, a);
  const denom = lengthSq(ab);
  if (denom < 1e-9) return distance(point, a);
  const t = clamp(dot(sub(point, a), ab) / denom, 0, 1);
  return distance(point, add(a, scale(ab, t)));
};

export const closestPointOnSegment = (point: Vec2, a: Vec2, b: Vec2): Vec2 => {
  const ab = sub(b, a);
  const denom = lengthSq(ab);
  if (denom < 1e-9) return a;
  const t = clamp(dot(sub(point, a), ab) / denom, 0, 1);
  return add(a, scale(ab, t));
};

export type IKResult = {
  joint: Vec2;
  end: Vec2;
  reachable: boolean;
  distance: number;
};

/**
 * Two-bone IK. Bone lengths are never changed: an unreachable target is pulled
 * onto the reachable annulus, so the chain cannot stretch.
 */
export const solveTwoBoneIK = (root: Vec2, target: Vec2, upperLength: number, lowerLength: number, bend = 1): IKResult => {
  const delta = sub(target, root);
  const rawDistance = length(delta);
  const minDistance = Math.abs(upperLength - lowerLength) + 1e-5;
  const maxDistance = upperLength + lowerLength - 1e-5;
  const reachable = rawDistance >= minDistance && rawDistance <= maxDistance;
  const d = clamp(rawDistance, minDistance, maxDistance);
  const direction = rawDistance > 1e-8 ? scale(delta, 1 / rawDistance) : { x: 1, y: 0 };
  const end = add(root, scale(direction, d));
  const along = (upperLength * upperLength - lowerLength * lowerLength + d * d) / (2 * d);
  const height = Math.sqrt(Math.max(0, upperLength * upperLength - along * along));
  const base = add(root, scale(direction, along));
  const perpendicular = { x: -direction.y, y: direction.x };
  const joint = add(base, scale(perpendicular, height * bend));
  return { joint, end, reachable, distance: rawDistance };
};

export const quatFromAxisAngleZ = (angle: number): Quat => ({
  x: 0,
  y: 0,
  z: Math.sin(angle / 2),
  w: Math.cos(angle / 2),
});

export const quatMultiply = (a: Quat, b: Quat): Quat => ({
  x: a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
  y: a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
  z: a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w,
  w: a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z,
});

export const quatConjugate = (q: Quat): Quat => ({ x: -q.x, y: -q.y, z: -q.z, w: q.w });

export const quatNormalize = (q: Quat): Quat => {
  const l = Math.sqrt(q.x * q.x + q.y * q.y + q.z * q.z + q.w * q.w);
  if (l < 1e-9) return { x: 0, y: 0, z: 0, w: 1 };
  return { x: q.x / l, y: q.y / l, z: q.z / l, w: q.w / l };
};

export const quatDot = (a: Quat, b: Quat) => a.x * b.x + a.y * b.y + a.z * b.z + a.w * b.w;

export const dualQuatFromTransform = (angle: number, translation: Vec2): DualQuat => {
  const real = quatFromAxisAngleZ(angle);
  const pureTranslation: Quat = { x: translation.x, y: translation.y, z: 0, w: 0 };
  const dual = quatMultiply(pureTranslation, real);
  return {
    real,
    dual: { x: dual.x * 0.5, y: dual.y * 0.5, z: dual.z * 0.5, w: dual.w * 0.5 },
  };
};

export const blendDualQuats = (entries: { value: DualQuat; weight: number }[]): DualQuat => {
  const real: Quat = { x: 0, y: 0, z: 0, w: 0 };
  const dual: Quat = { x: 0, y: 0, z: 0, w: 0 };
  let total = 0;
  for (const entry of entries) {
    if (entry.weight <= 0) continue;
    total += entry.weight;
    real.x += entry.value.real.x * entry.weight;
    real.y += entry.value.real.y * entry.weight;
    real.z += entry.value.real.z * entry.weight;
    real.w += entry.value.real.w * entry.weight;
    dual.x += entry.value.dual.x * entry.weight;
    dual.y += entry.value.dual.y * entry.weight;
    dual.z += entry.value.dual.z * entry.weight;
    dual.w += entry.value.dual.w * entry.weight;
  }
  if (total <= 1e-9) return { real: { x: 0, y: 0, z: 0, w: 1 }, dual: { x: 0, y: 0, z: 0, w: 0 } };
  const normalizedReal = quatNormalize(real);
  const projection = quatDot(normalizedReal, dual);
  return {
    real: normalizedReal,
    dual: {
      x: dual.x - normalizedReal.x * projection,
      y: dual.y - normalizedReal.y * projection,
      z: dual.z - normalizedReal.z * projection,
      w: dual.w - normalizedReal.w * projection,
    },
  };
};

export const dualQuatTranslation = (q: DualQuat): Vec2 => {
  const product = quatMultiply(q.dual, quatConjugate(q.real));
  return { x: product.x * 2, y: product.y * 2 };
};

export const transformPoint = (point: Vec2, q: DualQuat): Vec2 => {
  const t = dualQuatTranslation(q);
  const v = { x: point.x, y: point.y, z: 0 };
  const qv = q.real;
  // q * v * q^-1
  const tx = 2 * (qv.y * v.z - qv.z * v.y);
  const ty = 2 * (qv.z * v.x - qv.x * v.z);
  const tz = 2 * (qv.x * v.y - qv.y * v.x);
  return {
    x: point.x + qv.w * tx + (qv.y * tz - qv.z * ty) + t.x,
    y: point.y + qv.w * ty + (qv.z * tx - qv.x * tz) + t.y,
  };
};

export const spring = (current: number, velocity: number, target: number, stiffness: number, damping: number, dt: number) => {
  const acceleration = (target - current) * stiffness - velocity * damping;
  const nextVelocity = velocity + acceleration * dt;
  return { value: current + nextVelocity * dt, velocity: nextVelocity };
};

export const formatSigned = (value: number, digits = 2) => `${value >= 0 ? "+" : ""}${value.toFixed(digits)}`;
