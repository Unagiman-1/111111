import Phaser from "phaser";
import courtyardImage from "../art/locations/courtyard.jpg?inline";
import archImage from "../art/locations/arch.jpg?inline";
import boilerImage from "../art/locations/boiler.jpg?inline";
import { ABILITIES, ENEMIES, LOGICAL_HEIGHT, LOGICAL_WIDTH, TOWERS } from "../game/data";
import type { Game } from "../game/engine";
import { audio } from "../game/audio";
import { ART_UNITS, type ArtUnit } from "../game/art-types";
import { getArtwork } from "../game/art-library";
import type { Snapshot, Vec } from "../game/types";

export interface BattleSetup {
  game: Game;
  onSnapshot: (snapshot: Snapshot) => void;
}

/** Фиксированный шаг симуляции (30 Гц), как в прежнем движке. */
const FIXED_STEP = 1 / 30;
const MAX_STEPS = 8;
const UI_INTERVAL_MS = 90;
const BIRD_KEY = "bird";
const LOCATION_IMAGES = { courtyard: courtyardImage, arch: archImage, boiler: boilerImage } as const;
const LEAF_COUNT = 34;
const RAIN_COUNT = 140;
const SNOW_COUNT = 110;
/** Шрифт подписей на поле: тот же, что и в интерфейсе, с запасными вариантами. */
const FIELD_FONT = '"Manrope Variable", "Segoe UI", Arial, sans-serif';
const LABEL_FONT = '"Oswald Variable", "Arial Narrow", Arial, sans-serif';

const textureKey = (unit: ArtUnit) => `unit-${unit}`;

/** "#rrggbb" -> число для Phaser. Некорректные значения дают белый. */
function hex(color: string): number {
  return /^#[0-9a-f]{6}/i.test(color) ? parseInt(color.slice(1, 7), 16) : 0xffffff;
}

/**
 * Игровое поле на Phaser 4. Вся логика боя живёт в Game (engine.ts),
 * сцена только читает состояние, рисует его и передаёт ввод игроку обратно в Game.
 */
export class BattleScene extends Phaser.Scene {
  private setup: BattleSetup;
  private staticLayer!: Phaser.GameObjects.Graphics;
  private ground!: Phaser.GameObjects.Graphics;
  private fx!: Phaser.GameObjects.Graphics;
  private hud!: Phaser.GameObjects.Graphics;
  private hero!: Phaser.GameObjects.Image;
  private sprites = new Map<string, Phaser.GameObjects.Image>();
  private labels: Phaser.GameObjects.Text[] = [];
  private labelCount = 0;
  private accumulator = 0;
  private frames = 0;
  private fpsTime = 0;
  private lastUi = 0;
  private unitScale = 1;
  private pointer: Vec | null = null;
  private readonly leaves = Array.from({ length: LEAF_COUNT }, (_, i) => ({
    x: (i * 197) % LOGICAL_WIDTH, y: (i * 83) % LOGICAL_HEIGHT,
    speed: 8 + (i % 7) * 2, drift: 15 + (i % 5) * 7, size: 2 + (i % 4), phase: i * 1.71,
  }));
  private readonly drops = Array.from({ length: RAIN_COUNT }, (_, i) => ({
    x: (i * 733) % (LOGICAL_WIDTH + 200) - 100, y: (i * 389) % LOGICAL_HEIGHT,
    speed: 620 + (i % 9) * 45, len: 12 + (i % 5) * 4, alpha: 0.12 + (i % 4) * 0.05,
  }));
  private readonly flakes = Array.from({ length: SNOW_COUNT }, (_, i) => ({
    x: (i * 211) % LOGICAL_WIDTH, y: (i * 137) % LOGICAL_HEIGHT,
    speed: 22 + (i % 7) * 7, drift: 10 + (i % 5) * 6, size: 1.2 + (i % 4) * 0.7, phase: i * 0.93,
  }));
  private cleanup: (() => void)[] = [];
  private get locationKey() { return `location-${this.setup.game.map.location}`; }

  constructor(setup: BattleSetup) {
    super({ key: "battle" });
    this.setup = setup;
  }

  preload() {
    this.load.image(this.locationKey, LOCATION_IMAGES[this.setup.game.map.location]);
    for (const unit of ART_UNITS) this.load.image(textureKey(unit), getArtwork(unit).url);
  }

  create() {
    const { game } = this.setup;
    this.prepareBattleTextures();
    this.makeBirdTexture();
    this.createBackground();
    this.staticLayer = this.add.graphics().setDepth(0);
    this.drawStaticWorld(game);
    this.ground = this.add.graphics().setDepth(10);
    this.fx = this.add.graphics().setDepth(1000);
    this.hud = this.add.graphics().setDepth(2000);
    this.hero = this.add.image(0, 0, textureKey("altushka")).setOrigin(0.5, 1);
    this.fpsTime = this.time.now;
    this.bindInput();
    this.setup.onSnapshot(game.snapshot());
  }

  update(_time: number, delta: number) {
    const { game, onSnapshot } = this.setup;
    const elapsed = Math.min(0.1, delta / 1000);
    this.accumulator += elapsed * game.speed;
    let steps = 0;
    while (this.accumulator >= FIXED_STEP && steps < MAX_STEPS) {
      game.update(FIXED_STEP);
      this.accumulator -= FIXED_STEP;
      steps++;
    }
    if (steps === MAX_STEPS) this.accumulator = 0;

    this.unitScale = this.scale.displaySize.width < 600 ? 1.25 : 1;
    this.render(game);

    for (const event of game.events.splice(0)) audio.event(event);
    audio.setMood(game.waveActive, game.enemies.some((e) => e.type === "boss" && !e.dead));

    this.frames++;
    const now = this.time.now;
    if (now - this.fpsTime > 1000) {
      game.fps = Math.round((this.frames * 1000) / (now - this.fpsTime));
      this.frames = 0;
      this.fpsTime = now;
    }
    if (now - this.lastUi > UI_INTERVAL_MS) {
      onSnapshot(game.snapshot());
      this.lastUi = now;
    }
  }

  /** У каждой карты — собственная локация: двор, арка в тупике, котельная. */
  private createBackground() {
    const key = this.locationKey;
    if (!this.textures.exists(key)) return;
    const frame = this.textures.getFrame(key);
    if (!frame || !frame.width || !frame.height) return;
    const scale = Math.max(LOGICAL_WIDTH / frame.width, LOGICAL_HEIGHT / frame.height);
    this.add.image(LOGICAL_WIDTH / 2, LOGICAL_HEIGHT / 2, key)
      .setDisplaySize(frame.width * scale, frame.height * scale).setDepth(-1);
  }

  /** У поля боя персонажи небольшие: уменьшаем только GPU-текстуры,
   * не изменяя оригинальные изображения и изображения в арт-студии. */
  private prepareBattleTextures() {
    const maxDimension = 512;
    for (const unit of ART_UNITS) {
      const key = textureKey(unit);
      if (!this.textures.exists(key)) continue;
      const source = this.textures.get(key).getSourceImage();
      if (!(source instanceof HTMLImageElement) && !(source instanceof HTMLCanvasElement)) continue;
      const width = source.width, height = source.height;
      const ratio = Math.min(1, maxDimension / Math.max(width, height));
      if (ratio === 1 || !width || !height) continue;
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(width * ratio));
      canvas.height = Math.max(1, Math.round(height * ratio));
      const context = canvas.getContext("2d");
      if (!context) continue; // Если Canvas недоступен, остаётся оригинальная текстура.
      context.imageSmoothingEnabled = true;
      context.imageSmoothingQuality = "high";
      context.drawImage(source, 0, 0, canvas.width, canvas.height);
      this.textures.remove(key);
      this.textures.addCanvas(key, canvas);
    }
  }

  // ---------------------------------------------------------------- ввод

  private bindInput() {
    const { game, onSnapshot } = this.setup;
    this.input.mouse?.disableContextMenu();

    const onMove = (pointer: Phaser.Input.Pointer) => { this.pointer = { x: pointer.x, y: pointer.y }; };
    const onDown = (pointer: Phaser.Input.Pointer) => {
      if (pointer.rightButtonDown()) {
        game.targeting = null;
        game.selectedPad = null;
        game.selectedTowerUid = null;
        game.selectedPropUid = null;
        game.selectedSpot = null;
        game.pendingTower = null;
      } else {
        const p = { x: pointer.x, y: pointer.y };
        if (game.targeting) game.castAbility(p.x, p.y);
        else game.selectAt(p.x, p.y);
      }
      onSnapshot(game.snapshot());
    };
    const canvas = this.game.canvas;
    const onLeave = () => { this.pointer = null; };
    this.input.on("pointermove", onMove);
    this.input.on("pointerdown", onDown);
    canvas.addEventListener("pointerleave", onLeave);

    const onBlur = () => {
      if (game.status === "wave" || game.status === "prep") game.paused = true;
      audio.setHidden(true);
      onSnapshot(game.snapshot());
    };
    const onFocus = () => audio.setHidden(false);
    window.addEventListener("blur", onBlur);
    window.addEventListener("focus", onFocus);

    this.cleanup.push(() => {
      this.input.off("pointermove", onMove);
      this.input.off("pointerdown", onDown);
      canvas.removeEventListener("pointerleave", onLeave);
      window.removeEventListener("blur", onBlur);
      window.removeEventListener("focus", onFocus);
    });
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, () => {
      this.cleanup.forEach((fn) => fn());
      this.cleanup = [];
    });
  }

  // ---------------------------------------------------------------- статика

  private makeBirdTexture() {
    if (this.textures.exists(BIRD_KEY)) return;
    const g = this.make.graphics({ x: 0, y: 0 }, false);
    const cx = 40, cy = 30; // центр птицы в текстуре 80x60
    g.fillStyle(0xffffff, 1);
    g.fillTriangle(cx - 2, cy - 12, cx - 30, cy - 8, cx, cy);
    g.fillTriangle(cx + 2, cy - 12, cx + 30, cy - 8, cx, cy);
    g.fillEllipse(cx, cy - 7, 16, 26);
    g.generateTexture(BIRD_KEY, 80, 60);
    g.destroy();
  }

  private drawStaticWorld(game: Game) {
    const g = this.staticLayer;
    // Запасной фон только при ошибке загрузки: иначе изображение должно быть видно.
    if (!this.textures.exists(this.locationKey)) {
      g.fillGradientStyle(0x68727f, 0x68727f, 0x343b46, 0x343b46, 1);
      g.fillRect(0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);
    }
    const location = game.map.location;
    g.fillStyle(0x191f2b, location === "boiler" ? 0.22 : location === "arch" ? 0.18 : 0.34);
    g.fillRect(0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);
    g.fillStyle(hex(game.map.tint), 0.08);
    g.fillRect(0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);
    // Мягкий свет в центре и затемнение по краям.
    for (let i = 0; i < 12; i++) {
      g.fillStyle(0xa6afbc, 0.008);
      g.fillCircle(620, 340, 660 - i * 50);
    }
    for (let i = 0; i < 6; i++) {
      g.lineStyle(26, 0x0a0e18, 0.07);
      g.strokeRect(-13 + i * 6, -13 + i * 6, LOGICAL_WIDTH + 26 - i * 12, LOGICAL_HEIGHT + 26 - i * 12);
    }

    // Дорожки врагов: тёмная основа, светлая полоса и пунктир направления.
    const snowy = location === "boiler";
    for (const path of game.map.paths) {
      g.lineStyle(60, snowy ? 0x2a3a52 : 0x10141a, snowy ? 0.12 : 0.2);
      this.strokePolyline(g, path);
      g.lineStyle(38, snowy ? 0xe4ecf5 : 0xbdb5ab, snowy ? 0.07 : 0.06);
      this.strokePolyline(g, path);
    }
    for (let lane = 0; lane < game.map.paths.length; lane++) {
      for (let d = 60; d < 2600; d += 46) {
        const a = game.pathPoint(lane, d), b = game.pathPoint(lane, d + 14);
        if (a.x < -20 || a.x > LOGICAL_WIDTH + 20 || a.y < -20 || a.y > LOGICAL_HEIGHT + 20) continue;
        if (Math.hypot(b.x - a.x, b.y - a.y) < 4) break;
        g.lineStyle(2, 0xe8d9c8, 0.16);
        g.lineBetween(a.x, a.y, b.x, b.y);
      }
      const p = game.pathPoint(lane, 70), q = game.pathPoint(lane, 82);
      const ang = Math.atan2(q.y - p.y, q.x - p.x);
      const tri = (dx: number, dy: number) => ({ x: p.x + Math.cos(ang) * dx - Math.sin(ang) * dy, y: p.y + Math.sin(ang) * dx + Math.cos(ang) * dy });
      const [t1, t2, t3] = [tri(14, 0), tri(-8, -9), tri(-8, 9)];
      g.fillStyle(0xd0727c, 0.85);
      g.fillTriangle(t1.x, t1.y, t2.x, t2.y, t3.x, t3.y);
    }

    // Защищаемая точка: подъезд или дверь котельной.
    const route = game.map.paths[0];
    const exit = game.map.exit ?? route[route.length - 2];
    const ox = game.map.exit ? -19 : 10, oy = game.map.exit ? -40 : -35;
    g.fillStyle(0xd9a85f, 0.12);
    g.fillCircle(exit.x + ox + 19, exit.y + oy + 26, 46);
    g.fillStyle(0x0d1117, 0.62);
    g.fillRoundedRect(exit.x + ox, exit.y + oy, 38, 52, 3);
    g.lineStyle(1.5, 0xe2c38d, 0.55);
    g.strokeRoundedRect(exit.x + ox, exit.y + oy, 38, 52, 3);
    g.fillStyle(0xe8bd72, 0.42);
    g.fillRect(exit.x + ox + 9, exit.y + oy + 9, 8, 17);
    g.fillRect(exit.x + ox + 22, exit.y + oy + 9, 8, 17);
    this.add.text(exit.x + ox + 19, exit.y + oy + 58, game.map.exitLabel ?? "ПОДЪЕЗД", {
      fontFamily: LABEL_FONT, fontSize: "12px", fontStyle: "600", color: "#f1e6d6",
      stroke: "#0b0e14", strokeThickness: 4, resolution: 2,
    }).setAlpha(0.92).setOrigin(0.5, 0).setDepth(1);

    // Атмосфера локации.
    if (location === "arch") {
      for (const [x, y, r] of [[163, 312, 120], [991, 66, 110], [1040, 520, 150], [270, 370, 70]] as const) {
        for (let i = 0; i < 6; i++) { g.fillStyle(0xf0a24c, 0.025); g.fillCircle(x, y, r - i * 16); }
      }
    } else if (location === "boiler") {
      for (const [x, y, r] of [[780, 160, 170], [800, 260, 120]] as const) {
        for (let i = 0; i < 6; i++) { g.fillStyle(0xf2b35c, 0.02); g.fillCircle(x, y, r - i * 20); }
      }
      g.fillStyle(0x9cc3ff, 0.05);
      g.fillRect(0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);
    }
  }

  private strokePolyline(g: Phaser.GameObjects.Graphics, points: Vec[]) {
    g.beginPath();
    points.forEach((p, i) => (i ? g.lineTo(p.x, p.y) : g.moveTo(p.x, p.y)));
    g.strokePath();
  }

  // ---------------------------------------------------------------- кадр

  private render(game: Game) {
    // Тряска экрана через смещение камеры.
    const trauma = game.shake * game.shake * 11;
    this.cameras.main.setScroll(-Math.sin(game.time * 91) * trauma, -Math.cos(game.time * 77) * trauma * 0.7);

    this.ground.clear();
    this.fx.clear();
    this.hud.clear();
    this.labelCount = 0;

    this.drawPropSpots(game);
    this.drawLinks(game);
    this.drawPads(game);
    this.drawProps(game);
    this.drawEffects(game);
    this.drawSelectionRange(game);
    this.drawEnemyGround(game);

    this.syncSprites(game);
    this.drawHeroOverlay(game);

    this.drawProjectiles(game);
    this.drawParticles(game);
    this.drawWeather(game);
    this.drawTargeting(game);
    this.drawTowerOverlay(game);
    this.drawEnemyOverlay(game);

    for (let i = this.labelCount; i < this.labels.length; i++) this.labels[i].setVisible(false);
  }

  private label(x: number, y: number, text: string, color: string, size = 12, alpha = 1) {
    let t = this.labels[this.labelCount];
    if (!t) {
      t = this.add.text(0, 0, "", {
        fontFamily: FIELD_FONT, fontSize: "12px", fontStyle: "700", color: "#ffffff",
        stroke: "#0a0d13", strokeThickness: 4, resolution: 2,
      }).setOrigin(0.5).setDepth(2001);
      t.setShadow(0, 1, "rgba(0,0,0,0.6)", 3, true, true);
      this.labels.push(t);
    }
    this.labelCount++;
    // Phaser setColor всегда перерисовывает текстовую текстуру, даже если цвет не изменился.
    // Обновляем её только при реальном изменении, чтобы не перегружать кадр.
    if (t.style.color !== color) t.setColor(color);
    t.setText(text).setPosition(x, y).setFontSize(size).setAlpha(alpha).setVisible(true);
    return t;
  }

  private sprite(key: string, texture: string): Phaser.GameObjects.Image {
    let img = this.sprites.get(key);
    if (!img) {
      img = this.add.image(0, 0, texture).setOrigin(0.5, 1);
      this.sprites.set(key, img);
    } else if (img.texture.key !== texture) {
      // Индекс затухающего врага может перейти к другому типу после удаления.
      img.setTexture(texture);
    }
    return img;
  }

  /** Ставит спрайт по ногам (origin внизу) с нужной высотой и глубиной по Y. */
  private place(img: Phaser.GameObjects.Image, x: number, y: number, heightPx: number, depthY: number) {
    img.setPosition(x, y).setScale(heightPx / img.height).setDepth(100 + depthY).setVisible(true);
    return img;
  }

  private syncSprites(game: Game) {
    const used = new Set<string>();
    const us = this.unitScale;
    const t = game.time;

    // Башни (с учётом отдачи после выстрела).
    for (const tower of game.towers) {
      const p = game.padPos(tower.pad);
      const key = `t${tower.uid}`;
      used.add(key);
      const bob = Math.sin(t * 2.2 + tower.uid * 0.7) * 1.2;
      const img = this.sprite(key, textureKey(tower.type));
      this.place(img, p.x, p.y + 4 + bob - tower.recoil * 2, (tower.type === "cat" ? 78 : 100) * us * 0.98, p.y);
      img.setRotation(tower.recoil * 0.04 * tower.facing);
    }

    // Враги.
    for (const enemy of game.enemies) {
      if (enemy.dead) continue;
      const def = ENEMIES[enemy.type];
      const pos = game.enemyPos(enemy);
      const scale = def.scale * (0.4 + enemy.spawnScale * 0.6) * us;
      const key = `e${enemy.uid}`;
      used.add(key);

      if (def.tags.includes("flying")) {
        const img = this.sprite(key, BIRD_KEY);
        img.setPosition(pos.x, pos.y).setScale(scale).setDepth(100 + pos.y).setVisible(true);
        img.setTint(hex(def.color));
        const flap = Math.sin(t * 11 + enemy.wobble);
        img.setScale(scale, scale * (1 + flap * 0.25));
        continue;
      }

      const texture = textureKey(enemy.type === "boss" ? "boss" : "skuf");
      const h = 72 * scale;
      const img = this.sprite(key, texture);
      this.place(img, pos.x, pos.y, h, pos.y);
      const sway = enemy.walking ? Math.sin(t * 9 + enemy.progress * 0.105 + enemy.wobble) * 0.05 : 0;
      img.setRotation(sway);
      if (enemy.flash > 0) img.setTint(0xffb0b0); else img.clearTint();

      if (enemy.type === "crowd") {
        for (const [suffix, dx, s] of [["a", -18, 0.8], ["b", 19, 0.78]] as const) {
          const k = `${key}${suffix}`;
          used.add(k);
          const side = this.sprite(k, textureKey("skuf"));
          this.place(side, pos.x + dx * 0.72 * scale, pos.y + 3 * 0.72 * scale, 100 * 0.72 * s * scale, pos.y - 1);
          side.setRotation(Math.sin(t * 9 + enemy.progress * 0.105 + enemy.wobble) * 0.05 * (suffix === "a" ? 1 : -1));
        }
      }
    }

    // Затухающие враги (погибшие/сбежавшие). Ключ — индекс в массиве.
    game.fadingActors.forEach((actor, i) => {
      const def = ENEMIES[actor.type];
      const progress = 1 - actor.life / actor.maxLife;
      const key = `f${i}`;
      used.add(key);
      if (def.tags.includes("flying")) {
        const img = this.sprite(key, BIRD_KEY).setTint(hex(def.color));
        img.setPosition(actor.x, actor.y).setScale(def.scale * us).setAlpha(1 - progress)
          .setRotation(progress * 0.9).setDepth(100 + actor.y).setVisible(true);
      } else {
        const img = this.sprite(key, textureKey(actor.type === "boss" ? "boss" : "skuf"));
        this.place(img, actor.x, actor.y, 72 * def.scale * us, actor.y).setAlpha(1 - progress).setRotation(progress * 0.9);
        img.clearTint();
      }
    });

    for (const [key, img] of this.sprites) {
      if (!used.has(key)) {
        img.destroy();
        this.sprites.delete(key);
      }
    }
  }

  private drawHeroOverlay(game: Game) {
    const p = game.map.hero;
    this.place(this.hero, p.x, p.y - game.heroRecoil * 2, 138 * this.unitScale, p.y);
    this.label(p.x, p.y + 20, "АЛЬТУШКА", "#f3d3dc", 13);
  }

  // ---------------------------------------------------------------- земля

  private drawPropSpots(game: Game) {
    const g = this.ground;
    for (const spot of game.map.props) {
      if (game.props.some((p) => p.spot === spot.id)) continue;
      const selected = game.selectedSpot === spot.id;
      g.lineStyle(selected ? 2.5 : 1.5, selected ? 0xe2c48f : 0xcdc6b5, selected ? 0.9 : 0.24);
      g.strokeEllipse(spot.x, spot.y, 64, 38);
      g.lineStyle(1.5, 0xd6cfbe, 0.42);
      g.lineBetween(spot.x - 4, spot.y, spot.x + 4, spot.y);
      g.lineBetween(spot.x, spot.y - 4, spot.x, spot.y + 4);
    }
  }

  private drawLinks(game: Game) {
    const g = this.ground;
    for (const link of game.getLinks()) {
      const a = game.padPos(link.a), b = game.padPos(link.b);
      const active = !!game.selectedTower && (game.selectedTower.pad === link.a || game.selectedTower.pad === link.b);
      const start = { x: a.x, y: a.y - 15 };
      const end = { x: b.x, y: b.y - 15 };
      const ctrl = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 - 42 };
      g.lineStyle(active ? 3 : 2, hex(link.color), active ? 0.85 : 0.42);
      g.beginPath();
      for (let i = 0; i <= 24; i++) {
        const t = i / 24, u = 1 - t;
        const x = u * u * start.x + 2 * u * t * ctrl.x + t * t * end.x;
        const y = u * u * start.y + 2 * u * t * ctrl.y + t * t * end.y;
        i ? g.lineTo(x, y) : g.moveTo(x, y);
      }
      g.strokePath();
      if (active) this.label((a.x + b.x) / 2, (a.y + b.y) / 2 - 35, link.name, link.color, 12);
    }
  }

  private drawPads(game: Game) {
    const g = this.ground;
    for (const pad of game.map.pads) {
      const unlocked = game.unlockedPads.includes(pad.id);
      const selected = game.selectedPad === pad.id;
      const occupied = game.towers.some((t) => t.pad === pad.id);
      if (occupied) continue;

      g.fillStyle(0x0d1219, 0.38);
      g.fillEllipse(pad.x, pad.y + 8, 76, 40);
      const color = selected ? 0xd9c6a0 : unlocked && game.pendingTower ? 0xe0c08f : unlocked ? 0xcecfc7 : 0x807d7f;
      const alpha = selected ? 1 : unlocked && game.pendingTower ? 0.8 : unlocked ? 0.48 : 0.25;
      g.lineStyle(selected ? 3 : 2, color, alpha);
      g.strokeEllipse(pad.x, pad.y, 66, 44);

      if (!unlocked) {
        g.fillStyle(0x1a1d25, 0.72);
        g.fillEllipse(pad.x, pad.y, 58, 36);
        g.lineStyle(2, 0xc0b7ac, 0.55);
        g.strokeRect(pad.x - 6, pad.y - 7, 12, 11);
        const affordable = game.wave >= pad.unlockWave;
        this.label(pad.x, pad.y + 30, affordable ? `${pad.unlockCost}` : `ВОЛНА ${pad.unlockWave}`,
          affordable ? "#f0cf86" : "#e2ddd4", 11);
      } else {
        g.lineStyle(2, selected ? 0xe0cba5 : 0xdad7cc, 0.58);
        g.lineBetween(pad.x - 6, pad.y, pad.x + 6, pad.y);
        g.lineBetween(pad.x, pad.y - 6, pad.x, pad.y + 6);
      }
    }
  }

  private drawProps(game: Game) {
    const g = this.ground;
    for (const prop of game.props) {
      const p = game.map.props[prop.spot];
      const selected = game.selectedPropUid === prop.uid;
      if (selected) {
        g.lineStyle(2, 0xe2cda6, 1);
        g.strokeEllipse(p.x, p.y + 4, 84, 50);
      }
      g.fillStyle(0x0a0e13, 0.45);
      g.fillEllipse(p.x, p.y + 11, 60, 20);
      const x = p.x, y = p.y;
      if (prop.type === "sofa") {
        g.fillStyle(0x625861); g.fillRect(x - 29, y - 11, 58, 23);
        g.fillStyle(0x796b72); g.fillRect(x - 25, y - 19, 50, 15);
        g.fillRect(x - 32, y - 14, 8, 24); g.fillRect(x + 24, y - 14, 8, 24);
        g.lineStyle(1, 0xa18c8d); g.lineBetween(x, y - 18, x, y + 8);
      } else if (prop.type === "clothesline") {
        g.lineStyle(4, 0x48454a);
        g.lineBetween(x - 30, y + 12, x - 30, y - 42);
        g.lineBetween(x + 30, y + 12, x + 30, y - 42);
        g.lineStyle(1, 0xa9a3a0);
        g.lineBetween(x - 30, y - 38, x, y - 28); g.lineBetween(x, y - 28, x + 30, y - 38);
        const colors = [0x7c8490, 0x8d6f77, 0xb1a58e];
        colors.forEach((c, i) => { g.fillStyle(c); g.fillRect(x - 20 + i * 17, y - 35 + Math.abs(i - 1) * 3, 13, 22); });
      } else if (prop.type === "dumpster") {
        g.fillStyle(0x455d5b); g.fillRect(x - 25, y - 24, 50, 34);
        g.fillStyle(0x5e7470); g.fillRect(x - 27, y - 26, 54, 9);
        g.lineStyle(1, 0x82918a); g.strokeRect(x - 25, y - 24, 50, 34);
      } else {
        g.fillStyle(0x4d515d); g.fillRoundedRect(x - 34, y - 18, 68, 30, 9);
        g.fillStyle(0x68707c); g.fillRect(x - 17, y - 29, 36, 16);
        g.fillStyle(prop.cooldown > 10.8 ? 0xd86262 : 0xa68c67);
        g.fillRect(x - 30, y - 7, 6, 5); g.fillRect(x + 24, y - 7, 6, 5);
      }
      if (prop.hp < prop.maxHp) {
        g.fillStyle(0x20242b); g.fillRect(x - 25, y + 22, 50, 4);
        g.fillStyle(0xb49b84); g.fillRect(x - 25, y + 22, (50 * prop.hp) / prop.maxHp, 4);
      }
    }
  }

  private drawEffects(game: Game) {
    const g = this.ground;
    for (const effect of game.effects) {
      const alpha = Math.min(1, effect.life * 2);
      const color = effect.kind === "bucket" ? 0x84aec1 : effect.kind === "chord" ? 0xd7b56a : 0xe7a4a4;
      g.fillStyle(color, 0.16 * alpha);
      g.fillCircle(effect.x, effect.y, effect.radius);
      g.lineStyle(3, color, alpha);
      g.strokeCircle(effect.x, effect.y, effect.radius);
    }
  }

  private drawSelectionRange(game: Game) {
    const selected = game.selectedTower;
    if (!selected || selected.type === "kiosk") return;
    const pos = game.padPos(selected.pad);
    const range = game.towerStats(selected).range;
    const color = hex(TOWERS[selected.type].color);
    this.ground.fillStyle(color, 0.05);
    this.ground.fillCircle(pos.x, pos.y, range);
    this.ground.lineStyle(1.5, color, 0.4);
    this.ground.strokeCircle(pos.x, pos.y, range);
  }

  private drawEnemyGround(game: Game) {
    const g = this.ground;
    for (const enemy of game.enemies) {
      if (enemy.dead) continue;
      const p = game.enemyPos(enemy);

      if (enemy.telegraph > 0 && enemy.type === "boss") {
        const radius = enemy.telegraphKind === "slam" ? 220 : 145;
        const pulse = 0.12 + Math.sin(game.time * 14) * 0.05;
        g.fillStyle(0xb94147, pulse);
        g.fillCircle(p.x, p.y, radius);
        g.lineStyle(3, 0xec7570, 0.85);
        g.strokeCircle(p.x, p.y, radius);
        const text = enemy.telegraphKind === "slam" ? "УДАР КЛЮЧАМИ" : enemy.telegraphKind === "summon" ? "ПРИЗЫВ" : "ЯРОСТЬ";
        this.label(p.x, p.y - radius - 14, text, "#ffd2c6", 17);
      }
      if (enemy.type === "loudmouth") {
        g.lineStyle(2, 0xae7bbe, 0.23);
        g.strokeCircle(p.x, p.y, 150 + Math.sin(game.time * 4) * 4);
      }
      g.fillStyle(0x070b10, 0.45);
      g.fillEllipse(p.x, p.y + 9, 34, 16);
    }
  }

  private drawWeather(game: Game) {
    const weather = game.map.weather;
    if (weather === "rain") this.drawRain(game);
    else if (weather === "snow") this.drawSnow(game);
    else this.drawLeaves(game);
  }

  private drawRain(game: Game) {
    const g = this.fx;
    const t = this.time.now / 1000;
    for (const d of this.drops) {
      const y = (((d.y + t * d.speed) % (LOGICAL_HEIGHT + 60)) + LOGICAL_HEIGHT + 60) % (LOGICAL_HEIGHT + 60) - 30;
      const x = ((d.x + t * d.speed * 0.18) % (LOGICAL_WIDTH + 200) + LOGICAL_WIDTH + 200) % (LOGICAL_WIDTH + 200) - 100;
      g.lineStyle(1, 0xbfd3e6, d.alpha);
      g.lineBetween(x, y, x - d.len * 0.18, y - d.len);
    }
    // Круги от капель на асфальте.
    for (let i = 0; i < 14; i++) {
      const phase = (t * 1.4 + i * 0.37) % 1;
      const x = (i * 293 + Math.floor(t * 1.4 + i * 0.37) * 157) % LOGICAL_WIDTH;
      const y = 140 + (i * 181 + Math.floor(t * 1.4 + i * 0.37) * 97) % (LOGICAL_HEIGHT - 160);
      g.lineStyle(1, 0xcfe0ee, 0.22 * (1 - phase));
      g.strokeEllipse(x, y, 4 + phase * 22, 2 + phase * 9);
    }
    void game;
  }

  private drawSnow(game: Game) {
    const g = this.fx;
    const t = this.time.now / 1000;
    for (const f of this.flakes) {
      const x = (((f.x + Math.sin(t * 0.8 + f.phase) * f.drift + t * 14) % LOGICAL_WIDTH) + LOGICAL_WIDTH) % LOGICAL_WIDTH;
      const y = (((f.y + t * f.speed) % LOGICAL_HEIGHT) + LOGICAL_HEIGHT) % LOGICAL_HEIGHT;
      g.fillStyle(0xf4f8ff, 0.55 + (f.size > 2.5 ? 0.25 : 0));
      g.fillCircle(x, y, f.size);
    }
    // Пар из люков теплотрассы и трубы котельной.
    for (const [sx, sy, scale] of [[184, 600, 1], [689, 606, 1], [1030, 70, 1.5]] as const) {
      for (let i = 0; i < 7; i++) {
        const life = (t * 0.32 + i / 7) % 1;
        const r = (14 + life * 38) * scale;
        g.fillStyle(0xe9f0f7, 0.13 * (1 - life));
        g.fillCircle(sx + Math.sin(t + i) * 8 + life * 30 * scale, sy - life * 70 * scale, r);
      }
    }
    void game;
  }

  private drawLeaves(game: Game) {
    const g = this.fx;
    for (const leaf of this.leaves) {
      const x = (((leaf.x + game.time * leaf.speed + Math.sin(game.time * 0.7 + leaf.phase) * leaf.drift) % LOGICAL_WIDTH) + LOGICAL_WIDTH) % LOGICAL_WIDTH;
      const y = (((leaf.y + game.time * leaf.speed * 0.4) % LOGICAL_HEIGHT) + LOGICAL_HEIGHT) % LOGICAL_HEIGHT;
      g.fillStyle(0xd9b98a, 0.5);
      g.fillEllipse(x, y, leaf.size * 2, leaf.size);
    }
  }

  // ---------------------------------------------------------------- верхний слой

  private drawProjectiles(game: Game) {
    const g = this.fx;
    for (const p of game.projectiles) {
      const dx = p.to.x - p.from.x, dy = p.to.y - p.from.y;
      const d = Math.hypot(dx, dy) || 1;
      g.lineStyle(p.type === "heavy" ? 4 : 2, hex(p.color), 0.45);
      g.lineBetween(p.from.x, p.from.y, p.from.x - (dx / d) * 18, p.from.y - (dy / d) * 18);
      g.fillStyle(0xf0e5ce, 1);
      g.fillCircle(p.from.x, p.from.y, p.type === "heavy" ? 4 : 2.5);
    }
  }

  private drawParticles(game: Game) {
    const g = this.fx;
    for (const p of game.particles) {
      const a = Math.max(0, p.life / p.maxLife);
      if (p.kind === "text") {
        this.label(p.x, p.y - (1 - a) * 22, p.text ?? "", p.color, 13, a);
      } else if (p.kind === "ring") {
        g.lineStyle(2, hex(p.color), a);
        g.strokeCircle(p.x, p.y, p.size * (1.6 - a));
      } else if (p.kind === "leaf") {
        g.fillStyle(hex(p.color), a);
        g.fillEllipse(p.x, p.y, p.size * 2, p.size);
      } else {
        g.fillStyle(hex(p.color), a);
        g.fillCircle(p.x, p.y, p.kind === "coin" ? p.size : p.size * a + 0.5);
      }
    }
  }

  private drawTargeting(game: Game) {
    if (!this.pointer || !game.targeting) return;
    const ability = ABILITIES[game.targeting];
    const color = game.targeting === "bucket" ? 0x84aec1 : game.targeting === "chord" ? 0xd7b56a : 0xe7a4a4;
    this.fx.fillStyle(color, 0.12);
    this.fx.fillCircle(this.pointer.x, this.pointer.y, ability.radius);
    this.fx.lineStyle(1.5, color, 0.7);
    this.fx.strokeCircle(this.pointer.x, this.pointer.y, ability.radius);
  }

  private drawTowerOverlay(game: Game) {
    const g = this.hud;
    for (const tower of game.towers) {
      const def = TOWERS[tower.type];
      const p = game.padPos(tower.pad);
      if (tower.disabledUntil > game.time) {
        g.fillStyle(0x71242a, 0.6);
        g.fillCircle(p.x, p.y - 92 * this.unitScale, 10);
        g.lineStyle(2, 0xe59a91, 1);
        g.lineBetween(p.x - 5, p.y - 97 * this.unitScale, p.x + 5, p.y - 87 * this.unitScale);
        g.lineBetween(p.x + 5, p.y - 97 * this.unitScale, p.x - 5, p.y - 87 * this.unitScale);
      }
      if (tower.buffUntil > game.time) {
        g.lineStyle(1.5, 0xe7be69, 0.65);
        g.strokeEllipse(p.x, p.y + 1, (34 + Math.sin(game.time * 6) * 2) * 2, 28);
      }
      for (let i = 0; i < 4; i++) {
        g.fillStyle(i < tower.level ? (i === 3 ? 0xe9c979 : hex(def.color)) : 0xbebebe, i < tower.level ? 1 : 0.2);
        g.fillRect(p.x - 14 + i * 8, p.y + 13, 6, 2.5);
      }
    }
  }

  private drawEnemyOverlay(game: Game) {
    const g = this.hud;
    for (const e of game.enemies) {
      if (e.dead) continue;
      const def = ENEMIES[e.type];
      const p = game.enemyPos(e);
      const scale = def.scale * (0.4 + e.spawnScale * 0.6) * this.unitScale;
      const flying = def.tags.includes("flying");
      if (e.slowUntil > game.time) {
        g.lineStyle(2, 0x9dbed5, 0.75);
        g.strokeEllipse(p.x, p.y + 8, 40, 18);
      }
      if (e.stunUntil > game.time || e.heldUntil > game.time) {
        g.lineStyle(2, 0xe3ca77, 1);
        for (let i = 0; i < 3; i++) {
          const a = game.time * 4 + (i * Math.PI * 2) / 3;
          g.strokeCircle(p.x + Math.cos(a) * 14 * scale, p.y - 108 * scale + Math.sin(a) * 4 * scale, 2);
        }
      }
      if (e.type !== "skuf" && e.type !== "boss") {
        this.label(p.x, p.y - 80 * scale - 12, def.short, def.color, 10);
      }
      if (e.hp < e.maxHp || e.type === "boss" || e.shield > 0) {
        const width = e.type === "boss" ? 100 : 38;
        const y = p.y - (flying ? 42 : 84) * scale;
        g.fillStyle(0x0c0f14, 0.75);
        g.fillRect(p.x - width / 2, y, width, 5);
        g.fillStyle(e.type === "boss" ? 0xb85861 : 0xc7b4a0);
        g.fillRect(p.x - width / 2 + 1, y + 1, (width - 2) * Math.max(0, e.hp / e.maxHp), 3);
        if (e.maxShield > 0 && e.shield > 0) {
          g.fillStyle(0x7da6c2);
          g.fillRect(p.x - width / 2, y - 4, width * (e.shield / e.maxShield), 2);
        }
      }
    }
  }
}
