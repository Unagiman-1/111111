import { useSyncExternalStore } from "react";
import { getArtwork, getArtVersion, subscribeArt } from "../game/art-library";
import { ART_NAMES, type ArtUnit } from "../game/art-types";

export function ArtPortrait({ unit, alt = "", className = "" }: { unit: ArtUnit; alt?: string; className?: string }) {
  useSyncExternalStore(subscribeArt, getArtVersion);
  const art = getArtwork(unit);
  return <img className={`art-portrait ${className}`} src={art.url} alt={alt || ART_NAMES[unit]} data-art-source={art.source} draggable={false} />;
}
