import { useEffect, useState, type CSSProperties } from "react";
import courtyardImage from "../art/locations/courtyard.jpg?inline";
import archImage from "../art/locations/arch.jpg?inline";
import boilerImage from "../art/locations/boiler.jpg?inline";
import { ArrowRight, BookOpen, CloudRain, ImagePlus, Infinity as InfinityIcon, Leaf, LockKeyhole, Music2, Play, Snowflake, Star, Users, X } from "lucide-react";
import { MAPS, TOWERS } from "../game/data";
import { audio } from "../game/audio";
import { dailySeed, type MetaState } from "../game/meta";
import type { GameMode, MapDef } from "../game/types";
import { LiveHero } from "./LiveHero";
import { ArtPortrait } from "./ArtPortrait";
import { ArtStudio } from "./ArtStudio";
import { restoreArtwork } from "../game/art-library";
import { CreditsModal, SoundButton } from "./SoundControls";

export const LOCATION_ART: Record<MapDef["location"], string> = { courtyard: courtyardImage, arch: archImage, boiler: boilerImage };
const weatherIcon = { leaves: <Leaf size={12} />, rain: <CloudRain size={12} />, snow: <Snowflake size={12} /> };
const weatherName = { leaves: "листопад", rain: "ливень", snow: "метель" };

export function MainMenu({ meta, onStart }: { meta: MetaState; onStart: (mapId: string, mode: GameMode, seed: number) => void }) {
  const [mapId, setMapId] = useState("yard");
  const [mode, setMode] = useState<GameMode>("campaign");
  const [codex, setCodex] = useState(false);
  const [studio, setStudio] = useState(false);
  const [credits, setCredits] = useState(false);
  const map = MAPS.find((item) => item.id === mapId) ?? MAPS[0];
  const daily = dailySeed();

  useEffect(() => { audio.playMusic("menu"); }, []);

  const start = async () => {
    audio.ui();
    await restoreArtwork();
    try { await audio.start(); } catch (error) { console.warn("Звук недоступен:", error); }
    onStart(mapId, mode, mode === "endless" ? daily.seed : (Date.now() & 0xffffffff));
  };

  const bestScore = Math.max(0, ...Object.values(meta.records).map((r) => r.bestScore));

  return (
    <main className="menu-screen" style={{ "--courtyard-image": `url("${LOCATION_ART[map.location]}")` } as CSSProperties}>
      <div className="menu-backdrop" key={map.location} />
      <div className="menu-grain" />
      <header className="menu-header">
        <div className="brand-mark"><span className="brand-sigil">А</span><span>АЛЬТУШКА<br /><b>TOWER DEFENSE</b></span></div>
        <div className="menu-header-center">СЕВЕРНЫЙ РАЙОН <i /> 03:47 <i /> СМЕНА {String(meta.runs + 1).padStart(2, "0")}</div>
        <div className="menu-actions">
          <button className="text-button studio-launch" onClick={() => { audio.ui(); void restoreArtwork().then(() => setStudio(true)); }}><ImagePlus size={16} /> Арты</button>
          <button className="text-button" onClick={() => { audio.ui(); setCodex(true); }}><Users size={16} /> Жители</button>
          <button className="text-button" onClick={() => { audio.ui(); setCredits(true); }}><Music2 size={16} /> Саундтрек</button>
          <SoundButton />
        </div>
      </header>

      <section className="menu-hero">
        <div className="menu-copy">
          <div className="eyebrow"><span /> ЖИВОЙ ДВОР · ВЕРСИЯ 2.1</div>
          <h1>Альтушка</h1>
          <div className="title-sub"><b>TOWER DEFENSE</b><span>Двор помнит каждого,<br />кого ты не впустила.</span></div>
          <p className="menu-quote">«Они пришли за тишиной.<br />Ошиблись адресом.»</p>
        </div>
        <div className="menu-altushka" aria-label="Альтушка">
          <div className="portrait-halo" />
          <LiveHero />
          <div className="hero-caption"><span>ГЕРОИНЯ · 01</span><b>Альтушка</b><small>Гитара, капюшон и ни шагу назад.</small></div>
        </div>
        <div className="menu-side-note">
          <span>20</span><p>авторских<br />волн</p><i />
          <span>12</span><p>типов<br />врагов</p><i />
          <span>3</span><p>разные<br />локации</p>
        </div>
      </section>

      <section className="run-setup">
        <div className="mode-switch" role="group" aria-label="Режим игры">
          <button className={mode === "campaign" ? "active" : ""} onClick={() => { audio.ui(); setMode("campaign"); }}><Play size={15} /> Кампания <small>20 волн</small></button>
          <button className={mode === "endless" ? "active" : ""} onClick={() => { audio.ui(); setMode("endless"); }}><InfinityIcon size={17} /> Ночной двор <small>сид дня</small></button>
        </div>
        <div className="map-selector">
          {MAPS.map((item, index) => {
            const locked = meta.totalStars < item.requiredStars;
            const record = meta.records[item.id];
            return (
              <button
                key={item.id}
                disabled={locked}
                className={`map-card ${mapId === item.id ? "selected" : ""}`}
                onMouseEnter={() => !locked && audio.ui("hover")}
                onClick={() => { audio.ui(); setMapId(item.id); }}
              >
                <div className="map-thumb" style={{ backgroundImage: `linear-gradient(0deg, rgba(14,17,24,.55), rgba(14,17,24,.05)), url("${LOCATION_ART[item.location]}")` }}>
                  {locked && <LockKeyhole size={20} />}<b>0{index + 1}</b>
                </div>
                <div className="map-card-copy">
                  <small>{item.subtitle}</small>
                  <strong>{item.name}</strong>
                  <span className="map-meta">
                    <span className="map-weather">{weatherIcon[item.weather]} {weatherName[item.weather]}</span>
                    <span className="map-stars">{locked ? `нужно ${item.requiredStars} ★` : [0, 1, 2].map((star) => <Star key={star} size={12} fill={star < (record?.stars ?? 0) ? "currentColor" : "none"} />)}</span>
                  </span>
                </div>
              </button>
            );
          })}
        </div>
        <div className="launch-block">
          <div className="selected-map-info"><small>{mode === "campaign" ? "ВЫБРАННАЯ СМЕНА" : `СИД ДНЯ · ${daily.label}`}</small><b>{map.name}</b><p>{map.description}</p></div>
          <button className="launch-button" onClick={start}><span>{mode === "campaign" ? "Войти во двор" : "Начать ночь"}</span><ArrowRight size={22} /></button>
          <div className="meta-line"><Star size={13} fill="currentColor" /> {meta.totalStars} звёзд собрано <span /> лучший счёт {bestScore.toLocaleString("ru-RU")}</div>
        </div>
      </section>

      <footer className="menu-footer"><span>1–6 — ЖИТЕЛИ · F — ВОЛНА</span><span>Q / W / E — СПОСОБНОСТИ</span><span>ПРОБЕЛ — ПАУЗА</span></footer>

      {codex && (
        <div className="modal-backdrop" onMouseDown={() => setCodex(false)}>
          <section className="codex-modal" onMouseDown={(e) => e.stopPropagation()}>
            <header><div><small>ЛЮДИ, КОТОРЫЕ НЕ СДАЮТСЯ</small><h2>Жители двора</h2></div><button className="icon-button" onClick={() => setCodex(false)} aria-label="Закрыть"><X /></button></header>
            <div className="codex-grid">
              {Object.values(TOWERS).map((tower) => (
                <article className="codex-person" key={tower.id}>
                  <ArtPortrait unit={tower.id} alt={tower.name} />
                  <div><small>{tower.role}</small><h3>{tower.name}</h3><p>{tower.description}</p><span>{tower.cost} монет · {tower.branches[0].name} / {tower.branches[1].name}</span></div>
                </article>
              ))}
            </div>
            <div className="codex-tip"><BookOpen size={18} /><p><b>Соседские связи.</b> Динамик усиливает Бабу Валю против замедленных врагов, Дозорный даёт Коту криты по удерживаемым, а выручка киоска ускоряет соседей.</p></div>
          </section>
        </div>
      )}
      {credits && <CreditsModal onClose={() => setCredits(false)} />}
      {studio && <ArtStudio onClose={() => setStudio(false)} />}
    </main>
  );
}
