import { useEffect, useRef } from "react";
import Phaser from "phaser";
import { LOGICAL_HEIGHT, LOGICAL_WIDTH } from "../game/data";
import type { Game } from "../game/engine";
import type { Snapshot } from "../game/types";
import { BattleScene } from "../phaser/BattleScene";

/** Монтирует Phaser-игру в React. Состояние боя и UI-снимки передаются наружу через колбэк. */
export function GameCanvas({ game, onSnapshot }: { game: Game; onSnapshot: (snapshot: Snapshot) => void }) {
  const hostRef = useRef<HTMLDivElement>(null);
  const snapshotRef = useRef(onSnapshot);
  snapshotRef.current = onSnapshot;

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    let instance: Phaser.Game | null = null;
    let cancelled = false;
    // Шрифты подписей должны быть загружены до того, как Phaser отрисует текст.
    const fontsReady = Promise.race([
      Promise.all([
        document.fonts?.load('700 12px "Manrope Variable"'),
        document.fonts?.load('600 12px "Oswald Variable"'),
      ]).catch(() => undefined),
      new Promise((resolve) => setTimeout(resolve, 1200)),
    ]);
    void fontsReady.then(() => {
      if (cancelled) return;
      const scene = new BattleScene({ game, onSnapshot: (snapshot) => snapshotRef.current(snapshot) });
      instance = new Phaser.Game({
      type: Phaser.AUTO,
      parent: host,
      width: LOGICAL_WIDTH,
      height: LOGICAL_HEIGHT,
      backgroundColor: "#171b24",
      banner: false,
      audio: { noAudio: true },
      scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH },
      scene: [scene],
      });
    });
    return () => { cancelled = true; instance?.destroy(true); };
  }, [game]);

  return (
    <div
      ref={hostRef}
      className="game-canvas"
      role="img"
      aria-label="Игровое поле: двор, дорожки врагов и площадки для защитников"
    />
  );
}
