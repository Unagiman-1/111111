import { ArtPortrait } from "./ArtPortrait";

export function LiveHero() {
  return (
    <div className="live-hero-doll">
      <ArtPortrait unit="altushka" alt="Альтушка" className="source-figure" />
    </div>
  );
}
