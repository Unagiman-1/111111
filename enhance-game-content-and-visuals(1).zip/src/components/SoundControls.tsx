import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import { Music2, Volume2, VolumeX, X, Headphones } from "lucide-react";
import { audio, MUSIC_TRACKS, SFX_CREDITS } from "../game/audio";

function useAudioState() {
  useSyncExternalStore(audio.subscribe, audio.getVersion);
  return { enabled: audio.isEnabled, music: audio.musicVolume, sfx: audio.sfxVolume };
}

/** Кнопка звука с выпадающей панелью громкости. */
export function SoundButton({ className = "", align = "right" }: { className?: string; align?: "left" | "right" }) {
  const { enabled, music, sfx } = useAudioState();
  const [open, setOpen] = useState(false);
  const [credits, setCredits] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  const [, force] = useState(0);

  useEffect(() => {
    if (!open) return;
    const close = (event: PointerEvent) => { if (!root.current?.contains(event.target as Node)) setOpen(false); };
    const tick = window.setInterval(() => force((n) => n + 1), 800);
    window.addEventListener("pointerdown", close);
    return () => { window.removeEventListener("pointerdown", close); window.clearInterval(tick); };
  }, [open]);

  const playing = audio.nowPlaying ? MUSIC_TRACKS[audio.nowPlaying] : null;

  return (
    <div className={`sound-control ${className}`} ref={root}>
      <button
        className={`icon-button ${open ? "active" : ""}`}
        aria-label="Настройки звука"
        title="Звук и музыка"
        onClick={() => { void audio.start(); setOpen((v) => !v); audio.ui(); }}
      >
        {enabled ? <Volume2 size={18} /> : <VolumeX size={18} />}
      </button>
      {open && (
        <div className={`sound-popover ${align}`} role="dialog" aria-label="Звук">
          <div className="sound-popover-head">
            <span>ЗВУК</span>
            <button className={`sound-toggle ${enabled ? "on" : ""}`} onClick={() => { audio.toggle(); audio.ui(); }}>
              {enabled ? "Включён" : "Выключен"}
            </button>
          </div>
          <label className="sound-slider">
            <span><Music2 size={14} /> Музыка <b>{Math.round(music * 100)}%</b></span>
            <input type="range" min={0} max={100} value={Math.round(music * 100)} onChange={(e) => audio.setMusicVolume(Number(e.target.value) / 100)} />
          </label>
          <label className="sound-slider">
            <span><Headphones size={14} /> Эффекты <b>{Math.round(sfx * 100)}%</b></span>
            <input type="range" min={0} max={100} value={Math.round(sfx * 100)} onChange={(e) => audio.setSfxVolume(Number(e.target.value) / 100)} onMouseUp={() => audio.event("coin")} onTouchEnd={() => audio.event("coin")} />
          </label>
          {playing && (
            <div className="now-playing">
              <span className="eq" aria-hidden><i /><i /><i /><i /></span>
              <div><small>СЕЙЧАС ИГРАЕТ</small><b>{playing.title}</b><em>{playing.author}</em></div>
            </div>
          )}
          <button className="sound-credits-link" onClick={() => { setCredits(true); setOpen(false); }}>Авторы музыки и звуков</button>
        </div>
      )}
      {credits && <CreditsModal onClose={() => setCredits(false)} />}
    </div>
  );
}

export function CreditsModal({ onClose }: { onClose: () => void }) {
  return (
    <div className="modal-backdrop" onMouseDown={onClose}>
      <section className="credits-modal" onMouseDown={(e) => e.stopPropagation()}>
        <header>
          <div><small>САУНДТРЕК И ЗВУКИ</small><h2>Что звучит во дворе</h2></div>
          <button className="icon-button" onClick={onClose} aria-label="Закрыть"><X /></button>
        </header>
        <h3>Музыка</h3>
        <ul className="credits-list">
          {Object.entries(MUSIC_TRACKS).map(([key, track]) => (
            <li key={key}>
              <b>«{track.title}»</b>
              <span>{track.author} · incompetech.com</span>
              <em>{track.usage}</em>
            </li>
          ))}
        </ul>
        <p className="credits-license">Музыка: Kevin MacLeod (incompetech.com). Лицензия Creative Commons: By Attribution 4.0.</p>
        <h3>Звуковые эффекты</h3>
        <ul className="credits-list">
          {SFX_CREDITS.map((credit) => (
            <li key={credit.title}><b>{credit.title}</b><span>{credit.author}</span><em>{credit.license}</em></li>
          ))}
        </ul>
        <p className="credits-license">Сковородки Бабы Вали, звон монет киоска, ключи управдома и хлопок двери подъезда — живые записи из этих наборов.</p>
      </section>
    </div>
  );
}
