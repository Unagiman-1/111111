import { ART_UNITS, type Artwork, type ArtUnit, type BackgroundKey } from "./art-types";
import { removeEdgeBackground } from "./alpha-mask";
import { unitArtUrl } from "./unit-assets";

const records = new Map<ArtUnit, Artwork>();
const listeners = new Set<() => void>();
let version = 0;
let revision = 0;
let restorePromise: Promise<void> | null = null;

const emit = () => { version++; for (const listener of listeners) listener(); };
export const subscribeArt = (listener: () => void) => { listeners.add(listener); return () => { listeners.delete(listener); }; };
export const getArtVersion = () => version;

function loadImage(record: Artwork) {
  record.image.onload = () => {
    record.ready = true;
    record.width = record.image.naturalWidth;
    record.height = record.image.naturalHeight;
    emit();
  };
  record.image.decoding = "async";
  record.image.src = record.url;
}

export function getArtwork(unit: ArtUnit): Artwork {
  const existing = records.get(unit);
  if (existing) return existing;
  const record: Artwork = {
    unit, url: unitArtUrl(unit), originalUrl: unitArtUrl(unit),
    image: new Image(), revision: ++revision, source: "builtin", filename: `source-${unit}.webp`,
    width: 848, height: 1264,
    fullBody: true, ready: false, key: "none",
  };
  records.set(unit, record);
  loadImage(record);
  return record;
}

interface SavedArt { unit: ArtUnit; original: Blob; cutout: Blob; filename: string; fullBody: boolean; key: BackgroundKey }

function database(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("altushka-original-art-v1", 1);
    request.onupgradeneeded = () => request.result.createObjectStore("art", { keyPath: "unit" });
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(new Error("Не удалось открыть локальное хранилище"));
  });
}

async function persist(art: SavedArt | ArtUnit) {
  const db = await database();
  try {
    await new Promise<void>((resolve, reject) => {
      const transaction = db.transaction("art", "readwrite");
      if (typeof art === "string") transaction.objectStore("art").delete(art);
      else transaction.objectStore("art").put(art);
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(new Error("Недостаточно места для сохранения арта"));
      transaction.onabort = () => reject(new Error("Сохранение арта отменено"));
    });
  } finally { db.close(); }
}

function install(saved: SavedArt) {
  const old = records.get(saved.unit);
  const record: Artwork = {
    unit: saved.unit, url: URL.createObjectURL(saved.cutout), originalUrl: URL.createObjectURL(saved.original),
    image: new Image(), revision: ++revision, source: "uploaded", filename: saved.filename,
    width: 512, height: 768, fullBody: saved.fullBody, ready: false, key: saved.key,
  };
  records.set(saved.unit, record);
  loadImage(record);
  if (old?.source === "uploaded") { URL.revokeObjectURL(old.url); URL.revokeObjectURL(old.originalUrl); }
  emit();
}

export function restoreArtwork(): Promise<void> {
  if (!restorePromise) restorePromise = restoreFromDatabase();
  return restorePromise;
}

async function restoreFromDatabase() {
  for (const unit of ART_UNITS) getArtwork(unit);
  try {
    const db = await database();
    const saved = await new Promise<SavedArt[]>((resolve, reject) => {
      const request = db.transaction("art").objectStore("art").getAll();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    db.close();
    for (const art of saved) if (ART_UNITS.includes(art.unit)) install(art);
  } catch { /* The game remains usable when browser storage is unavailable. */ }
}

export async function importArtwork(unit: ArtUnit, file: File, key: BackgroundKey, fullBody: boolean): Promise<{ persisted: boolean; removed: number }> {
  if (!/^image\/(png|jpeg|webp)$/.test(file.type)) throw new Error("Нужен PNG, JPEG или WebP. SVG и анимированные файлы не поддерживаются.");
  if (file.size > 20 * 1024 * 1024) throw new Error("Максимальный размер исходника: 20 МБ.");
  const image = await createImageBitmap(file, { imageOrientation: "from-image" });
  try {
    if (image.width * image.height > 20_000_000) throw new Error("Максимальное разрешение: 20 мегапикселей.");
    const canvas = document.createElement("canvas");
    canvas.width = image.width;
    canvas.height = image.height;
    const context = canvas.getContext("2d", { willReadFrequently: true });
    if (!context) throw new Error("Canvas недоступен в этом браузере.");
    context.drawImage(image, 0, 0);
    const pixels = context.getImageData(0, 0, image.width, image.height);
    const { removed, applied } = removeEdgeBackground(pixels.data, image.width, image.height, key);
    let visible = false;
    for (let i = 3; i < pixels.data.length; i += 4) if (pixels.data[i] > 0) { visible = true; break; }
    if (!visible) throw new Error("После удаления фона изображение пустое. Выбери «Без удаления».");
    context.putImageData(pixels, 0, 0);
    const cutout = await new Promise<Blob>((resolve, reject) => canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error("Не удалось подготовить PNG")), "image/png"));
    const saved: SavedArt = { unit, original: file, cutout, filename: file.name, fullBody, key: applied };
    let persisted = true;
    try { await persist(saved); } catch { persisted = false; }
    install(saved);
    return { persisted, removed };
  } finally { image.close(); }
}

export async function resetArtwork(unit: ArtUnit) {
  // Remove the persisted override first; a failed transaction must not pretend to reset it.
  await persist(unit);
  const old = records.get(unit);
  if (old?.source === "uploaded") { URL.revokeObjectURL(old.url); URL.revokeObjectURL(old.originalUrl); }
  records.delete(unit);
  getArtwork(unit);
  emit();
}