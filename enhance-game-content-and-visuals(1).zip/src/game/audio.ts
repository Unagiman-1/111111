/**
 * Звук «Альтушка TD».
 * Музыка — треки Kevin MacLeod (incompetech.com, CC BY 4.0), звуки — CC0-наборы
 * Kenney и OpenGameArt. Всё встроено в сборку, поэтому игра звучит и без интернета.
 */
import menuTrack from "../audio/music/menu-lightless-dawn.mp3?inline";
import yardTrack from "../audio/music/yard-hitman.mp3?inline";
import archTrack from "../audio/music/arch-night-on-the-docks.mp3?inline";
import boilerTrack from "../audio/music/boiler-darkling.mp3?inline";
import bossTrack from "../audio/music/boss-volatile-reaction.mp3?inline";

const sfxModules = import.meta.glob("../audio/sfx/*.mp3", { eager: true, query: "?inline", import: "default" }) as Record<string, string>;
const SFX_URLS: Record<string, string> = Object.fromEntries(
  Object.entries(sfxModules).map(([path, url]) => [path.split("/").pop()!.replace(".mp3", ""), url]),
);

export type MusicKey = "menu" | "yard" | "arch" | "boiler" | "boss";

export const MUSIC_TRACKS: Record<MusicKey, { title: string; author: string; usage: string; url: string }> = {
  menu: { title: "Lightless Dawn", author: "Kevin MacLeod", usage: "Главное меню", url: menuTrack },
  yard: { title: "Hitman", author: "Kevin MacLeod", usage: "Двор на Осыпной", url: yardTrack },
  arch: { title: "Night on the Docks — Sax", author: "Kevin MacLeod", usage: "Арка на Ломаной", url: archTrack },
  boiler: { title: "Darkling", author: "Kevin MacLeod", usage: "Котельная «Рассвет»", url: boilerTrack },
  boss: { title: "Volatile Reaction", author: "Kevin MacLeod", usage: "Управдом Гена (босс)", url: bossTrack },
};

export const SFX_CREDITS = [
  { title: "RPG Sound Pack", author: "Kenney", license: "CC0" },
  { title: "UI SFX Set", author: "Kenney", license: "CC0" },
  { title: "100 CC0 SFX", author: "rubberduck · OpenGameArt", license: "CC0" },
];

const SETTINGS_KEY = "altushka-td-audio-v1";
interface AudioSettings { music: number; sfx: number; enabled: boolean }

function loadSettings(): AudioSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) return { music: 0.55, sfx: 0.8, enabled: true, ...JSON.parse(raw) };
  } catch { /* приватный режим */ }
  return { music: 0.55, sfx: 0.8, enabled: true };
}

interface Sample { name: string; volume?: number; delay?: number; rate?: number; jitter?: number }

class AudioDirector {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  private buffers = new Map<string, AudioBuffer>();
  private loading: Promise<void> | null = null;
  private lastSfx = new Map<string, number>();
  private noise: AudioBuffer | null = null;

  private tracks = new Map<MusicKey, HTMLAudioElement>();
  private trackTargets = new Map<MusicKey, number>();
  private baseTrack: MusicKey = "menu";
  private currentTrack: MusicKey | null = null;
  private fadeTimer: number | null = null;
  private activeWave = false;
  private boss = false;
  private hidden = false;
  private unlocked = false;

  private settings = loadSettings();
  private listeners = new Set<() => void>();
  private version = 0;

  // ------------------------------------------------------------ жизненный цикл

  async start() {
    this.unlocked = true;
    if (!this.ctx) this.init();
    if (this.ctx?.state === "suspended") { try { await this.ctx.resume(); } catch { /* жест не засчитан */ } }
    void this.loadSamples();
    this.updateMusic(true);
  }

  private init() {
    const Ctx = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    this.ctx = ctx;
    this.master = ctx.createGain();
    this.master.gain.value = this.settings.enabled ? 1 : 0;
    this.sfxBus = ctx.createGain();
    this.sfxBus.gain.value = this.settings.sfx;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -14; comp.ratio.value = 4;
    this.sfxBus.connect(comp); comp.connect(this.master); this.master.connect(ctx.destination);
    const buffer = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    this.noise = buffer;
  }

  private loadSamples() {
    if (this.loading || !this.ctx) return this.loading;
    const ctx = this.ctx;
    this.loading = Promise.all(Object.entries(SFX_URLS).map(async ([name, url]) => {
      try {
        const data = await (await fetch(url)).arrayBuffer();
        const decoded = await new Promise<AudioBuffer>((resolve, reject) => ctx.decodeAudioData(data, resolve, reject));
        this.buffers.set(name, decoded);
      } catch (error) { console.warn(`Звук ${name} не загружен`, error); }
    })).then(() => undefined);
    return this.loading;
  }

  // ------------------------------------------------------------ музыка

  playMusic(key: Exclude<MusicKey, "boss">) {
    this.baseTrack = key;
    if (key === "menu") { this.boss = false; this.activeWave = false; }
    this.updateMusic();
  }

  setMood(activeWave: boolean, boss: boolean) {
    if (activeWave === this.activeWave && boss === this.boss) return;
    this.activeWave = activeWave;
    this.boss = boss;
    this.updateMusic();
  }

  private track(key: MusicKey) {
    let el = this.tracks.get(key);
    if (!el) {
      el = new Audio(MUSIC_TRACKS[key].url);
      el.loop = true;
      el.preload = "auto";
      el.volume = 0;
      this.tracks.set(key, el);
    }
    return el;
  }

  private updateMusic(forcePlay = false) {
    if (!this.unlocked) return;
    const target: MusicKey = this.boss && this.baseTrack !== "menu" ? "boss" : this.baseTrack;
    const audible = this.settings.enabled && !this.hidden;
    const intensity = target === "menu" || target === "boss" || this.activeWave ? 1 : 0.62;
    const level = audible ? this.settings.music * intensity : 0;

    if (target !== this.currentTrack) {
      const el = this.track(target);
      if (target === "boss" || this.currentTrack === null || this.currentTrack === "menu" || target === "menu") el.currentTime = 0;
      this.currentTrack = target;
    }
    for (const key of this.tracks.keys()) this.trackTargets.set(key, key === target ? level : 0);
    this.trackTargets.set(target, level);

    const el = this.track(target);
    if ((el.paused || forcePlay) && level > 0) el.play().catch(() => { /* ждём следующего жеста */ });
    this.runFade();
  }

  private runFade() {
    if (this.fadeTimer !== null) return;
    this.fadeTimer = window.setInterval(() => {
      let busy = false;
      for (const [key, el] of this.tracks) {
        const target = this.trackTargets.get(key) ?? 0;
        const diff = target - el.volume;
        if (Math.abs(diff) > 0.01) {
          el.volume = Math.min(1, Math.max(0, el.volume + Math.sign(diff) * Math.min(Math.abs(diff), 0.035)));
          busy = true;
        } else {
          el.volume = target;
          if (target === 0 && !el.paused) el.pause();
        }
      }
      if (!busy && this.fadeTimer !== null) { window.clearInterval(this.fadeTimer); this.fadeTimer = null; }
    }, 50);
  }

  // ------------------------------------------------------------ сэмплы и синтез

  private play(sample: Sample) {
    const ctx = this.ctx, buffer = this.buffers.get(sample.name);
    if (!ctx || !buffer || !this.sfxBus) return false;
    const src = ctx.createBufferSource(), gain = ctx.createGain();
    src.buffer = buffer;
    const jitter = sample.jitter ?? 0.06;
    src.playbackRate.value = (sample.rate ?? 1) * (1 + (Math.random() * 2 - 1) * jitter);
    gain.gain.value = sample.volume ?? 0.6;
    src.connect(gain); gain.connect(this.sfxBus);
    src.start(ctx.currentTime + (sample.delay ?? 0));
    return true;
  }

  private note(time: number, frequency: number, duration: number, volume: number, type: OscillatorType, endFrequency?: number) {
    if (!this.ctx || !this.sfxBus) return;
    const osc = this.ctx.createOscillator(), gain = this.ctx.createGain();
    osc.type = type; osc.frequency.setValueAtTime(frequency, time);
    if (endFrequency) osc.frequency.exponentialRampToValueAtTime(endFrequency, time + duration);
    gain.gain.setValueAtTime(0.0001, time); gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, volume), time + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, time + duration);
    osc.connect(gain); gain.connect(this.sfxBus); osc.start(time); osc.stop(time + duration + 0.03);
  }

  /** Гитарный аккорд «Разрывного аккорда»: струны с щипковой огибающей. */
  private strum(time: number, freqs: number[], volume: number) {
    if (!this.ctx || !this.sfxBus) return;
    freqs.forEach((f, i) => {
      const t = time + i * 0.028;
      const osc = this.ctx!.createOscillator(), filter = this.ctx!.createBiquadFilter(), gain = this.ctx!.createGain();
      osc.type = "sawtooth"; osc.frequency.value = f;
      filter.type = "lowpass"; filter.frequency.setValueAtTime(3200, t); filter.frequency.exponentialRampToValueAtTime(500, t + 0.9);
      gain.gain.setValueAtTime(0.0001, t); gain.gain.exponentialRampToValueAtTime(volume, t + 0.008);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 1.3);
      osc.connect(filter); filter.connect(gain); gain.connect(this.sfxBus!); osc.start(t); osc.stop(t + 1.35);
    });
  }

  private noiseBurst(time: number, volume: number, freq: number, duration: number) {
    if (!this.ctx || !this.noise || !this.sfxBus) return;
    const src = this.ctx.createBufferSource(), filter = this.ctx.createBiquadFilter(), gain = this.ctx.createGain();
    src.buffer = this.noise; filter.type = "bandpass"; filter.frequency.value = freq; filter.Q.value = 0.8;
    gain.gain.setValueAtTime(volume, time); gain.gain.exponentialRampToValueAtTime(0.0001, time + duration);
    src.connect(filter); filter.connect(gain); gain.connect(this.sfxBus); src.start(time); src.stop(time + duration + 0.02);
  }

  private pick(...names: string[]) { return names[Math.floor(Math.random() * names.length)]; }

  event(name: string) {
    if (!this.ctx || !this.settings.enabled || this.hidden) return;
    const now = this.ctx.currentTime;
    const throttle = name === "shot" ? 0.07 : name === "heavy" ? 0.12 : name === "coin" ? 0.09 : name === "hero" ? 0.1 : name === "speaker" ? 0.18 : 0.03;
    if (now - (this.lastSfx.get(name) ?? -10) < throttle) return;
    this.lastSfx.set(name, now);

    switch (name) {
      case "shot":
        if (!this.play({ name: this.pick("shot1", "shot2"), volume: 0.2, jitter: 0.12 })) this.note(now, 330, 0.05, 0.02, "square");
        break;
      case "hero":
        this.play({ name: "slice", volume: 0.16, rate: 1.25 });
        this.note(now, 660, 0.12, 0.018, "triangle"); this.note(now + 0.03, 990, 0.1, 0.01, "triangle");
        break;
      case "heavy":
        if (!this.play({ name: this.pick("pan1", "pan2", "pan3"), volume: 0.42, jitter: 0.08 })) this.note(now, 95, 0.12, 0.06, "square");
        break;
      case "speaker":
        this.note(now, 82, 0.32, 0.06, "sawtooth", 55); this.note(now, 41, 0.35, 0.07, "sine");
        break;
      case "coin":
        if (!this.play({ name: this.pick("coin1", "coin2"), volume: 0.42 })) { this.note(now, 880, 0.08, 0.04, "sine"); this.note(now + 0.06, 1174, 0.1, 0.03, "sine"); }
        break;
      case "build":
        this.play({ name: "build1", volume: 0.6 }); this.play({ name: "build2", volume: 0.45, delay: 0.06 });
        this.note(now, 220, 0.12, 0.025, "triangle"); this.note(now + 0.08, 330, 0.16, 0.022, "triangle");
        break;
      case "upgrade":
        this.play({ name: "latch", volume: 0.5 }); this.play({ name: "bell-short", volume: 0.35, delay: 0.08, jitter: 0 });
        [392, 523.25, 659.25].forEach((f, i) => this.note(now + 0.05 + i * 0.07, f, 0.22, 0.025, "triangle"));
        break;
      case "wave":
        this.play({ name: "door-open", volume: 0.6, rate: 0.9 });
        this.note(now, 110, 0.6, 0.05, "sawtooth", 82);
        break;
      case "waveClear":
        this.play({ name: "bell-long", volume: 0.42, jitter: 0 });
        [261.63, 329.63, 392].forEach((f, i) => this.note(now + i * 0.11, f, 0.45, 0.03, "triangle"));
        break;
      case "boss":
        this.play({ name: "gong", volume: 0.7, rate: 0.85, jitter: 0 }); this.play({ name: "slam", volume: 0.5, delay: 0.05 });
        this.note(now, 55, 1.1, 0.09, "sawtooth"); this.note(now, 58.3, 1.1, 0.05, "square");
        break;
      case "bossDown":
        this.play({ name: "explosion", volume: 0.7, rate: 0.8 }); this.play({ name: "gong", volume: 0.4, delay: 0.25, rate: 1.1 });
        break;
      case "telegraph":
        this.play({ name: "keys", volume: 0.75 }); this.play({ name: "keys", volume: 0.5, delay: 0.18, rate: 1.15 });
        this.note(now, 190, 0.4, 0.035, "square");
        break;
      case "ability-bucket":
        this.play({ name: "splash", volume: 0.75 }); this.noiseBurst(now, 0.12, 900, 0.5);
        break;
      case "ability-chord":
        this.strum(now, [82.41, 123.47, 164.81, 196, 246.94, 329.63], 0.05);
        this.play({ name: "slam", volume: 0.3, rate: 0.7 });
        break;
      case "ability-cat":
        this.play({ name: "scratch", volume: 0.55 }); this.play({ name: "scratch", volume: 0.45, delay: 0.12, rate: 1.2 });
        this.note(now + 0.05, 620, 0.35, 0.03, "sine", 900); this.note(now + 0.32, 900, 0.3, 0.025, "sine", 520);
        break;
      case "ability":
        this.note(now, 130, 0.4, 0.07, "sawtooth"); this.note(now + 0.04, 390, 0.3, 0.04, "triangle");
        break;
      case "explode":
        if (!this.play({ name: "explosion", volume: 0.65 })) this.noiseBurst(now, 0.18, 400, 0.4);
        this.note(now, 60, 0.35, 0.07, "sawtooth");
        break;
      case "alarm":
        for (let i = 0; i < 6; i++) this.note(now + i * 0.14, i % 2 ? 640 : 920, 0.13, 0.03, "square");
        break;
      case "leak":
        if (!this.play({ name: "door-close", volume: 0.7 })) this.note(now, 120, 0.25, 0.07, "square");
        this.note(now, 98, 0.3, 0.035, "sawtooth", 70);
        break;
      case "lost":
        this.play({ name: "slam", volume: 0.7, rate: 0.75 }); this.play({ name: "door-close", volume: 0.6, delay: 0.3, rate: 0.8 });
        [220, 196, 164.81, 110].forEach((f, i) => this.note(now + 0.2 + i * 0.22, f, 0.6, 0.035, "triangle"));
        break;
      case "won":
        this.play({ name: "bell-long", volume: 0.5, jitter: 0 }); this.play({ name: "gong", volume: 0.35, rate: 1.3, delay: 0.2, jitter: 0 });
        [261.63, 329.63, 392, 523.25, 659.25].forEach((f, i) => this.note(now + 0.1 + i * 0.12, f, 0.7, 0.03, "triangle"));
        break;
      case "deny":
        if (!this.play({ name: "deny", volume: 0.45, jitter: 0 })) this.note(now, 105, 0.08, 0.03, "square");
        break;
    }
  }

  /** Звуки интерфейса — кнопки меню, карточки. */
  ui(kind: "click" | "hover" = "click") {
    if (!this.ctx || !this.settings.enabled) return;
    const now = this.ctx.currentTime;
    if (now - (this.lastSfx.get(`ui-${kind}`) ?? -10) < 0.05) return;
    this.lastSfx.set(`ui-${kind}`, now);
    this.play({ name: kind, volume: kind === "click" ? 0.32 : 0.12, jitter: 0.03 });
  }

  // ------------------------------------------------------------ настройки

  private save() {
    try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(this.settings)); } catch { /* ignore */ }
    this.version++;
    this.listeners.forEach((fn) => fn());
  }

  toggle() {
    this.settings.enabled = !this.settings.enabled;
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(this.settings.enabled && !this.hidden ? 1 : 0, this.ctx.currentTime, 0.04);
    this.updateMusic(this.settings.enabled);
    this.save();
    return this.settings.enabled;
  }

  setMusicVolume(value: number) {
    this.settings.music = Math.min(1, Math.max(0, value));
    this.updateMusic();
    this.save();
  }

  setSfxVolume(value: number) {
    this.settings.sfx = Math.min(1, Math.max(0, value));
    if (this.sfxBus && this.ctx) this.sfxBus.gain.setTargetAtTime(this.settings.sfx, this.ctx.currentTime, 0.03);
    this.save();
  }

  setHidden(hidden: boolean) {
    this.hidden = hidden;
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(this.settings.enabled && !hidden ? 1 : 0, this.ctx.currentTime, 0.05);
    this.updateMusic(!hidden);
  }

  subscribe = (fn: () => void) => { this.listeners.add(fn); return () => { this.listeners.delete(fn); }; };
  getVersion = () => this.version;

  get isEnabled() { return this.settings.enabled; }
  get musicVolume() { return this.settings.music; }
  get sfxVolume() { return this.settings.sfx; }
  get nowPlaying(): MusicKey | null { return this.currentTrack; }
}

export const audio = new AudioDirector();
