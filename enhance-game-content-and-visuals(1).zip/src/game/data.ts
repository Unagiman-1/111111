import type { EnemyDef, EnemyId, MapDef, TowerDef, TowerId, WaveDef } from "./types";

export const LOGICAL_WIDTH = 1200;
export const LOGICAL_HEIGHT = 720;
export const MAX_WAVE = 20;

export const TOWERS: Record<TowerId, TowerDef> = {
  girlfriend: {
    id: "girlfriend", name: "Подруга", role: "Быстрый урон · по плоти", cost: 70,
    damage: 12, rate: 1.45, range: 155, damageType: "soft", canAir: true, color: "#d98591",
    description: "Дешёвый темповый урон. Слаба против шлемов, зато быстро разбирает толпу и летающих.",
    branches: [
      { id: "glass", name: "Битое стекло", description: "25% шанс критического урона ×2.", capstone: "Осколки рикошетят во вторую цель." },
      { id: "chorus", name: "Девичий хор", description: "Выстрелы задевают область 42.", capstone: "Темп атаки ещё +25%." },
    ],
  },
  granny: {
    id: "granny", name: "Баба Валя", role: "Тяжёлый урон · по броне", cost: 110,
    damage: 38, rate: 0.58, range: 145, damageType: "heavy", canAir: false, color: "#d2a679",
    description: "Медленные сокрушительные сковородки. Пробивает броню, но часто промахивается по стаям.",
    branches: [
      { id: "iron", name: "Чугун", description: "+30% урона по броне и щитам.", capstone: "Каждый четвёртый удар оглушает." },
      { id: "pies", name: "Пироги", description: "Урон по области 58, включая соседние цели.", capstone: "Область больше, темп +20%." },
    ],
  },
  cat: {
    id: "cat", name: "Кот Барсик", role: "Пробитие · дальний бой", cost: 90,
    damage: 22, rate: 0.92, range: 190, damageType: "pierce", canAir: true, color: "#e0c66f",
    description: "Дальнобойный охотник против брони. Щиты гасят его атаки; связь с дозорным даёт криты.",
    branches: [
      { id: "hunter", name: "Охотник", description: "+35% урона по полному здоровью.", capstone: "Добивает цели ниже 18% HP." },
      { id: "lives", name: "Девять жизней", description: "Каждый третий выстрел бьёт две цели.", capstone: "Темп атаки +30%." },
    ],
  },
  speaker: {
    id: "speaker", name: "Динамик", role: "Контроль · замедление", cost: 85,
    damage: 6, rate: 0.65, range: 165, damageType: "control", canAir: true, color: "#a59ad8",
    description: "Звуковая волна бьёт всех рядом и замедляет. Сам наносит мало урона — усиливает соседей.",
    branches: [
      { id: "bass", name: "Сабвуфер", description: "Замедление сильнее: до 42% скорости.", capstone: "Каждая волна оглушает на 0,25 с." },
      { id: "underground", name: "Андеграунд", description: "Соседние башни атакуют на 10% быстрее.", capstone: "Бонус соседей возрастает до 20%." },
    ],
  },
  kiosk: {
    id: "kiosk", name: "Киоск «Лариса»", role: "Экономика · усиление", cost: 100,
    damage: 0, rate: 0, range: 0, damageType: "soft", canAir: false, color: "#d9a764",
    description: "Приносит 10 монет каждые 8 секунд. Курьеры могут украсть выручку. Даёт соседям энергетик.",
    branches: [
      { id: "energy", name: "Энергетики", description: "Связь ускоряет соседей на 45% вместо 30%.", capstone: "Выручка вырастает до 16 монет." },
      { id: "trade", name: "Ночная торговля", description: "Выручка 14 монет, но связь слабее.", capstone: "После волны +4% от накоплений, максимум 40." },
    ],
  },
  patrol: {
    id: "patrol", name: "Дозорный", role: "Удержание · защита", cost: 120,
    damage: 11, rate: 0.82, range: 135, damageType: "heavy", canAir: true, color: "#df835c",
    description: "Фонарь останавливает цель на 0,45 с. Кот по удерживаемым врагам наносит двойной урон.",
    branches: [
      { id: "baton", name: "Дубинка", description: "Удержание длится 0,8 с, +20% урона.", capstone: "Оглушение распространяется рядом." },
      { id: "searchlight", name: "Прожектор", description: "+45 дальности, +50% по летающим.", capstone: "Цели получают +10% от всех источников." },
    ],
  },
};

export const ENEMIES: Record<EnemyId, EnemyDef> = {
  skuf: { id: "skuf", name: "Скуф", short: "СК", hp: 62, speed: 48, reward: 8, damage: 1, tags: ["flesh"], armor: 0, resists: {}, color: "#7e8490", scale: 1, behavior: "Обычный жилец. Идёт к подъезду." },
  scooter: { id: "scooter", name: "Самокатчик", short: "СМ", hp: 45, speed: 92, reward: 9, damage: 1, tags: ["flesh"], armor: 0, resists: { heavy: 0.8 }, color: "#bd7b83", scale: 0.9, behavior: "Очень быстрый. После замедления ускоряется рывком." },
  helmet: { id: "helmet", name: "Шлёма", short: "ШЛ", hp: 110, speed: 44, reward: 12, damage: 1, tags: ["helmet"], armor: 1, resists: { soft: 0.42, heavy: 1.15, pierce: 1.2 }, color: "#a59773", scale: 1.05, behavior: "Каска гасит мягкий урон. Нужны сковородки или кот." },
  pigeons: { id: "pigeons", name: "Стая голубей", short: "ГЛ", hp: 42, speed: 70, reward: 7, damage: 1, tags: ["swarm", "flying"], armor: 0, resists: { heavy: 0.45, soft: 1.3, control: 0.8 }, color: "#8399b5", scale: 0.9, behavior: "Летит над диванами. Тяжёлые атаки часто промахиваются." },
  armored: { id: "armored", name: "Броник", short: "БР", hp: 205, speed: 34, reward: 17, damage: 2, tags: ["armor"], armor: 5, resists: { heavy: 0.62, pierce: 1.45, soft: 0.8 }, color: "#697a80", scale: 1.22, behavior: "Плоская броня 5. Кот пробивает её, тяжёлый урон частично гасится." },
  regen: { id: "regen", name: "Неубиваемый", short: "РГ", hp: 155, speed: 39, reward: 15, damage: 1, tags: ["flesh"], armor: 1, resists: { soft: 0.9, pierce: 1.1 }, color: "#79967e", scale: 1.08, behavior: "Восстанавливает 3% HP в секунду, если его не били 2 секунды." },
  courier: { id: "courier", name: "Курьер", short: "КР", hp: 90, speed: 66, reward: 14, damage: 1, tags: ["flesh"], armor: 0, resists: { control: 0.75 }, color: "#d7a34f", scale: 0.96, behavior: "Проходя мимо киоска, крадёт следующую выплату и ускоряется." },
  loudmouth: { id: "loudmouth", name: "Скуф с колонкой", short: "АУ", hp: 175, speed: 38, reward: 18, damage: 2, tags: ["flesh"], armor: 1, resists: { control: 0.55 }, color: "#9c78aa", scale: 1.12, behavior: "Аура в радиусе 150 снижает темп соседних башен на 25%." },
  cop: { id: "cop", name: "Участковый", short: "ЩТ", hp: 145, speed: 42, reward: 18, damage: 2, tags: ["shield"], armor: 2, resists: { soft: 1.15, heavy: 1.3, pierce: 0.85 }, color: "#678ca9", scale: 1.12, behavior: "Щит 90 HP. Пробитие наносит щиту лишь 45% урона." },
  drunk: { id: "drunk", name: "Ночной философ", short: "ФЛ", hp: 125, speed: 53, reward: 13, damage: 1, tags: ["flesh"], armor: 0, resists: { control: 0.25 }, color: "#9b7e72", scale: 1, behavior: "Почти невосприимчив к контролю, идёт неровно и меняет темп." },
  crowd: { id: "crowd", name: "Шумная компания", short: "ТЛ", hp: 125, speed: 41, reward: 12, damage: 1, tags: ["swarm"], armor: 0, resists: { heavy: 0.55, soft: 1.25, pierce: 0.9 }, color: "#aa7d89", scale: 1.05, behavior: "После смерти распадается на трёх обычных скуфов." },
  boss: { id: "boss", name: "Управдом Гена", short: "БОСС", hp: 1450, speed: 27, reward: 160, damage: 5, tags: ["boss", "armor"], armor: 4, resists: { soft: 0.75, heavy: 0.85, pierce: 1.2, control: 0.4 }, color: "#a54d56", scale: 1.9, behavior: "Три фазы. Телеграфирует удар по башням, призывает компанию и сбрасывает броню." },
};

const w = (name: string, tip: string, bonus: number, groups: WaveDef["groups"]): WaveDef => ({ name, tip, bonus, groups });

export const WAVES: WaveDef[] = [
  w("Первые гости", "Поставь двух защитников у слияния дорожек.", 34, [{ enemy: "skuf", count: 8, gap: 1.15 }]),
  w("Скрип колёсиков", "Быстрые цели требуют темповой атаки.", 38, [{ enemy: "skuf", count: 7, gap: 0.9 }, { enemy: "scooter", count: 4, gap: 1.1, delay: 4 }]),
  w("Каски и кепки", "Шлемы сопротивляются мягкому урону.", 42, [{ enemy: "helmet", count: 5, gap: 1.5 }, { enemy: "skuf", count: 8, gap: 0.65, delay: 2 }]),
  w("Налетели", "Голуби игнорируют диваны. Баба Валя по ним не стреляет.", 45, [{ enemy: "pigeons", count: 12, gap: 0.65 }, { enemy: "scooter", count: 5, gap: 0.9, delay: 5, lane: 1 }]),
  w("Проверка документов", "Управдом объявляет удар красной зоной — отключит башни рядом.", 65, [{ enemy: "skuf", count: 8, gap: 0.65 }, { enemy: "boss", count: 1, gap: 1, delay: 4, lane: 2 }]),
  w("Железный занавес", "Пробитие эффективно против брони.", 52, [{ enemy: "armored", count: 4, gap: 2 }, { enemy: "helmet", count: 6, gap: 1.1, delay: 3 }]),
  w("Не звони сюда", "Аура колонки замедляет твои башни. Убей носителя первым.", 55, [{ enemy: "loudmouth", count: 3, gap: 2.8 }, { enemy: "skuf", count: 12, gap: 0.45, delay: 1 }]),
  w("Доставка не заказана", "Курьеры крадут выручку киосков и убегают быстрее.", 58, [{ enemy: "courier", count: 8, gap: 1.15 }, { enemy: "pigeons", count: 10, gap: 0.55, delay: 4 }]),
  w("Тесная компания", "Компании распадаются на трёх врагов. Нужен урон по области.", 62, [{ enemy: "crowd", count: 7, gap: 1.5 }, { enemy: "scooter", count: 10, gap: 0.55, delay: 3 }]),
  w("Повторная проверка", "Во второй фазе босс призывает подмогу.", 85, [{ enemy: "armored", count: 4, gap: 1.8 }, { enemy: "boss", count: 1, gap: 1, delay: 3, lane: 1 }]),
  w("Регенерация", "Не распыляй урон: неубиваемые лечатся без атак.", 66, [{ enemy: "regen", count: 7, gap: 1.35 }, { enemy: "helmet", count: 8, gap: 0.85, delay: 4 }]),
  w("Участковый вышел", "Разбирай щиты тяжёлым уроном, кот здесь не поможет.", 70, [{ enemy: "cop", count: 6, gap: 1.6 }, { enemy: "pigeons", count: 14, gap: 0.45, delay: 3 }]),
  w("Ночная философия", "Контроль почти не действует на философов.", 72, [{ enemy: "drunk", count: 10, gap: 0.8 }, { enemy: "loudmouth", count: 3, gap: 2.5, delay: 2 }]),
  w("Все сразу", "Смешанная волна: используй режимы приоритета.", 78, [{ enemy: "armored", count: 5, gap: 1.5 }, { enemy: "helmet", count: 8, gap: 0.75, delay: 2 }, { enemy: "courier", count: 6, gap: 0.8, delay: 7 }]),
  w("Ключи от всех дверей", "Третья фаза: управдом сбрасывает броню и ускоряется.", 110, [{ enemy: "crowd", count: 6, gap: 1.2 }, { enemy: "boss", count: 1, gap: 1, delay: 4, lane: 0 }]),
  w("Птицы над бетоном", "Большая воздушная волна с аурами поддержки.", 84, [{ enemy: "pigeons", count: 24, gap: 0.32 }, { enemy: "loudmouth", count: 4, gap: 2, delay: 2 }]),
  w("Лом и каска", "Смешай пробитие и тяжёлый урон у одной связки.", 88, [{ enemy: "armored", count: 9, gap: 1.05 }, { enemy: "helmet", count: 12, gap: 0.6, delay: 2 }]),
  w("Без выходных", "Регенерация под прикрытием щитов.", 92, [{ enemy: "cop", count: 7, gap: 1.15 }, { enemy: "regen", count: 10, gap: 0.75, delay: 3 }, { enemy: "drunk", count: 8, gap: 0.55, delay: 6 }]),
  w("Двор не спит", "Курьеры, ауры и толпы атакуют с разных сторон.", 100, [{ enemy: "loudmouth", count: 5, gap: 1.7 }, { enemy: "crowd", count: 10, gap: 0.7, delay: 1 }, { enemy: "courier", count: 12, gap: 0.5, delay: 4 }, { enemy: "pigeons", count: 16, gap: 0.35, delay: 7 }]),
  w("Последний звонок", "Финальная проверка. Сохрани способности на фазы босса.", 180, [{ enemy: "armored", count: 8, gap: 1 }, { enemy: "cop", count: 6, gap: 1.1, delay: 2 }, { enemy: "boss", count: 1, gap: 1, delay: 6, lane: 2 }]),
];

const pads = [
  { id: 0, x: 220, y: 250, unlockWave: 0, unlockCost: 0 },
  { id: 1, x: 345, y: 125, unlockWave: 0, unlockCost: 0 },
  { id: 2, x: 390, y: 345, unlockWave: 0, unlockCost: 0 },
  { id: 3, x: 475, y: 545, unlockWave: 0, unlockCost: 0 },
  { id: 4, x: 565, y: 200, unlockWave: 0, unlockCost: 0 },
  { id: 5, x: 745, y: 245, unlockWave: 0, unlockCost: 0 },
  { id: 6, x: 780, y: 555, unlockWave: 0, unlockCost: 0 },
  { id: 7, x: 945, y: 335, unlockWave: 0, unlockCost: 0 },
  { id: 8, x: 160, y: 455, unlockWave: 4, unlockCost: 80 },
  { id: 9, x: 655, y: 610, unlockWave: 8, unlockCost: 120 },
  { id: 10, x: 1030, y: 600, unlockWave: 12, unlockCost: 170 },
  { id: 11, x: 1020, y: 225, unlockWave: 16, unlockCost: 230 },
];

const commonPath = [{ x: 620, y: 370 }, { x: 760, y: 405 }, { x: 900, y: 485 }, { x: 1125, y: 520 }, { x: 1240, y: 520 }];
const paths = [
  [{ x: -40, y: 125 }, { x: 155, y: 130 }, { x: 290, y: 235 }, { x: 455, y: 285 }, ...commonPath],
  [{ x: -40, y: 640 }, { x: 165, y: 610 }, { x: 280, y: 505 }, { x: 450, y: 465 }, ...commonPath],
  [{ x: 650, y: -40 }, { x: 670, y: 120 }, { x: 605, y: 245 }, ...commonPath],
  [{ x: 1240, y: 125 }, { x: 1050, y: 150 }, { x: 920, y: 265 }, { x: 820, y: 340 }, ...commonPath],
];

export const MAPS: MapDef[] = [
  {
    id: "yard", name: "Двор на Осыпной", subtitle: "ДОМ 17 · СЕВЕРНЫЙ ДВОР",
    description: "Осенний двор под моросью. Четыре входа сливаются у старой песочницы — классическая оборона с дальними флангами.",
    requiredStars: 0, tint: "#778291", paths, pads,
    props: [
      { id: 0, x: 470, y: 292, allowed: ["sofa", "clothesline"] },
      { id: 1, x: 510, y: 452, allowed: ["sofa", "dumpster"] },
      { id: 2, x: 780, y: 410, allowed: ["dumpster", "car"] },
      { id: 3, x: 915, y: 490, allowed: ["sofa", "car"] },
    ],
    hero: { x: 1090, y: 585 },
    exitLabel: "ПОДЪЕЗД", location: "courtyard", weather: "leaves", music: "yard",
  },
  {
    id: "arch", name: "Арка на Ломаной", subtitle: "ДОМ 4 · ТУПИК ЗА ГАРАЖАМИ",
    description: "Ночной ливень и тупик за гаражами. Враги лезут через арку, вдоль гаражей и мимо стоянки — короткий общий коридор к подъезду.",
    requiredStars: 3, tint: "#8a6a52",
    paths: [
      [{ x: 535, y: -40 }, { x: 535, y: 130 }, { x: 540, y: 260 }, { x: 590, y: 360 }, { x: 660, y: 430 }, { x: 760, y: 500 }, { x: 880, y: 560 }, { x: 990, y: 580 }, { x: 1030, y: 576 }],
      [{ x: 235, y: 760 }, { x: 235, y: 600 }, { x: 300, y: 500 }, { x: 430, y: 450 }, { x: 660, y: 430 }, { x: 760, y: 500 }, { x: 880, y: 560 }, { x: 990, y: 580 }, { x: 1030, y: 576 }],
      [{ x: 1240, y: 105 }, { x: 1000, y: 105 }, { x: 880, y: 180 }, { x: 800, y: 300 }, { x: 720, y: 400 }, { x: 660, y: 430 }, { x: 760, y: 500 }, { x: 880, y: 560 }, { x: 990, y: 580 }, { x: 1030, y: 576 }],
    ],
    pads: [
      { id: 0, x: 400, y: 200, unlockWave: 0, unlockCost: 0 },
      { id: 1, x: 690, y: 195, unlockWave: 0, unlockCost: 0 },
      { id: 2, x: 420, y: 340, unlockWave: 0, unlockCost: 0 },
      { id: 3, x: 660, y: 300, unlockWave: 0, unlockCost: 0 },
      { id: 4, x: 900, y: 330, unlockWave: 0, unlockCost: 0 },
      { id: 5, x: 560, y: 545, unlockWave: 0, unlockCost: 0 },
      { id: 6, x: 830, y: 430, unlockWave: 0, unlockCost: 0 },
      { id: 7, x: 380, y: 565, unlockWave: 0, unlockCost: 0 },
      { id: 8, x: 330, y: 390, unlockWave: 4, unlockCost: 80 },
      { id: 9, x: 720, y: 640, unlockWave: 8, unlockCost: 120 },
      { id: 10, x: 950, y: 470, unlockWave: 12, unlockCost: 170 },
      { id: 11, x: 960, y: 250, unlockWave: 16, unlockCost: 230 },
    ],
    props: [
      { id: 0, x: 540, y: 250, allowed: ["sofa", "clothesline"] },
      { id: 1, x: 380, y: 466, allowed: ["sofa", "dumpster"] },
      { id: 2, x: 775, y: 332, allowed: ["dumpster", "car"] },
      { id: 3, x: 880, y: 560, allowed: ["sofa", "car"] },
    ],
    hero: { x: 935, y: 680 },
    exit: { x: 1030, y: 576 }, exitLabel: "ПОДЪЕЗД", location: "arch", weather: "rain", music: "arch",
  },
  {
    id: "boiler", name: "Котельная «Рассвет»", subtitle: "ТЕПЛОПУНКТ · 03:47 · −23°",
    description: "Снежная ночь у котельной. Четыре подхода: по следам шин, через теплотрассу и вдоль угольной кучи. Враги быстрее на 8%, ранний вызов даёт больше монет.",
    requiredStars: 6, tint: "#6f8aa3",
    paths: [
      [{ x: 430, y: -40 }, { x: 470, y: 100 }, { x: 560, y: 220 }, { x: 620, y: 320 }, { x: 700, y: 420 }, { x: 790, y: 390 }, { x: 852, y: 372 }],
      [{ x: -40, y: 180 }, { x: 200, y: 200 }, { x: 330, y: 300 }, { x: 470, y: 380 }, { x: 600, y: 410 }, { x: 700, y: 420 }, { x: 790, y: 390 }, { x: 852, y: 372 }],
      [{ x: 300, y: 760 }, { x: 320, y: 560 }, { x: 440, y: 500 }, { x: 600, y: 450 }, { x: 700, y: 420 }, { x: 790, y: 390 }, { x: 852, y: 372 }],
      [{ x: 1240, y: 612 }, { x: 1080, y: 600 }, { x: 900, y: 560 }, { x: 780, y: 500 }, { x: 700, y: 420 }, { x: 790, y: 390 }, { x: 852, y: 372 }],
    ],
    pads: [
      { id: 0, x: 330, y: 130, unlockWave: 0, unlockCost: 0 },
      { id: 1, x: 610, y: 140, unlockWave: 0, unlockCost: 0 },
      { id: 2, x: 400, y: 430, unlockWave: 0, unlockCost: 0 },
      { id: 3, x: 530, y: 300, unlockWave: 0, unlockCost: 0 },
      { id: 4, x: 230, y: 370, unlockWave: 0, unlockCost: 0 },
      { id: 5, x: 560, y: 560, unlockWave: 0, unlockCost: 0 },
      { id: 6, x: 740, y: 300, unlockWave: 0, unlockCost: 0 },
      { id: 7, x: 660, y: 530, unlockWave: 0, unlockCost: 0 },
      { id: 8, x: 190, y: 480, unlockWave: 4, unlockCost: 80 },
      { id: 9, x: 450, y: 610, unlockWave: 8, unlockCost: 120 },
      { id: 10, x: 990, y: 665, unlockWave: 12, unlockCost: 170 },
      { id: 11, x: 820, y: 615, unlockWave: 16, unlockCost: 230 },
    ],
    props: [
      { id: 0, x: 520, y: 392, allowed: ["sofa", "clothesline"] },
      { id: 1, x: 470, y: 100, allowed: ["sofa", "dumpster"] },
      { id: 2, x: 440, y: 500, allowed: ["dumpster", "car"] },
      { id: 3, x: 790, y: 390, allowed: ["sofa", "car"] },
    ],
    hero: { x: 935, y: 470 },
    exit: { x: 852, y: 372 }, exitLabel: "КОТЕЛЬНАЯ", location: "boiler", weather: "snow", music: "boiler",
  },
];

export function endlessWave(n: number): WaveDef {
  const pool: EnemyId[] = ["skuf", "scooter", "helmet", "pigeons", "armored", "regen", "courier", "loudmouth", "cop", "drunk", "crowd"];
  const pick = (offset: number) => pool[(n * 7 + offset * 5) % pool.length];
  const groups: WaveDef["groups"] = [
    { enemy: pick(0), count: Math.min(26, 8 + Math.floor(n * 0.55)), gap: Math.max(0.28, 0.8 - n * 0.012) },
    { enemy: pick(1), count: Math.min(20, 5 + Math.floor(n * 0.4)), gap: Math.max(0.35, 1 - n * 0.012), delay: 2.5, lane: n % 4 },
    { enemy: pick(2), count: Math.min(14, 3 + Math.floor(n * 0.28)), gap: 0.8, delay: 5, lane: (n + 1) % 4 },
  ];
  if (n % 5 === 0) groups.push({ enemy: "boss", count: 1 + Math.floor(n / 35), gap: 4, delay: 7, lane: n % 3 });
  return { name: n % 5 === 0 ? "Бесконечная проверка" : `Ночь ${n}`, tip: "Процедурная волна. Награды растут вместе с угрозой.", bonus: 80 + n * 4, groups };
}

export function getWave(n: number): WaveDef {
  return n <= MAX_WAVE ? WAVES[Math.max(0, n - 1)] : endlessWave(n);
}

export const PROP_DATA = {
  sofa: { name: "Диван", cost: 45, hp: 110, description: "Останавливает наземных врагов, пока они его не сломают." },
  clothesline: { name: "Бельевые верёвки", cost: 55, hp: 70, description: "Постоянно замедляет наземных врагов рядом на 25%." },
  dumpster: { name: "Мусорный бак", cost: 70, hp: 45, description: "Однократно взрывается: 150 тяжёлого урона по области." },
  car: { name: "Сигнализация", cost: 80, hp: 90, description: "Каждые 12 с оглушает наземных врагов рядом на 1,2 с." },
} as const;

export const ABILITIES = {
  bucket: { name: "Ведро с водой", cooldown: 18, radius: 105, key: "Q", description: "85 мягкого урона и замедление на 4 с." },
  chord: { name: "Разрывной аккорд", cooldown: 30, radius: 150, key: "W", description: "55 урона контролем и оглушение на 1,5 с." },
  cat: { name: "Кот в помощь", cooldown: 25, radius: 115, key: "E", description: "5 секунд наносит пробивающий урон всем в области." },
} as const;
