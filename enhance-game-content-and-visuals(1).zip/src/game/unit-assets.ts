import altushka from "../art/units/source-altushka.webp?inline";
import girlfriend from "../art/units/source-girlfriend.webp?inline";
import granny from "../art/units/source-granny.webp?inline";
import speaker from "../art/units/source-speaker.webp?inline";
import cat from "../art/units/source-cat.webp?inline";
import kiosk from "../art/units/source-kiosk.webp?inline";
import patrol from "../art/units/source-patrol.webp?inline";
import boss from "../art/units/source-boss.webp?inline";
import skuf from "../art/units/source-skuf.webp?inline";

import type { ArtUnit } from "./art-types";
const ART: Record<ArtUnit, string> = { altushka, girlfriend, granny, speaker, cat, kiosk, patrol, boss, skuf };
export const unitArtUrl = (unit: ArtUnit): string => ART[unit];
