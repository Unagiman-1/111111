// Оригиналы из архива пользователя; Vite встраивает их в автономную сборку.
export const ART_UNITS = ["altushka", "girlfriend", "granny", "speaker", "cat", "kiosk", "patrol", "boss", "skuf"] as const;
export type ArtUnit = (typeof ART_UNITS)[number];

export const ART_NAMES: Record<ArtUnit, string> = {
  altushka: "Альтушка", girlfriend: "Подруга", granny: "Баба Валя", speaker: "Динамик",
  cat: "Кот Барсик", kiosk: "Лариса", patrol: "Дозорный", boss: "Управдом Гена", skuf: "Скуф",
};

export type MotionKind = "idle" | "walk" | "attack" | "neutral";
export type BackgroundKey = "auto" | "white" | "black" | "none";
export interface Artwork {
  unit: ArtUnit; url: string; originalUrl: string; image: HTMLImageElement;
  revision: number; source: "builtin" | "uploaded"; filename: string;
  width: number; height: number; fullBody: boolean; ready: boolean; key: BackgroundKey;
}
export interface ArtPose { time: number; phase?: number; walking?: boolean; attack?: number; neutral?: boolean }
