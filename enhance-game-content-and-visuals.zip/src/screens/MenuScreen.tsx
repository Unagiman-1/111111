import { ArrowRight, BookOpen, MapPin, MousePointerClick, Play, Shield, Star, Swords, Volume2 } from "lucide-react";
import { MAPS, MAX_WAVE, TOWERS } from "../game/data";
import { locationArt, unitArt } from "../game/assets";
import type { Progress } from "../game/progress";
import { NowPlaying, Stars } from "../components/ui";
import { audio } from "../audio/director";

export function MenuScreen({
  progress, onPlay, onNavigate, onSelectMap,
}: {
  progress: Progress;
  onPlay: () => void;
  onNavigate: (screen: "maps" | "codex" | "settings") => void;
  onSelectMap: (id: string) => void;
}) {
  const lastMap = localStorage.getItem("altushka-td-last-map") ?? "yard";
  const greeting = "Двор не сдаётся";

  return (
    <div>
      <section className="menu-hero">
        <div className="menu-hero-bg">
          <img src={locationArt("yard")} alt="Заснеженный петербургский двор ночью" />
        </div>
        <div className="shell menu-hero-inner">
          <div className="hero-copy fade-up">
            <div className="hero-kicker">
              <span className="chip gold"><span className="dot" /> Ночной двор · сезон 1</span>
              <span className="chip">18+ · юмор и сковородки</span>
            </div>
            <h1 className="hero-title">Альт<span className="accent">ушка</span></h1>
            <div className="hero-title-sub">Ночной двор</div>
            <p className="hero-desc">
              Пока весь дом спит, подъезд защищает девушка с гитарой, бабушка со сковородкой
              и кот, который слишком хорошо целится. Ставь защитников, слушай двор
              и не дай управдому забрать ключи.
            </p>
            <div className="hero-actions">
              <button className="btn btn-primary" onClick={() => { audio.unlock(); audio.click(); onPlay(); }}>
                <Play size={15} fill="currentColor" /> Занять двор
              </button>
              <button className="btn btn-ghost" onClick={() => { audio.unlock(); audio.click(); onSelectMap(lastMap); }}>
                <MapPin size={15} /> Продолжить
              </button>
              <button className="btn btn-quiet" onClick={() => onNavigate("codex")}>
                <BookOpen size={15} /> Справочник
              </button>
            </div>
            <div className="hero-meta">
              <div className="hero-meta-item">
                <span className="hero-meta-value">03</span>
                <span className="hero-meta-label">локации</span>
              </div>
              <div className="hero-meta-item">
                <span className="hero-meta-value">06</span>
                <span className="hero-meta-label">защитников</span>
              </div>
              <div className="hero-meta-item">
                <span className="hero-meta-value">20</span>
                <span className="hero-meta-label">волн</span>
              </div>
              <div className="hero-meta-item">
                <span className="hero-meta-value">4</span>
                <span className="hero-meta-label">трека в сети</span>
              </div>
            </div>
          </div>
          <div className="hero-figure fade-up delay-1">
            <img src={unitArt("altushka")} alt="Альтушка — защитница двора с гитарой" />
            <div className="hero-nameplate">
              <strong>Альтушка</strong>
              <span>Голос двора · герой</span>
            </div>
          </div>
        </div>
        <div className="hero-scroll"><MousePointerClick size={12} /> листай ниже · три адреса</div>
      </section>

      <section className="shell menu-lower">
        <div className="section-head">
          <div>
            <p className="eyebrow" style={{ marginBottom: 12 }}>Одна ночь · три адреса</p>
            <h2 className="display h2">{greeting},<br /><span className="serif" style={{ fontStyle: "italic", color: "var(--gold-bright)" }}>услышимся у подъезда.</span></h2>
          </div>
          <div style={{ display: "grid", gap: 10 }}>
            <NowPlaying />
            <button className="btn btn-ghost btn-sm" style={{ justifySelf: "start" }} onClick={() => onNavigate("settings")}>
              <Volume2 size={13} /> Музыка и звуки
            </button>
          </div>
        </div>

        <div className="map-grid">
          {MAPS.map((map, index) => {
            const saved = progress[map.id];
            const locked = progress && Object.values(progress).reduce((sum, item) => sum + item.stars, 0) < map.requiredStars;
            return (
              <button key={map.id} className={`map-card ${locked ? "locked" : ""} fade-up delay-${index + 1}`} onClick={() => { if (!locked) { audio.click(); onSelectMap(map.id); } }}>
                <div className="map-card-media">
                  <img src={locationArt(map.background)} alt={`Локация: ${map.name}`} />
                  <div className="map-card-top">
                    <span className="chip">{map.subtitle.split(" · ").slice(-1)}</span>
                    <span className="chip gold">{map.difficulty}</span>
                  </div>
                </div>
                <div className="map-card-body">
                  <div className="map-card-name">{map.name}</div>
                  <div className="map-card-meta">
                    <span className="chip sage">{map.paths.length} {map.paths.length > 3 ? "подхода" : "входа"}</span>
                    <Stars value={saved?.stars ?? 0} />
                  </div>
                  <p className="map-card-desc">{map.description}</p>
                  <div className="map-card-foot">
                    <span className="tiny">{map.requiredStars ? `нужно ${map.requiredStars} ★` : "открыт с начала"}</span>
                    <span className="gold" style={{ display: "inline-flex", alignItems: "center", gap: 6, fontSize: 11, fontWeight: 700 }}>
                      {locked ? "Закрыто" : "Играть"} <ArrowRight size={13} />
                    </span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      <section className="shell" style={{ paddingBottom: 72 }}>
        <div className="panel" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(230px, 1fr))", gap: 0 }}>
          {[
            { icon: <Play size={18} />, title: "1 · Выбери площадку", text: "Свободные места светятся во дворе. Клик — и защитник уже на посту." },
            { icon: <Shield size={18} />, title: "2 · Собери связку", text: `Дозорный держит, ${TOWERS.cat.name} бьёт вдвое. ${TOWERS.kiosk.name} ускоряет соседей.` },
            { icon: <Swords size={18} />, title: "3 · Держи 20 волн", text: "Управдом придёт трижды. Способности Альтушки и её гитара — твой последний козырь." },
          ].map((step, i) => (
            <div key={step.title} style={{ padding: "24px 22px", borderLeft: i ? "1px solid var(--line)" : "none", display: "flex", flexDirection: "column", gap: 10 }}>
              <div style={{ color: "var(--gold)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                {step.icon}
                <span className="mono" style={{ fontSize: 10, color: "var(--dim)" }}>0{i + 1}</span>
              </div>
              <h3 className="display h3" style={{ fontSize: 21 }}>{step.title}</h3>
              <p className="body-s" style={{ fontSize: 12.5, margin: 0 }}>{step.text}</p>
            </div>
          ))}
        </div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 16, flexWrap: "wrap", marginTop: 26, paddingTop: 18, borderTop: "1px solid var(--line)" }}>
          <p className="tiny" style={{ margin: 0, letterSpacing: ".16em" }}>Двор · гитара · сковородка · управдом</p>
          <p className="body-s" style={{ margin: 0, display: "flex", alignItems: "center", gap: 7 }}>
            <Star size={12} fill="currentColor" style={{ color: "var(--gold)" }} />
            Прогресс сохраняется в браузере · {MAX_WAVE} волн в кампании
          </p>
        </div>
      </section>
    </div>
  );
}
