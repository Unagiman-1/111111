import { ArrowRight, Infinity as InfinityIcon, LockKeyhole, MapPin, Play, Skull, Star, Trophy } from "lucide-react";
import { MAPS } from "../game/data";
import { locationArt } from "../game/assets";
import type { Progress } from "../game/progress";
import { totalStars } from "../game/progress";
import { BackButton, Stars } from "../components/ui";
import { audio } from "../audio/director";

export function MapsScreen({
  progress, onStart, onBack,
}: {
  progress: Progress;
  onStart: (mapId: string, endless: boolean) => void;
  onBack: () => void;
}) {
  const stars = totalStars(progress);
  return (
    <main className="shell page" style={{ flex: 1 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", gap: 20, flexWrap: "wrap", marginBottom: 28 }}>
        <div>
          <BackButton onClick={onBack} label="Главная" />
          <p className="eyebrow" style={{ margin: "18px 0 12px" }}>Карта ночи · {stars} ★ собрано</p>
          <h1 className="display h1">Куда <span style={{ fontStyle: "italic", color: "var(--gold-bright)" }}>идём?</span></h1>
          <p className="lead" style={{ marginTop: 14 }}>
            Три адреса — три характера обороны. Двор учит расставлять приоритеты,
            арка не даёт времени на раздумья, а котельная проверяет нервы на прочность.
          </p>
        </div>
        <div className="panel" style={{ minWidth: 240, flex: "0 1 300px" }}>
          <div className="panel-head"><span className="panel-title" style={{ fontSize: 17 }}>Кампания</span><Trophy size={15} color="var(--gold)" /></div>
          <div className="panel-body" style={{ display: "flex", flexDirection: "column", gap: 9 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span className="tiny">Звёзды</span><span className="mono" style={{ color: "var(--gold-bright)" }}>{stars} / 9</span>
            </div>
            <div style={{ height: 3, background: "rgba(255,255,255,.1)", borderRadius: 4 }}>
              <div style={{ width: `${Math.min(100, (stars / 9) * 100)}%`, height: "100%", background: "linear-gradient(90deg,var(--gold),var(--gold-bright))", transition: "width .4s ease" }} />
            </div>
            <p className="body-s" style={{ margin: "2px 0 0", fontSize: 11 }}>
              Звёзды открывают новые локации. Три звезды дают двор без единой пробоины.
            </p>
          </div>
        </div>
      </div>

      <div className="map-list">
        {MAPS.map((map, index) => {
          const saved = progress[map.id];
          const locked = stars < map.requiredStars;
          return (
            <article key={map.id} className="map-row fade-up" style={{ animationDelay: `${index * 0.06}s`, opacity: locked ? 0.72 : 1 }}>
              <div className="map-row-image">
                <img src={locationArt(map.background)} alt="" />
                <span className="chip gold" style={{ position: "absolute", zIndex: 2, top: 10, left: 10, backdropFilter: "blur(6px)" }}>
                  {String(index + 1).padStart(2, "0")} · {map.difficulty}
                </span>
              </div>
              <div className="map-row-copy">
                <div className="eyebrow" style={{ fontSize: 9 }}>{map.subtitle}</div>
                <h2 className="display" style={{ fontSize: "clamp(26px, 2.6vw, 36px)" }}>{map.name}</h2>
                <p className="lead" style={{ fontSize: 12.5, margin: 0, lineHeight: 1.6 }}>{map.description}</p>
                <div style={{ display: "flex", gap: 7, flexWrap: "wrap", marginTop: 2 }}>
                  <span className="chip">{map.paths.length} входа</span>
                  <span className="chip">{map.pads.length} площадок</span>
                  {map.id === "arch" && <span className="chip wine">враги +8% скорости</span>}
                  {map.id === "boiler" && <span className="chip wine">ранний вызов ×1,5</span>}
                  {saved?.cleared && <span className="chip sage"><Star size={9} fill="currentColor" /> пройдено</span>}
                </div>
              </div>
              <div className="map-row-side">
                {locked ? (
                  <>
                    <div className="lock-note"><LockKeyhole size={14} /> нужно {map.requiredStars} ★</div>
                    <span className="body-s" style={{ fontSize: 10.5, textAlign: "right" }}>Пройди предыдущие дворы, чтобы получить допуск.</span>
                  </>
                ) : (
                  <>
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <Stars value={saved?.stars ?? 0} />
                      <span className="tiny">{saved ? `лучшая ${saved.bestWave} волна` : "новая локация"}</span>
                    </div>
                    <div style={{ display: "flex", gap: 6, flexWrap: "wrap", justifyContent: "flex-end" }}>
                      <button className="btn btn-primary btn-sm" onClick={() => { audio.click(); onStart(map.id, false); }}>
                        <Play size={12} fill="currentColor" /> Кампания
                      </button>
                      <button className="btn btn-ghost btn-sm" onClick={() => { audio.click(); onStart(map.id, true); }} title="Бесконечная ночь">
                        <InfinityIcon size={14} /> Ночь
                      </button>
                    </div>
                    <button className="tiny" onClick={() => onStart(map.id, true)} style={{ display: "flex", alignItems: "center", gap: 5 }}>
                      <Skull size={10} /> бесконечные волны
                    </button>
                  </>
                )}
              </div>
            </article>
          );
        })}
      </div>

      <div className="panel" style={{ marginTop: 20, display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))" }}>
        {[
          { title: "Как открыть арку", text: "Собери 3 звезды на первом дворе. Одна звезда — за прохождение, ещё две дают за сохранённые жизни.", icon: <Star size={15} /> },
          { title: "Зачем бесконечная ночь", text: "Волны генерируются бесконечно и становятся злее. Рекорд по волнам сохраняется для каждой локации.", icon: <InfinityIcon size={15} /> },
          { title: "Смена локации", text: "Площадки, маршруты и атмосфера у всех разные. Привычные связки придётся переставлять заново.", icon: <MapPin size={15} /> },
        ].map((item) => (
          <div key={item.title} style={{ padding: 18, borderRight: "1px solid var(--line)" }}>
            <div className="gold" style={{ marginBottom: 8 }}>{item.icon}</div>
            <h4 style={{ margin: "0 0 5px", fontFamily: "var(--serif)", fontSize: 18, fontWeight: 600 }}>{item.title}</h4>
            <p className="body-s" style={{ margin: 0, fontSize: 11.5 }}>{item.text}</p>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 22, display: "flex", justifyContent: "flex-end" }}>
        <button className="btn btn-ghost btn-sm" onClick={() => onStart("yard", false)}>
          Начать с чистого двора <ArrowRight size={13} />
        </button>
      </div>
    </main>
  );
}
