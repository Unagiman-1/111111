import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft, ArrowRight, Cat, ChevronUp, Coins, Crosshair, Droplets, FastForward,
  Heart, Info, LockKeyhole, Music2, Pause, Play, RotateCcw, ShieldAlert, Skull,
  Sparkles, Trash2, Volume2, VolumeX, X,
} from "lucide-react";
import { Game } from "../game/engine";
import { ABILITIES, ENEMIES, MAPS, MAX_WAVE, PROP_DATA, TOWERS, mapById } from "../game/data";
import { PERKS, type PerkId } from "../game/perks";
import { unitArt } from "../game/assets";
import type { GameMode, PropId, Snapshot, Tower, TowerId } from "../game/types";
import { BattleCanvas } from "../components/BattleCanvas";
import { Logo, Stars } from "../components/ui";
import { audio } from "../audio/director";
import { cn } from "../utils/cn";

const TOWER_IDS = Object.keys(TOWERS) as TowerId[];
const PROP_IDS = Object.keys(PROP_DATA) as PropId[];
const TARGET_LABELS: Record<Tower["targetMode"], string> = {
  first: "Первый", last: "Последний", strong: "Сильный", weak: "Слабый", close: "Ближний",
};

function fmt(value: number) {
  return new Intl.NumberFormat("ru-RU").format(Math.floor(value));
}

export interface GameResult {
  mapId: string;
  stars: number;
  wave: number;
  endless: boolean;
  won: boolean;
}

export function GameScreen({
  mapId, mode, onExit, onRestart, onResult,
}: {
  mapId: string;
  mode: GameMode;
  onExit: () => void;
  onRestart: () => void;
  onResult: (result: GameResult) => void;
}) {
  const game = useMemo(() => new Game(mapId, mode), [mapId, mode]);
  const [snap, setSnap] = useState<Snapshot>(() => game.snapshot());
  const [paused, setPaused] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [tab, setTab] = useState<"defenders" | "objects">("defenders");
  const [soundOn, setSoundOn] = useState(audio.settings.music || audio.settings.sfx);
  const [intro, setIntro] = useState(() => {
    try { return localStorage.getItem("altushka-td-intro") !== "1"; } catch { return true; }
  });
  const resultSent = useRef(false);
  const map = mapById(mapId);
  const sync = useCallback(() => setSnap(game.snapshot()), [game]);

  useEffect(() => {
    audio.unlock();
    audio.setAmbient(map.background === "boiler" ? "factory" : "night");
    try { localStorage.setItem("altushka-td-last-map", map.id); } catch { /* noop */ }
    return () => { audio.setAmbient("none"); };
  }, [map.background, map.id]);

  useEffect(() => {
    game.paused = paused;
    if (!paused) sync();
  }, [game, paused, sync]);

  useEffect(() => { game.speed = speed; }, [game, speed]);

  useEffect(() => {
    if (snap.selectedSpot !== null) setTab("objects");
  }, [snap.selectedSpot]);

  useEffect(() => {
    if (snap.status === "prep" && snap.wave === 0) setTab("defenders");
  }, [snap.status, snap.wave]);

  useEffect(() => {
    if (!["won", "lost"].includes(snap.status) || resultSent.current) return;
    resultSent.current = true;
    onResult({
      mapId,
      stars: snap.status === "won" ? snap.starsEarned : 0,
      wave: snap.wave,
      endless: mode === "endless",
      won: snap.status === "won",
    });
    audio.sfx(snap.status === "won" ? "victory" : "deny");
  }, [snap.status, snap.starsEarned, snap.wave, mapId, mode, onResult]);

  useEffect(() => {
    const onVisibility = () => {
      if (document.hidden && game.status !== "won" && game.status !== "lost") setPaused(true);
    };
    document.addEventListener("visibilitychange", onVisibility);
    return () => document.removeEventListener("visibilitychange", onVisibility);
  }, [game]);

  const togglePause = useCallback(() => {
    setPaused((value) => {
      const next = !value;
      game.paused = next;
      return next;
    });
    audio.click();
  }, [game]);

  const startWave = useCallback(() => {
    game.startWave();
    sync();
  }, [game, sync]);

  const cycleSpeed = useCallback(() => {
    setSpeed((current) => {
      const next = current >= 3 ? 1 : current + 1;
      game.speed = next;
      return next;
    });
    audio.click();
  }, [game]);

  const toggleSound = () => {
    const next = !soundOn;
    setSoundOn(next);
    audio.unlock();
    audio.set("music", next);
    audio.set("sfx", next);
    if (next) audio.click();
  };

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.target instanceof HTMLInputElement) return;
      const key = event.key.toLowerCase();
      if (key === " " || key === "escape") {
        event.preventDefault();
        if (event.key === "Escape") {
          if (game.targeting || game.pendingTower) { game.targeting = null; game.pendingTower = null; sync(); }
          else togglePause();
        } else togglePause();
        return;
      }
      if (paused || intro || game.status === "won" || game.status === "lost" || game.draft) return;
      const index = Number(event.key) - 1;
      if (index >= 0 && index < TOWER_IDS.length) {
        game.prepareTower(TOWER_IDS[index]);
        sync();
        return;
      }
      if (key === "f") { startWave(); return; }
      if (key === "q" || key === "w" || key === "e") {
        const ability = key === "q" ? "bucket" : key === "w" ? "chord" : "cat";
        game.armAbility(ability);
        sync();
        return;
      }
      if (key === "0" || key === "+" || key === "-") cycleSpeed();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [game, paused, intro, togglePause, sync, startWave, cycleSpeed]);

  const selectedTower = snap.selectedTower;
  const selectedProp = snap.selectedProp;
  const selectedSpotDef = snap.selectedSpot !== null ? map.props.find((spot) => spot.id === snap.selectedSpot) : null;
  const hint = (() => {
    if (snap.targeting) return "Выбери точку на карте — способность сработает по области.";
    if (snap.pendingTower) return "Площадка выбрана. Нажми на свободный постамент во дворе.";
    if (selectedTower) return "Улучшай, меняй приоритет цели или продай защитника справа.";
    if (selectedSpotDef) return "Объект двора: выбери, что поставить на дороге.";
    if (snap.waveActive) return "Держи подъезд. Q, W и E — способности Альтушки.";
    if (snap.wave === 0) return "Нажми на светящийся постамент, затем выбери защитника.";
    return "Перерыв между волнами. Можно вызвать следующую досрочно и получить бонус.";
  })();

  const canStart = !snap.waveActive && snap.status === "prep" && !snap.draft;

  return (
    <div className="game-shell">
      <header className="game-topbar">
        <button onClick={onExit} className="brand" style={{ gap: 8 }} aria-label="Выйти в меню">
          <Logo compact />
          <span className="brand-text"><span className="brand-title">Альтушка</span><span className="brand-sub">ночной двор</span></span>
        </button>
        <div className="game-location">
          <strong>{map.name}</strong>
          <span>{map.subtitle}</span>
        </div>
        <div className="game-resources">
          <span className="resource" title="Монеты"><Coins size={13} /> {fmt(snap.coins)}</span>
          <span className="resource hp" title="Жизни подъезда"><Heart size={13} fill="currentColor" /> {snap.lives}<span className="dim" style={{ fontSize: 9 }}>/{snap.maxLives}</span></span>
          <span className="resource score" title="Очки">{fmt(snap.score)} очк.</span>
        </div>
        <div className="game-controls">
          <button className="icon-button sm" onClick={toggleSound} title="Звук" aria-label="Звук">{soundOn ? <Volume2 size={14} /> : <VolumeX size={14} />}</button>
          <button className="icon-button sm" onClick={cycleSpeed} title="Скорость" aria-label="Скорость"><FastForward size={14} /><span className="mono" style={{ fontSize: 8, marginLeft: -4 }}>{speed}×</span></button>
          <button className={cn("icon-button sm", paused && "active")} onClick={togglePause} title="Пауза" aria-label="Пауза"><Pause size={14} /></button>
          <button className="icon-button sm" onClick={onExit} title="Выйти" aria-label="Выйти в меню"><X size={14} /></button>
        </div>
      </header>

      <main className="game-main">
        <section className="board-column">
          <div className="board">
            <BattleCanvas game={game} onSnapshot={setSnap} />
            <div className="board-vignette" />
            <div className="board-hud-top">
              <div className="board-objective">
                <span>{snap.endless ? "Бесконечная ночь" : `Кампания · ${Math.min(snap.wave, MAX_WAVE)} из ${MAX_WAVE}`}</span>
                <strong>{map.name}</strong>
              </div>
              <div className="wave-progress">
                <span>волна</span>
                <b>{snap.waveActive ? snap.wave : snap.wave + (snap.wave < MAX_WAVE ? 1 : 0)}/{MAX_WAVE}</b>
                <div className="bar"><i style={{ width: `${Math.round(snap.waveActive ? snap.waveProgress * 100 : 0)}%` }} /></div>
                <b style={{ color: "var(--dim)" }}>{snap.enemies > 0 ? `${snap.enemies}` : "—"}</b>
              </div>
            </div>

            {snap.notice && snap.notice.time > 0 && (
              <div className="board-notice" key={snap.notice.text}>
                <strong>{snap.notice.text}</strong>
                {snap.notice.sub && <span>{snap.notice.sub}</span>}
              </div>
            )}

            {snap.boss && (
              <div style={{ position: "absolute", left: "50%", transform: "translateX(-50%)", bottom: 54, zIndex: 2, width: "min(340px, 70%)", padding: "7px 11px", border: "1px solid rgba(179,103,117,.42)", background: "rgba(15,10,13,.86)", backdropFilter: "blur(8px)" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8, marginBottom: 4 }}>
                  <span style={{ fontSize: 8, fontWeight: 700, letterSpacing: ".16em", textTransform: "uppercase", color: "#e0a3ac" }}>босс · фаза {snap.boss.phase}</span>
                  <span className="mono" style={{ fontSize: 9, color: "#dcc6b6" }}>{Math.ceil(snap.boss.hp)} / {snap.boss.maxHp}</span>
                </div>
                <div style={{ height: 4, background: "rgba(255,255,255,.1)", borderRadius: 4 }}>
                  <div style={{ height: "100%", width: `${Math.max(0, (snap.boss.hp / snap.boss.maxHp) * 100)}%`, background: "linear-gradient(90deg,#8f4553,#c97580)", transition: "width .2s linear" }} />
                </div>
              </div>
            )}

            <div className="board-bottom">
              <div className="board-tip"><Info size={12} /> <span>{hint}</span></div>
              <div className="board-actions">
                <button className="board-mini" onClick={togglePause} title="Пауза">{paused ? <Play size={13} /> : <Pause size={13} />}</button>
                <button className="board-mini" onClick={cycleSpeed} title="Скорость"><FastForward size={13} /></button>
                <button className="board-mini" onClick={toggleSound} title="Звук">{soundOn ? <Volume2 size={13} /> : <VolumeX size={13} />}</button>
              </div>
            </div>

            {paused && snap.status !== "won" && snap.status !== "lost" && (
              <div className="game-overlay">
                <div className="overlay-card center">
                  <span className="eyebrow no-rule">Пауза · двор замер</span>
                  <h2 className="overlay-title">Тишина во дворе</h2>
                  <p className="overlay-sub">Можно послушать, как капает с крыши, и продумать следующую связку. Прогресс волны не сбросится.</p>
                  <div className="overlay-actions center">
                    <button className="btn btn-primary" onClick={togglePause}><Play size={14} fill="currentColor" /> Продолжить</button>
                    <button className="btn btn-ghost" onClick={() => { audio.click(); onRestart(); }}><RotateCcw size={14} /> Заново</button>
                    <button className="btn btn-quiet" onClick={onExit}><ArrowLeft size={14} /> В меню</button>
                  </div>
                </div>
              </div>
            )}

            {snap.draft && (
              <div className="game-overlay">
                <div className="overlay-card">
                  <span className="eyebrow no-rule">Новый жилец двора</span>
                  <h2 className="overlay-title">Усиление на выбор</h2>
                  <p className="overlay-sub">Каждые пять волн двор делится опытом. Выбери одну карту — она останется до конца забега.</p>
                  <div className="draft-grid">
                    {snap.draft.map((id) => {
                      const perk = PERKS.find((item) => item.id === id as PerkId);
                      if (!perk) return null;
                      return (
                        <button key={perk.id} className="draft-card" onClick={() => { game.choosePerk(perk.id as PerkId); sync(); audio.sfx("upgrade"); }}>
                          <img src={unitArt(perk.art)} alt="" />
                          <b>{perk.name}</b>
                          <span>{perk.description}</span>
                        </button>
                      );
                    })}
                  </div>
                  <div className="overlay-actions center">
                    <span className="tiny">волна {snap.wave} · награда за стойкость</span>
                  </div>
                </div>
              </div>
            )}

            {(snap.status === "won" || snap.status === "lost") && (
              <div className="game-overlay">
                <div className="overlay-card center">
                  <span className="eyebrow no-rule">{snap.status === "won" ? "рассвет · двор устоял" : "подъезд захвачен"}</span>
                  <h2 className="overlay-title">{snap.status === "won" ? "Двор не сдаётся" : "Ключи не отдаём"}</h2>
                  <p className="overlay-sub">
                    {snap.status === "won"
                      ? `Все ${MAX_WAVE} волн отбиты. Альтушка допела аккорд, управдом ушёл без ключей.`
                      : `Ты продержалась до волны ${snap.wave}. Двор запомнит этот забег, а подъезд — нет. Попробуй другую связку.`}
                  </p>
                  {snap.status === "won" && <Stars value={snap.starsEarned} size={24} />}
                  <div className="result-stats">
                    <div className="result-stat"><b>{snap.wave}</b><span>волна</span></div>
                    <div className="result-stat"><b>{fmt(snap.score)}</b><span>очки</span></div>
                    <div className="result-stat"><b>{snap.lives}</b><span>жизни</span></div>
                  </div>
                  <div className="overlay-actions center">
                    {snap.status === "won" && MAPS.findIndex((item) => item.id === map.id) < MAPS.length - 1 && (
                      <button className="btn btn-primary" onClick={onExit}>Выбрать локацию <ArrowRight size={14} /></button>
                    )}
                    <button className={cn("btn", snap.status === "won" && MAPS.findIndex((item) => item.id === map.id) < MAPS.length - 1 ? "btn-ghost" : "btn-primary")} onClick={onRestart}>
                      <RotateCcw size={14} /> Ещё раз
                    </button>
                    <button className="btn btn-quiet" onClick={onExit}><ArrowLeft size={14} /> В меню</button>
                  </div>
                </div>
              </div>
            )}

            {intro && snap.status === "prep" && snap.wave === 0 && !paused && (
              <div className="game-overlay">
                <div className="overlay-card">
                  <span className="eyebrow no-rule">Первая смена · инструктаж</span>
                  <h2 className="overlay-title">Двор просыпается</h2>
                  <p className="overlay-sub">Ты — Альтушка. Голос двора, гитара и три способности. Задача — не дать ночным гостям дойти до двери подъезда.</p>
                  <div style={{ display: "flex", flexDirection: "column", gap: 8, margin: "14px 0 18px" }}>
                    {[
                      "Кликни по светящемуся постаменту и выбери защитника справа.",
                      "«Вызвать волну» запускает ночь. Ранний вызов даёт монеты.",
                      "Волны 5, 10, 15 — управдом. Q, W, E помогут его остановить.",
                    ].map((text, index) => (
                      <div key={text} style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                        <span className="chip gold" style={{ minWidth: 22, justifyContent: "center" }}>{index + 1}</span>
                        <span className="body-s" style={{ margin: 0, fontSize: 12, color: "#b9b6ae" }}>{text}</span>
                      </div>
                    ))}
                  </div>
                  <div className="overlay-actions">
                    <button className="btn btn-primary" style={{ flex: 1 }} onClick={() => { setIntro(false); try { localStorage.setItem("altushka-td-intro", "1"); } catch { /* noop */ } }}>
                      Занять позиции <ArrowRight size={14} />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>

        <aside className="game-side">
          <div className="side-scroll">
          <div className="side-card">
            <div className="side-head">
              <h3><Crosshair size={13} color="var(--gold)" /> {snap.waveActive ? `Волна ${snap.wave}` : snap.wave === 0 ? "Подготовка" : "Передышка"}</h3>
              <span>{snap.totalInWave > 0 ? `${snap.totalSpawned - snap.enemies}/${snap.totalInWave}` : snap.endless ? "бесконечно" : `${Math.max(1, snap.wave + 1)} / ${MAX_WAVE}`}</span>
            </div>
            <div className="wave-panel">
              <div>
                <p className="wave-title">{snap.waveActive ? snap.currentWave.name : snap.nextWave.name}</p>
                <p className="wave-tip" style={{ marginTop: 3 }}>{snap.waveActive ? snap.currentWave.tip : snap.nextWave.tip}</p>
              </div>
              <div className="wave-enemies">
                {[...new Set((snap.waveActive ? snap.currentWave : snap.nextWave).groups.map((group) => group.enemy))].map((id) => (
                  <span key={id} className="wave-enemy-chip">
                    <Skull size={8} color="var(--wine)" /> {ENEMIES[id].name}
                    <b>×{(snap.waveActive ? snap.currentWave : snap.nextWave).groups.filter((g) => g.enemy === id).reduce((sum, g) => sum + g.count, 0)}</b>
                  </span>
                ))}
              </div>
              <div className="wave-actions">
                <button className="btn btn-primary btn-sm" onClick={startWave} disabled={!canStart} style={{ flex: 1 }}>
                  <Play size={12} fill="currentColor" />
                  {snap.waveActive ? "Волна идёт" : snap.wave === 0 ? "Начать ночь" : "Вызвать волну"}
                  {!snap.waveActive && snap.earlyBonus > 0 && <span className="mono" style={{ fontSize: 9, color: "#3d2f18" }}>+{snap.earlyBonus}</span>}
                </button>
              </div>
              {snap.status === "prep" && snap.wave > 0 && snap.intermission > 0 && !snap.waveActive && (
                <span className="tiny" style={{ color: "var(--dim)" }}>автостарт через {Math.ceil(snap.intermission)} с</span>
              )}
            </div>
          </div>

          <div className="side-card">
            <div className="side-tabs">
              <button className={cn("side-tab", tab === "defenders" && "active")} onClick={() => setTab("defenders")}><ShieldAlert size={11} /> Защитники</button>
              <button className={cn("side-tab", tab === "objects" && "active")} onClick={() => setTab("objects")}><Sparkles size={11} /> Объекты</button>
            </div>

            {tab === "defenders" ? (
              <>
                <div className="tower-grid">
                  {TOWER_IDS.map((id, index) => {
                    const tower = TOWERS[id];
                    const afford = snap.coins >= tower.cost;
                    return (
                      <button
                        key={id}
                        className={cn("tower-card", snap.pendingTower === id && "selected")}
                        disabled={!afford || paused || snap.status === "won" || snap.status === "lost"}
                        onClick={() => { game.prepareTower(id); sync(); }}
                        title={`${tower.name} · ${tower.description}`}
                      >
                        <span className="tower-key">{index + 1}</span>
                        <span className="tower-thumb" style={{ ["--tone" as string]: `${tower.color}44` }}><img src={unitArt(id)} alt="" /></span>
                        <span className="tower-copy">
                          <span className="tower-name">{tower.name}</span>
                          <span className="tower-role">{tower.role}</span>
                          <span className="tower-cost"><Coins size={9} /> {tower.cost}</span>
                        </span>
                      </button>
                    );
                  })}
                </div>

                {selectedTower ? (
                  <div className="inspector" style={{ borderTop: "1px solid var(--line)" }}>
                    <div className="inspector-top">
                      <div className="inspector-art"><img src={unitArt(selectedTower.type)} alt="" /></div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <h3 className="inspector-name">{TOWERS[selectedTower.type].name}</h3>
                        <div className="inspector-role">{TOWERS[selectedTower.type].role}</div>
                        <div className="level-pips" style={{ marginTop: 5 }}>
                          {[1, 2, 3, 4].map((level) => <span key={level} className={cn("level-pip", selectedTower.level >= level && "on")} />)}
                        </div>
                      </div>
                      <span className="chip gold">ур. {selectedTower.level}</span>
                    </div>
                    <p className="inspector-desc">{TOWERS[selectedTower.type].description}</p>
                    <div className="stat-grid">
                      {selectedTower.type === "kiosk" ? (
                        <>
                          <div className="stat-box"><b>10</b><span>монет / 8с</span></div>
                          <div className="stat-box"><b>+30%</b><span>соседям</span></div>
                          <div className="stat-box"><b>{selectedTower.level === 4 ? "16" : "10"}</b><span>выплата</span></div>
                        </>
                      ) : (
                        <>
                          <div className="stat-box"><b>{Math.round(game.towerStats(selectedTower).damage)}</b><span>урон</span></div>
                          <div className="stat-box"><b>{game.towerStats(selectedTower).rate.toFixed(2)}</b><span>темп</span></div>
                          <div className="stat-box"><b>{Math.round(game.towerStats(selectedTower).range)}</b><span>радиус</span></div>
                        </>
                      )}
                    </div>
                    {selectedTower.level === 2 && selectedTower.branch === null ? (
                      <div className="branch-grid">
                        {TOWERS[selectedTower.type].branches.map((branch, index) => (
                          <button key={branch.id} className="branch-btn" onClick={() => { game.upgradeTower(selectedTower.uid, index as 0 | 1); sync(); audio.sfx("upgrade"); }}>
                            <b>{branch.name}</b><span>{branch.description}</span>
                          </button>
                        ))}
                      </div>
                    ) : selectedTower.level < 4 ? (
                      <button className="btn btn-primary btn-sm" onClick={() => { game.upgradeTower(selectedTower.uid); sync(); }} disabled={snap.coins < game.upgradeCost(selectedTower)}>
                        <ChevronUp size={12} /> Улучшить · <Coins size={10} /> {game.upgradeCost(selectedTower)}
                      </button>
                    ) : (
                      <div className="hint-box" style={{ borderStyle: "solid" }}>
                        <Sparkles size={12} />
                        <span>{selectedTower.branch !== null ? TOWERS[selectedTower.type].branches[selectedTower.branch].capstone : "Максимальный уровень"}</span>
                      </div>
                    )}
                    <div className="target-modes">
                      {(Object.keys(TARGET_LABELS) as Tower["targetMode"][]).map((modeKey) => (
                        <button key={modeKey} className={cn("target-mode", selectedTower.targetMode === modeKey && "active")} onClick={() => { game.setTargetMode(selectedTower.uid, modeKey); sync(); }}>
                          {TARGET_LABELS[modeKey]}
                        </button>
                      ))}
                    </div>
                    <div className="inspector-actions">
                      <button className="btn btn-wine btn-sm" onClick={() => { game.sellTower(selectedTower.uid); sync(); audio.sfx("coin"); }}>
                        <Trash2 size={11} /> Продать · {Math.floor(selectedTower.invested * 0.7)}
                      </button>
                    </div>
                  </div>
                ) : selectedProp ? (
                  <div className="inspector" style={{ borderTop: "1px solid var(--line)" }}>
                    <div className="inspector-top">
                      <div style={{ flex: 1 }}>
                        <h3 className="inspector-name">{PROP_DATA[selectedProp.type].name}</h3>
                        <div className="inspector-role">объект двора</div>
                      </div>
                      <span className="chip">{selectedProp.hp} / {selectedProp.maxHp} HP</span>
                    </div>
                    <p className="inspector-desc">{PROP_DATA[selectedProp.type].description}</p>
                    <button className="btn btn-wine btn-sm" onClick={() => { game.removeProp(selectedProp.uid); sync(); }}><Trash2 size={11} /> Разобрать</button>
                  </div>
                ) : selectedSpotDef ? (
                  <div className="inspector" style={{ borderTop: "1px solid var(--line)" }}>
                    <h3 className="inspector-name">Точка на дорожке</h3>
                    <p className="inspector-desc">Поставь на земле объект — он задержит или замедлит названных гостей. Выбери тип во вкладке «Объекты».</p>
                    <div className="prop-grid" style={{ padding: 0 }}>
                      {PROP_IDS.filter((id) => selectedSpotDef.allowed.includes(id)).map((id) => (
                        <button key={id} className="prop-btn" onClick={() => { game.buildProp(selectedSpotDef.id, id); sync(); }} disabled={snap.coins < PROP_DATA[id].cost}>
                          <span>{PROP_DATA[id].name}</span><span className="cost">{PROP_DATA[id].cost}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="hint-box" style={{ margin: 7 }}>
                    <LockKeyhole size={12} />
                    <span>Выбери постамент на карте. Закрытые площадки открываются по волнам за монеты.</span>
                  </div>
                )}
              </>
            ) : (
              <>
                <div className="prop-grid">
                  {PROP_IDS.map((id) => {
                    const allowed = selectedSpotDef ? selectedSpotDef.allowed.includes(id) : false;
                    return (
                      <button
                        key={id}
                        className="prop-btn"
                        disabled={!allowed || !selectedSpotDef || snap.coins < PROP_DATA[id].cost || !!game.props.find((prop) => prop.spot === snap.selectedSpot)}
                        onClick={() => { if (selectedSpotDef) { game.buildProp(selectedSpotDef.id, id); sync(); } }}
                        title={PROP_DATA[id].description}
                      >
                        <span>{PROP_DATA[id].name}</span><span className="cost">{PROP_DATA[id].cost}</span>
                      </button>
                    );
                  })}
                </div>
                <div style={{ padding: "0 10px 9px" }}>
                  {snap.selectedSpot === null ? (
                    <div className="hint-box"><Info size={12} /><span>Сначала выбери точку с пунктиром на дорожке.</span></div>
                  ) : (
                    <div className="hint-box"><Sparkles size={12} /><span>Доступно на этой точке: {selectedSpotDef?.allowed.map((id) => PROP_DATA[id].name).join(", ")}.</span></div>
                  )}
                </div>
              </>
            )}
          </div>

          </div>
          <div className="side-card" style={{ flex: "0 0 auto" }}>
            <div className="side-head"><h3><Music2 size={13} color="var(--gold)" /> Способности Альтушки</h3><span>Q · W · E</span></div>
            <div className="abilities-row">
              {([
                { id: "bucket" as const, icon: <Droplets size={13} /> },
                { id: "chord" as const, icon: <Music2 size={13} /> },
                { id: "cat" as const, icon: <Cat size={13} /> },
              ]).map(({ id, icon }) => {
                const ability = ABILITIES[id];
                const cooldown = snap.cooldowns[id] ?? 0;
                const disabled = !snap.waveActive || cooldown > 0 || paused;
                return (
                  <button
                    key={id}
                    className={cn("ability-btn", snap.targeting === id && "armed")}
                    disabled={disabled}
                    onClick={() => { game.armAbility(id); sync(); audio.sfx("ability"); }}
                    title={ability.description}
                  >
                    <span className="ability-key">{ability.key}</span>
                    <span className="ability-icon">{icon}</span>
                    <span className="ability-name">{ability.name}</span>
                    <span className={cn("ability-cd", cooldown <= 0 && "ready")}>{cooldown > 0 ? `${cooldown.toFixed(1)} с` : snap.waveActive ? "готова" : "в бой"}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {snap.perks.length > 0 && (
            <div className="side-card">
              <div className="side-head"><h3><Sparkles size={13} color="var(--gold)" /> Усиления</h3><span>{snap.perks.length}</span></div>
              <div className="perks-strip">
                {snap.perks.map((id) => {
                  const perk = PERKS.find((item) => item.id === id);
                  return perk ? <span key={id} className="perk-pill">{perk.name}</span> : null;
                })}
              </div>
            </div>
          )}

          <div className="side-card" style={{ padding: 10 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
              <span className="tiny">Стойкость подъезда</span>
              <span className="mono" style={{ fontSize: 10, color: "var(--wine)" }}>{snap.lives} / {snap.maxLives}</span>
            </div>
            <div style={{ height: 3, background: "rgba(255,255,255,.09)", borderRadius: 3 }}>
              <div style={{ height: "100%", width: `${(snap.lives / snap.maxLives) * 100}%`, background: "linear-gradient(90deg,#8f4553,#c77b82)", borderRadius: 3, transition: "width .25s ease" }} />
            </div>
            <p className="tiny" style={{ marginTop: 7, letterSpacing: ".08em", color: "var(--dim)", textTransform: "none", fontWeight: 500, lineHeight: 1.5 }}>
              {snap.lives <= 5 ? "Критично: подъезд почти потерян." : snap.lives >= 18 ? "Отлично: ни одной серьёзной пробоины." : "Каждый пропущенный гость забирает жизни навсегда."}
            </p>
          </div>
        </aside>
      </main>

      {/* мобильная панель: всегда под полем */}
      <div className="mobile-build">
        <div style={{ display: "flex", gap: 6, alignItems: "stretch", padding: "0 7px 6px" }}>
          <button className="btn btn-primary btn-sm" style={{ flex: 1 }} disabled={!canStart} onClick={startWave}>
            <Play size={12} fill="currentColor" /> {snap.waveActive ? `Волна ${snap.wave}` : snap.wave === 0 ? "Начать ночь" : `Волна +${snap.earlyBonus}`}
          </button>
          <button className="icon-button" onClick={cycleSpeed} title="Скорость"><FastForward size={14} /></button>
          <button className="icon-button" onClick={togglePause} title="Пауза">{paused ? <Play size={14} /> : <Pause size={14} />}</button>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(6, minmax(0, 1fr))", gap: 4, padding: "0 7px 6px" }}>
          {TOWER_IDS.map((id) => {
            const tower = TOWERS[id];
            return (
              <button key={id} className={cn("tower-card", snap.pendingTower === id && "selected")} style={{ flexDirection: "column", minHeight: 70, justifyContent: "center", gap: 2, padding: 4 }} disabled={snap.coins < tower.cost} onClick={() => { game.prepareTower(id); sync(); }}>
                <span className="tower-thumb" style={{ width: 26, height: 32 }}><img src={unitArt(id)} alt={tower.name} style={{ width: 26, height: 34 }} /></span>
                <span style={{ fontSize: 7.5, fontWeight: 700, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: "100%" }}>{tower.name.split(" ")[0]}</span>
                <span className="mono" style={{ fontSize: 8, color: "var(--gold)" }}>{tower.cost}</span>
              </button>
            );
          })}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 4, padding: "0 7px 6px" }}>
          {(["bucket", "chord", "cat"] as const).map((id) => {
            const cooldown = snap.cooldowns[id] ?? 0;
            return (
              <button key={id} className={cn("ability-btn", snap.targeting === id && "armed")} style={{ minHeight: 38, flexDirection: "row", alignItems: "center", gap: 6 }} disabled={!snap.waveActive || cooldown > 0} onClick={() => { game.armAbility(id); sync(); }}>
                {id === "bucket" ? <Droplets size={13} color="var(--gold)" /> : id === "chord" ? <Music2 size={13} color="var(--gold)" /> : <Cat size={13} color="var(--gold)" />}
                <span style={{ fontSize: 8, fontWeight: 700 }}>{ABILITIES[id].key} · {cooldown > 0 ? `${Math.ceil(cooldown)}с` : ABILITIES[id].name.split(" ")[0]}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
