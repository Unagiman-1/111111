import { useState } from "react";
import { ArrowUpRight, BadgeCheck, Bike, Bird, BookOpen, Crosshair, HardHat, HeartPulse, Package, Shield, Sparkles, Speaker, Swords, Users, UsersRound, Wine, Wind } from "lucide-react";
import { ABILITIES, ENEMIES, PROP_DATA, TOWERS } from "../game/data";
import { unitArt } from "../game/assets";
import type { DamageType, EnemyId, TowerId } from "../game/types";
import { BackButton } from "../components/ui";

const TABS = [
  { id: "defenders", label: "Защитники", icon: Shield },
  { id: "enemies", label: "Визитёры", icon: Users },
  { id: "mechanics", label: "Механика", icon: BookOpen },
  { id: "links", label: "Связки", icon: Sparkles },
] as const;
type Tab = (typeof TABS)[number]["id"];

const DMG_LABEL: Record<DamageType, string> = { soft: "мягкий", heavy: "тяжёлый", pierce: "пробитие", control: "контроль" };
const TAG_LABEL: Record<string, string> = { flesh: "плоть", helmet: "каска", armor: "броня", shield: "щит", swarm: "стая", flying: "летает", boss: "босс" };
const ENEMY_ICONS: Record<EnemyId, typeof Shield> = {
  skuf: Shield, scooter: Bike, helmet: HardHat, pigeons: Bird, armored: Shield,
  regen: HeartPulse, courier: Package, loudmouth: Speaker, cop: BadgeCheck,
  drunk: Wine, crowd: UsersRound, boss: Shield,
};

const TOWER_IDS = Object.keys(TOWERS) as TowerId[];
const ENEMY_IDS = Object.keys(ENEMIES) as EnemyId[];

export function CodexScreen({ onBack }: { onBack: () => void }) {
  const [tab, setTab] = useState<Tab>("defenders");

  return (
    <main className="shell page" style={{ flex: 1 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", gap: 20, flexWrap: "wrap", marginBottom: 24 }}>
        <div>
          <BackButton onClick={onBack} label="Главная" />
          <p className="eyebrow" style={{ margin: "18px 0 12px" }}>Справочник двора · редакция 2.0</p>
          <h1 className="display h1">Кто <span style={{ fontStyle: "italic", color: "var(--gold-bright)" }}>на посту</span></h1>
          <p className="lead" style={{ marginTop: 14 }}>
            Характеристики без тумана: кто по кому работает, чем опасен каждый визитёр
            и какие сочетания превращают квартиру в неприступную крепость.
          </p>
        </div>
        <div className="who-are-you panel" style={{ width: 290, padding: 14, display: "flex", gap: 12, alignItems: "flex-end", overflow: "hidden" }}>
          <img src={unitArt("altushka")} alt="Альтушка" style={{ height: 118, width: "auto", objectFit: "contain", filter: "drop-shadow(0 10px 18px rgba(0,0,0,.5))" }} />
          <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
            <span className="tiny">Герой · голос двора</span>
            <strong className="serif" style={{ fontSize: 22, lineHeight: 1, fontWeight: 600 }}>Альтушка</strong>
            <p className="body-s" style={{ fontSize: 10.5, margin: 0 }}>Сама стреляет по ближним целям и открывает три способности.</p>
            <div className="gold" style={{ display: "flex", gap: 4, fontSize: 9, fontFamily: "var(--mono)" }}>
              <span>Q</span><span>W</span><span>E</span><span className="dim">· гитара всегда рядом</span>
            </div>
          </div>
        </div>
      </div>

      <div className="codex-tabs" style={{ marginBottom: 22 }}>
        {TABS.map(({ id, label, icon: Icon }) => (
          <button key={id} className={`codex-tab ${tab === id ? "active" : ""}`} onClick={() => setTab(id)}>
            <Icon size={12} /> {label}
          </button>
        ))}
      </div>

      {tab === "defenders" && (
        <>
          <div className="codex-grid">
            {TOWER_IDS.map((id) => {
              const tower = TOWERS[id];
              return (
                <article className="unit-card" key={id}>
                  <div className="unit-portrait" style={{ ["--tone" as string]: `${tower.color}55` }}>
                    <img src={unitArt(id)} alt={tower.name} />
                  </div>
                  <div className="unit-card-copy">
                    <div>
                      <span className="unit-card-role">{tower.role}</span>
                      <h3 className="unit-card-name">{tower.name}</h3>
                    </div>
                    <p className="unit-card-text">{tower.description}</p>
                    <div className="unit-stats">
                      <div className="unit-stat"><b>{tower.cost}</b><span>монет</span></div>
                      <div className="unit-stat"><b>{tower.damage || "—"}</b><span>урон</span></div>
                      <div className="unit-stat"><b>{tower.rate ? tower.rate.toFixed(2) : "—"}</b><span>темп</span></div>
                      <div className="unit-stat"><b>{tower.range || "—"}</b><span>радиус</span></div>
                      <div className="unit-stat"><b>{DMG_LABEL[tower.damageType]}</b><span>тип</span></div>
                    </div>
                    <div style={{ borderTop: "1px solid var(--line)", paddingTop: 6, display: "flex", flexDirection: "column", gap: 4 }}>
                      {tower.branches.map((branch) => (
                        <div key={branch.id} style={{ display: "flex", gap: 6, alignItems: "baseline" }}>
                          <span style={{ color: "var(--gold)", fontSize: 8 }}>◆</span>
                          <span style={{ fontSize: 9.5, color: "#a9a7a0", lineHeight: 1.4 }}><b style={{ color: "#d8d3c8" }}>{branch.name}.</b> {branch.description}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </article>
              );
            })}
          </div>

          <div className="panel" style={{ marginTop: 18 }}>
            <div className="panel-head">
              <h3 className="panel-title">Объекты двора</h3>
              <span className="tiny">Помощь за монеты · «объекты» в игре</span>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(210px, 1fr))" }}>
              {(Object.keys(PROP_DATA) as (keyof typeof PROP_DATA)[]).map((id) => (
                <div key={id} style={{ padding: 16, borderRight: "1px solid var(--line)", borderTop: "1px solid var(--line)" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 5 }}>
                    <b style={{ fontFamily: "var(--serif)", fontSize: 18, fontWeight: 600 }}>{PROP_DATA[id].name}</b>
                    <span className="mono gold" style={{ fontSize: 11 }}>{PROP_DATA[id].cost}</span>
                  </div>
                  <p className="body-s" style={{ margin: 0, fontSize: 11 }}>{PROP_DATA[id].description}</p>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {tab === "enemies" && (
        <>
          <div className="codex-grid">
            {ENEMY_IDS.map((id) => {
              const enemy = ENEMIES[id];
              return (
                <article className="enemy-card" key={id}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 8 }}>
                    <div>
                      <span className="unit-card-role">{enemy.tags.map((tag) => TAG_LABEL[tag] ?? tag).join(" · ")}</span>
                      <h3 className="unit-card-name" style={{ fontSize: 20 }}>{enemy.name}</h3>
                    </div>
                    <span className="chip">{enemy.short}</span>
                  </div>
                  <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                    {id === "skuf" || id === "boss" ? (
                      <div className="enemy-art" style={{ width: 66, height: 84, flex: "0 0 auto" }}>
                        <img src={unitArt(id)} alt={enemy.name} />
                      </div>
                    ) : (
                      <div
                        aria-hidden="true"
                        style={{
                          flex: "0 0 auto", width: 60, height: 60, borderRadius: "50%",
                          border: `1px solid ${enemy.color}66`,
                          background: `radial-gradient(circle at 34% 26%, ${enemy.color}44, rgba(9,12,17,.7) 72%)`,
                          display: "grid", placeItems: "center", position: "relative",
                          boxShadow: `inset 0 0 22px ${enemy.color}22`,
                        }}
                      >
                        {(() => { const Icon = ENEMY_ICONS[id]; return <Icon size={22} color={enemy.color} strokeWidth={1.5} />; })()}
                        <span className="mono" style={{ position: "absolute", bottom: -5, right: -3, fontSize: 7, color: enemy.color, border: `1px solid ${enemy.color}55`, background: "#0e1219", padding: "0 3px", letterSpacing: ".08em" }}>{enemy.short}</span>
                      </div>
                    )}
                    <p className="body-s" style={{ margin: 0, fontSize: 11, flex: 1 }}>{enemy.behavior}</p>
                  </div>
                  <div className="unit-stats" style={{ marginTop: 0 }}>
                    <div className="unit-stat"><b>{enemy.hp}</b><span>HP</span></div>
                    <div className="unit-stat"><b>{enemy.speed}</b><span>скорость</span></div>
                    <div className="unit-stat"><b>{enemy.armor}</b><span>броня</span></div>
                    <div className="unit-stat"><b>{enemy.reward}</b><span>монет</span></div>
                  </div>
                  <div className="enemy-traits">
                    {Object.entries(enemy.resists).map(([type, value]) => (
                      <span key={type} className={`chip ${value > 1 ? "sage" : "wine"}`} style={{ fontSize: 8 }}>
                        {DMG_LABEL[type as DamageType]} ×{value}
                      </span>
                    ))}
                    {id === "cop" ? <span className="chip">щит 90</span> : null}
                  </div>
                </article>
              );
            })}
          </div>
          <div className="hint-box" style={{ marginTop: 18 }}>
            <Crosshair size={14} />
            <span>Подсказка: тип урона важнее урона. «Мягкий» вязнет в касках, «тяжёлый» плохо попадает по голубям, «пробитие» почти игнорирует броню, «контроль» замедляет и оглушает.</span>
          </div>
        </>
      )}

      {tab === "mechanics" && (
        <div className="codex-grid" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))" }}>
          {[
            { icon: <Shield size={16} />, title: "Площадки и препятствия", text: "Свободные места подсвечены на земле. Закрытые площадки открываются за монеты по мере волн. На дорожках можно ставить объекты: мебель тормозит врагов, а сигнализация ставит их на паузу." },
            { icon: <Swords size={16} />, title: "Четыре типа урона", text: "Мягкий — от Альтушки и Леры. Тяжёлый — сковородки и фонарь. Пробитие — Барсик. Контроль — динамик. Сопротивления врагов указаны в бестиарии и решают бой больше, чем цифры урона." },
            { icon: <HeartPulse size={16} />, title: "Жизни подъезда", text: "Двадцать жизней на кампанию. Каждый прорвавшийся визитёр снимает одну-две — босс до пяти. Не пускай врагов к двери: урон не восстанавливается." },
            { icon: <Wind size={16} />, title: "Воздух и земля", text: "Голуби летят над диванами и Бабой Валей. Лера, Барсик, динамик и дозорный умеют сбивать воздух. Прожектор дозорного по летающим бьёт на 50% сильнее." },
            { icon: <Sparkles size={16} />, title: "Улучшения и ветки", text: "Каждый защитник улучшается до четвёртого уровня. На втором уровне выбирается одна из двух веток; четвёртый открывает капстоун. Выбор необратим — продать башню можно за 70% вложений." },
            { icon: <Users size={16} />, title: "Соседские связки", text: "Связи считаются между ближайшими площадками. Динамик рядом с Бабой Валей добавляет урон по замедленным, кот с дозорным бьёт вдвое, киоск разгоняет любую башню рядом." },
          ].map((item, i) => (
            <article className="mechanic-card" key={item.title}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                <span className="gold">{item.icon}</span>
                <span className="mechanic-num">{String(i + 1).padStart(2, "0")}</span>
              </div>
              <h3 className="display" style={{ fontSize: 23 }}>{item.title}</h3>
              <p className="body-s" style={{ margin: 0, fontSize: 12 }}>{item.text}</p>
            </article>
          ))}
          <article className="panel" style={{ gridColumn: "1 / -1" }}>
            <div className="panel-head"><h3 className="panel-title">Три способности Альтушки</h3><span className="tiny">перезарядка в секундах</span></div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))" }}>
              {Object.entries(ABILITIES).map(([id, ability]) => (
                <div key={id} style={{ padding: 18, borderRight: "1px solid var(--line)" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                    <span className="chip gold">{ability.key}</span>
                    <b style={{ fontFamily: "var(--serif)", fontSize: 19, fontWeight: 600 }}>{ability.name}</b>
                  </div>
                  <p className="body-s" style={{ margin: "0 0 6px", fontSize: 11.5 }}>{ability.description}</p>
                  <span className="tiny">радиус {ability.radius} · КД {ability.cooldown} с</span>
                </div>
              ))}
            </div>
          </article>
        </div>
      )}

      {tab === "links" && (
        <div style={{ display: "grid", gap: 12 }}>
          {[
            { a: "patrol", b: "cat", name: "В голову", effect: "Кот наносит двойной урон по любой цели, которую держит дозорный. С перком «Дружный подъезд» — ×2,25.", color: "#dcc477" },
            { a: "speaker", b: "granny", name: "Синкопа", effect: "Сковородки Бабы Вали бьют по замедленным на 50% сильнее. С перком «Дружный подъезд» — на 65%.", color: "#b39ad2" },
            { a: "kiosk", b: "girlfriend", name: "Энергетик", effect: "Киоск ускоряет соседние башни на 30–45% и платит монетами. Лучшая экономика в центре двора.", color: "#d79a68" },
          ].map((link) => (
            <article key={link.name} className="link-card">
              <div className="link-orbs">
                <div className="link-orb"><img src={unitArt(link.a)} alt="" /></div>
                <span className="link-plus">+</span>
                <div className="link-orb"><img src={unitArt(link.b)} alt="" /></div>
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 9, flexWrap: "wrap" }}>
                  <h3 style={{ margin: 0, fontFamily: "var(--serif)", fontSize: 23, fontWeight: 600 }}>{link.name}</h3>
                  <span className="chip" style={{ color: link.color, borderColor: `${link.color}55` }}>связь</span>
                </div>
                <p className="body-s" style={{ margin: "4px 0 0", fontSize: 12 }}>{link.effect}</p>
              </div>
              <ArrowUpRight size={15} style={{ color: "var(--dim)", flex: "0 0 auto" }} />
            </article>
          ))}
          <div className="panel">
            <div className="panel-head"><h3 className="panel-title">Как читать связи</h3></div>
            <div className="panel-body" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 16 }}>
              <p className="body-s" style={{ margin: 0, fontSize: 12 }}>Связка возникает, когда две площадки находятся рядом. На карте такие пары видны тонкой пунктирной линией с названием.</p>
              <p className="body-s" style={{ margin: 0, fontSize: 12 }}>На втором уровне башни выбери ветку: она меняет роль. Не бойся продавать — 70% вложений вернётся в кассу.</p>
              <p className="body-s" style={{ margin: 0, fontSize: 12 }}>Комбинируй экономику и оборону: киоск в центре окупается к седьмой волне, если его не украли курьеры.</p>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
