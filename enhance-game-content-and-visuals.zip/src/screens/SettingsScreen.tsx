import { useState } from "react";
import { AudioLines, Check, ExternalLink, Music2, Play, RotateCcw, Sparkles, Volume1, Volume2, Waves } from "lucide-react";
import { AMBIENCES, TRACKS, audio } from "../audio/director";
import { BackButton, Stars } from "../components/ui";
import { totalStars, type Progress } from "../game/progress";

export function SettingsScreen({
  onBack, progress, onResetProgress,
}: {
  onBack: () => void;
  progress: Progress;
  onResetProgress: () => void;
}) {
  const [music, setMusic] = useState(audio.settings.music);
  const [sfx, setSfx] = useState(audio.settings.sfx);
  const [ambient, setAmbient] = useState(audio.settings.ambient);
  const [ambientId, setAmbientId] = useState("night");
  const [trackId, setTrackId] = useState(audio.current?.id ?? "hidden");
  const [musicVol, setMusicVol] = useState(Math.round(audio.settings.musicVolume * 100));
  const [sfxVol, setSfxVol] = useState(Math.round(audio.settings.sfxVolume * 100));
  const [ambientVol, setAmbientVol] = useState(Math.round(audio.settings.ambientVolume * 100));
  const [confirmReset, setConfirmReset] = useState(false);

  const update = <K extends "music" | "sfx" | "ambient">(key: K, value: boolean) => {
    audio.unlock();
    audio.set(key, value);
    if (key === "music") setMusic(value);
    if (key === "sfx") setSfx(value);
    if (key === "ambient") { setAmbient(value); if (value) { audio.setAmbient(ambientId); audio.sfx("wave"); } }
    if (value) audio.click();
  };

  const pickTrack = (id: string) => {
    audio.unlock();
    setTrackId(id);
    audio.set("music", true);
    setMusic(true);
    audio.playTrack(id, true);
    audio.sfx("coin");
  };

  return (
    <main className="shell page" style={{ flex: 1 }}>
      <div style={{ marginBottom: 26 }}>
        <BackButton onClick={onBack} label="Главная" />
        <p className="eyebrow" style={{ margin: "18px 0 12px" }}>Настройки · звук · память</p>
        <h1 className="display h1">Тише. <span style={{ fontStyle: "italic", color: "var(--gold-bright)" }}>Слышишь двор?</span></h1>
        <p className="lead" style={{ marginTop: 14 }}>
          Саундтрек и атмосфера подгружаются из интернета: четыре трека Kevin MacLeod
          и звуковая библиотека Google. Если сети нет, включится тихий встроенный ноктюрн.
        </p>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 12, flexWrap: "wrap" }}>
          <span className="chip gold"><span className="dot" /> интернет-аудио</span>
          <span className="chip">без загрузки файлов</span>
          <span className="chip">CC-лицензии</span>
        </div>
      </div>

      <div className="settings-grid">
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <section className="panel">
            <div className="panel-head"><h2 className="panel-title">Звук</h2><AudioLines size={16} color="var(--gold)" /></div>
            <div className="panel-body" style={{ paddingTop: 4, paddingBottom: 4 }}>
              <div className="setting-row">
                <div className="setting-copy"><h4>Музыка</h4><p>Нуарный фон для меню и боёв. Не останавливается при смене экрана.</p></div>
                <button className={`switch ${music ? "on" : ""}`} onClick={() => update("music", !music)} aria-label="Музыка" aria-pressed={music} />
              </div>
              <div className="setting-row">
                <div className="setting-copy"><h4>Звуковые эффекты</h4><p>Выстрелы, монеты, сковородки, тревога и появление управдома.</p></div>
                <button className={`switch ${sfx ? "on" : ""}`} onClick={() => update("sfx", !sfx)} aria-label="Звуковые эффекты" aria-pressed={sfx} />
              </div>
              <div className="setting-row">
                <div className="setting-copy"><h4>Атмосфера локации</h4><p>Ночной двор или гул теплопункта — тихий фоновый слой под музыку.</p></div>
                <button className={`switch ${ambient ? "on" : ""}`} onClick={() => update("ambient", !ambient)} aria-label="Атмосфера" aria-pressed={ambient} />
              </div>
              <div className="setting-row" style={{ alignItems: "flex-start", opacity: ambient ? 1 : 0.5 }}>
                <div className="setting-copy"><h4>Фоновая атмосфера</h4><p>Выбери, что слышно за спиной.</p></div>
                <div style={{ display: "flex", gap: 4, flexWrap: "wrap", justifyContent: "flex-end" }}>
                  {AMBIENCES.filter((item) => item.id !== "none").map((item) => (
                    <button
                      key={item.id}
                      className={`chip ${ambientId === item.id && ambient ? "gold" : ""}`}
                      onClick={() => { setAmbientId(item.id); audio.setAmbient(item.id); if (!ambient) update("ambient", true); }}
                    >
                      {item.title}
                    </button>
                  ))}
                </div>
              </div>
              <div className="setting-row">
                <div className="setting-copy"><h4>Громкость музыки</h4></div>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <Volume1 size={13} color="var(--dim)" />
                  <input className="range" type="range" min={0} max={100} value={musicVol} onChange={(e) => { const value = Number(e.target.value); setMusicVol(value); audio.set("musicVolume", value / 100); }} />
                  <span className="mono" style={{ fontSize: 10, color: "var(--gold)", width: 26, textAlign: "right" }}>{musicVol}</span>
                </div>
              </div>
              <div className="setting-row">
                <div className="setting-copy"><h4>Громкость эффектов</h4></div>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <Volume2 size={13} color="var(--dim)" />
                  <input className="range" type="range" min={0} max={100} value={sfxVol} onChange={(e) => { const value = Number(e.target.value); setSfxVol(value); audio.set("sfxVolume", value / 100); }} />
                  <span className="mono" style={{ fontSize: 10, color: "var(--gold)", width: 26, textAlign: "right" }}>{sfxVol}</span>
                </div>
              </div>
              <div className="setting-row">
                <div className="setting-copy"><h4>Громкость атмосферы</h4></div>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <Waves size={13} color="var(--dim)" />
                  <input className="range" type="range" min={0} max={100} value={ambientVol} onChange={(e) => { const value = Number(e.target.value); setAmbientVol(value); audio.set("ambientVolume", value / 100); }} />
                  <span className="mono" style={{ fontSize: 10, color: "var(--gold)", width: 26, textAlign: "right" }}>{ambientVol}</span>
                </div>
              </div>
            </div>
          </section>

          <section className="panel">
            <div className="panel-head">
              <h2 className="panel-title">Саундтрек</h2>
              <span className="tiny">Kevin MacLeod · archive.org</span>
            </div>
            <div className="panel-body">
              {TRACKS.map((track, index) => {
                const active = trackId === track.id;
                return (
                  <button key={track.id} className={`track-row ${active ? "active" : ""}`} onClick={() => pickTrack(track.id)}>
                    <span className="track-index">{String(index + 1).padStart(2, "0")}</span>
                    <span style={{ flex: 1, minWidth: 0 }}>
                      <span style={{ display: "block", fontSize: 12.5, fontWeight: 700, color: active ? "var(--gold-bright)" : "var(--paper)" }}>{track.title}</span>
                      <span style={{ display: "block", fontSize: 9, letterSpacing: ".08em", textTransform: "uppercase", color: "var(--dim)", marginTop: 2 }}>{track.artist} · {track.mood}</span>
                    </span>
                    {active ? <Check size={14} color="var(--gold)" /> : <Play size={13} color="var(--dim)" />}
                  </button>
                );
              })}
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 12 }}>
                <button className="btn btn-ghost btn-sm" onClick={() => { audio.unlock(); audio.sfx("build"); setTimeout(() => audio.sfx("upgrade"), 240); setTimeout(() => audio.sfx("coin"), 480); }}>
                  <Music2 size={12} /> Проверить эффекты
                </button>
                <span className="chip" style={{ alignSelf: "center" }}>{audio.current ? `сейчас: ${audio.current.title}` : "выбери трек"}</span>
              </div>
            </div>
          </section>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <section className="panel">
            <div className="panel-head"><h2 className="panel-title">Прогресс</h2><Sparkles size={16} color="var(--gold)" /></div>
            <div className="panel-body" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span className="body-s">Собрано звёзд</span>
                <Stars value={Math.min(3, totalStars(progress))} max={3} />
              </div>
              <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between" }}>
                <span className="mono" style={{ fontSize: 30, color: "var(--gold-bright)" }}>{totalStars(progress)}</span>
                <span className="tiny">из 9 возможных</span>
              </div>
              <hr className="rule" />
              <p className="body-s" style={{ margin: 0, fontSize: 11.5 }}>
                Прогресс хранится в этом браузере. Чтобы сохранить рекорды на другом устройстве,
                просто запомни, на какой волне пал подъезд.
              </p>
              {confirmReset ? (
                <div style={{ display: "flex", gap: 6 }}>
                  <button className="btn btn-wine btn-sm" style={{ flex: 1 }} onClick={() => { onResetProgress(); setConfirmReset(false); }}>Удалить навсегда</button>
                  <button className="btn btn-ghost btn-sm" onClick={() => setConfirmReset(false)}>Отмена</button>
                </div>
              ) : (
                <button className="btn btn-ghost btn-sm" onClick={() => setConfirmReset(true)} style={{ justifyContent: "flex-start", paddingInline: 0 }}>
                  <RotateCcw size={12} /> Сбросить прогресс
                </button>
              )}
            </div>
          </section>

          <section className="panel">
            <div className="panel-head"><h2 className="panel-title">Музыка и звуки</h2></div>
            <div className="panel-body credits-list">
              <p style={{ margin: 0 }}>
                Музыка: <a href="https://incompetech.com/" target="_blank" rel="noreferrer">Kevin MacLeod</a> — треки Hidden Agenda, Cold Funk, Southern Gothic, Hypnothis.
                Лицензии <a href="https://creativecommons.org/licenses/by/4.0/" target="_blank" rel="noreferrer">CC BY</a> и CC0.
                Размещено на <a href="https://archive.org/" target="_blank" rel="noreferrer">archive.org</a>.
              </p>
              <p style={{ margin: 0 }}>
                Эффекты: <a href="https://developers.google.com/assistant/tools/sound-library" target="_blank" rel="noreferrer">Google Sound Library</a> — удары, монеты, колокольчики, тревога, гул.
              </p>
              <p style={{ margin: 0 }}>Иллюстрации персонажей — оригинальные арты из архива игры. Фоны арки и котельной созданы для этой версии отдельно.</p>
            </div>
          </section>

          <section className="panel">
            <div className="panel-head"><h2 className="panel-title">Об игре</h2></div>
            <div className="panel-body" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              <div style={{ display: "flex", justifyContent: "space-between" }}><span className="tiny">Проект</span><span className="body-s" style={{ fontSize: 11.5 }}>Альтушка TD · Ночной двор</span></div>
              <div style={{ display: "flex", justifyContent: "space-between" }}><span className="tiny">Версия</span><span className="mono" style={{ fontSize: 11.5 }}>2.0 · nocturne</span></div>
              <div style={{ display: "flex", justifyContent: "space-between" }}><span className="tiny">Локации</span><span className="body-s" style={{ fontSize: 11.5 }}>Двор · Арка · Котельная</span></div>
              <div style={{ display: "flex", justifyContent: "space-between" }}><span className="tiny">Название</span><span className="body-s" style={{ fontSize: 11.5 }}>Альтушка <span className="dim">(не «Алтушка»)</span></span></div>
              <hr className="rule" style={{ marginBlock: 4 }} />
              <p className="body-s" style={{ margin: 0, fontSize: 11 }}>Классическая tower defense о дворе, где все своих знают. Ошибки прощаются, а вот управдома лучше не пускать.</p>
            </div>
          </section>

          <button className="btn btn-primary" onClick={onBack}>
            <Play size={14} fill="currentColor" /> Вернуться во двор
          </button>
        </div>
      </div>

      <footer style={{ marginTop: 32, paddingTop: 18, borderTop: "1px solid var(--line)", display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 10 }}>
        <span className="tiny">Альтушка · ночной двор · 2026</span>
        <a className="tiny" href="https://github.com/Unagiman-1/123" target="_blank" rel="noreferrer" style={{ display: "inline-flex", alignItems: "center", gap: 5, color: "var(--muted)", textDecoration: "none" }}>
          оригинальный проект <ExternalLink size={10} />
        </a>
      </footer>
    </main>
  );
}
