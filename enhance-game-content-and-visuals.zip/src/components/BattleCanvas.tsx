import { useEffect, useRef } from "react";
import { ABILITIES, ENEMIES, LOGICAL_HEIGHT, LOGICAL_WIDTH, TOWERS } from "../game/data";
import type { Game } from "../game/engine";
import type { Enemy, Snapshot, Tower, Vec } from "../game/types";
import { imageFor, locationArt, unitArt } from "../game/assets";
import { audio } from "../audio/director";

const IMG = {
  altushka: imageFor(unitArt("altushka")),
  girlfriend: imageFor(unitArt("girlfriend")),
  granny: imageFor(unitArt("granny")),
  cat: imageFor(unitArt("cat")),
  kiosk: imageFor(unitArt("kiosk")),
  patrol: imageFor(unitArt("patrol")),
  speaker: imageFor(unitArt("speaker")),
  skuf: imageFor(unitArt("skuf")),
  boss: imageFor(unitArt("boss")),
};
const MAP_IMG = {
  yard: imageFor(locationArt("yard")),
  arch: imageFor(locationArt("arch")),
  boiler: imageFor(locationArt("boiler")),
};

const UI_FONT = '"Manrope", "Segoe UI", sans-serif';
const SERIF_FONT = '"Cormorant Garamond", Georgia, serif';
const MONO_FONT = '"JetBrains Mono", ui-monospace, monospace';
const TAU = Math.PI * 2;

type View = { scale: number; offsetX: number; offsetY: number; width: number; height: number };

function hexA(hex: string, alpha: number) {
  const value = hex.replace("#", "");
  const full = value.length === 3 ? value.split("").map((c) => c + c).join("") : value;
  const num = parseInt(full, 16);
  return `rgba(${(num >> 16) & 255}, ${(num >> 8) & 255}, ${num & 255}, ${alpha})`;
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + w, y, x + w, y + h, radius);
  ctx.arcTo(x + w, y + h, x, y + h, radius);
  ctx.arcTo(x, y + h, x, y, radius);
  ctx.arcTo(x, y, x + w, y, radius);
  ctx.closePath();
}

function drawImage(ctx: CanvasRenderingContext2D, image: HTMLImageElement, x: number, y: number, height: number, flash = 0, alpha = 1) {
  if (!image.complete || !image.naturalWidth) return;
  const width = height * (image.naturalWidth / image.naturalHeight);
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.drawImage(image, x - width / 2, y - height, width, height);
  if (flash > 0) {
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = Math.min(0.55, flash * 0.5);
    ctx.drawImage(image, x - width / 2, y - height, width, height);
  }
  ctx.restore();
}

function bar(ctx: CanvasRenderingContext2D, x: number, y: number, width: number, ratio: number, color: string, height = 3) {
  ctx.fillStyle = "rgba(4,6,10,.8)";
  ctx.fillRect(x - width / 2, y, width, height);
  ctx.fillStyle = color;
  ctx.fillRect(x - width / 2, y, width * Math.max(0, Math.min(1, ratio)), height);
}

export function BattleCanvas({
  game, onSnapshot,
}: {
  game: Game;
  onSnapshot: (snapshot: Snapshot) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const viewRef = useRef<View>({ scale: 1, offsetX: 0, offsetY: 0, width: 1200, height: 720 });
  const pointerRef = useRef<Vec | null>(null);
  const hoverRef = useRef<number | null>(null);
  const snapshotRef = useRef(onSnapshot);
  snapshotRef.current = onSnapshot;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    let last = performance.now();
    let accumulator = 0;
    let lastUi = 0;
    const STEP = 1 / 60;

    const frame = (now: number) => {
      const dt = Math.min(0.06, (now - last) / 1000);
      last = now;
      accumulator += dt * game.speed;
      let steps = 0;
      while (accumulator >= STEP && steps < 7) {
        game.update(STEP);
        accumulator -= STEP;
        steps++;
      }
      if (steps === 7) accumulator = 0;

      for (const event of game.events.splice(0)) audio.event(event);
      const boss = game.enemies.some((enemy) => enemy.type === "boss" && !enemy.dead);
      audio.setScene(boss ? "boss" : (game.map.background === "yard" ? "yard" : game.map.background === "arch" ? "arch" : "boiler"));

      draw(ctx, canvas, game, pointerRef.current, hoverRef.current, viewRef.current);

      if (now - lastUi > 85) {
        lastUi = now;
        snapshotRef.current(game.snapshot());
      }
      raf = requestAnimationFrame(frame);
    };

    const toWorld = (event: PointerEvent): Vec | null => {
      const rect = canvas.getBoundingClientRect();
      const view = viewRef.current;
      const sx = ((event.clientX - rect.left) / rect.width) * view.width;
      const sy = ((event.clientY - rect.top) / rect.height) * view.height;
      return { x: (sx - view.offsetX) / view.scale, y: (sy - view.offsetY) / view.scale };
    };

    const move = (event: PointerEvent) => {
      const point = toWorld(event);
      pointerRef.current = point;
      if (!point) return;
      let hover: number | null = null;
      let best = 52;
      for (const pad of game.map.pads) {
        const distance = Math.hypot(pad.x - point.x, pad.y - point.y);
        if (distance < best) { best = distance; hover = pad.id; }
      }
      hoverRef.current = hover;
      const tower = hover !== null ? game.towers.find((item) => item.pad === hover) : null;
      canvas.style.cursor = game.targeting ? "crosshair" : tower || (hover !== null && game.unlockedPads.includes(hover)) ? "pointer" : "default";
    };
    const down = (event: PointerEvent) => {
      event.preventDefault();
      audio.unlock();
      const point = toWorld(event);
      if (!point) return;
      if (event.button === 2) {
        game.targeting = null;
        game.selectedPad = null;
        game.selectedTowerUid = null;
        game.selectedPropUid = null;
        game.selectedSpot = null;
        game.pendingTower = null;
      } else if (game.targeting) {
        game.castAbility(point.x, point.y);
      } else {
        game.selectAt(point.x, point.y);
        audio.sfx("click");
      }
      snapshotRef.current(game.snapshot());
    };
    const leave = () => { pointerRef.current = null; hoverRef.current = null; };
    const context = (event: Event) => event.preventDefault();

    canvas.addEventListener("pointermove", move);
    canvas.addEventListener("pointerdown", down);
    canvas.addEventListener("pointerleave", leave);
    canvas.addEventListener("contextmenu", context);
    last = performance.now();
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      canvas.removeEventListener("pointermove", move);
      canvas.removeEventListener("pointerdown", down);
      canvas.removeEventListener("pointerleave", leave);
      canvas.removeEventListener("contextmenu", context);
    };
  }, [game]);

  return <canvas ref={canvasRef} className="board-canvas" aria-label="Игровое поле: защищай подъезд от ночных гостей" />;
}

/* ================================================================ отрисовка */
function draw(ctx: CanvasRenderingContext2D, canvas: HTMLCanvasElement, game: Game, pointer: Vec | null, hover: number | null, viewOut: View) {
  const cssWidth = canvas.clientWidth;
  const cssHeight = canvas.clientHeight;
  if (!cssWidth || !cssHeight) return;
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const pixelWidth = Math.round(cssWidth * dpr);
  const pixelHeight = Math.round(cssHeight * dpr);
  if (canvas.width !== pixelWidth || canvas.height !== pixelHeight) {
    canvas.width = pixelWidth;
    canvas.height = pixelHeight;
  }
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, pixelWidth, pixelHeight);
  ctx.scale(dpr, dpr);

  const cover = Math.max(cssWidth / LOGICAL_WIDTH, cssHeight / LOGICAL_HEIGHT);
  const coverX = (cssWidth - LOGICAL_WIDTH * cover) / 2;
  const coverY = (cssHeight - LOGICAL_HEIGHT * cover) / 2;
  const map = game.map;
  const background = MAP_IMG[map.background] ?? MAP_IMG.yard;

  if (background.complete && background.naturalWidth) {
    ctx.save();
    ctx.globalAlpha = 0.9;
    ctx.drawImage(background, coverX, coverY, LOGICAL_WIDTH * cover, LOGICAL_HEIGHT * cover);
    ctx.restore();
  } else {
    const gradient = ctx.createLinearGradient(0, 0, 0, cssHeight);
    gradient.addColorStop(0, "#18202a");
    gradient.addColorStop(1, "#0b0f15");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, cssWidth, cssHeight);
  }

  // Затемнение и цветовой аккорд локации.
  ctx.fillStyle = "rgba(7, 10, 15, .43)";
  ctx.fillRect(0, 0, cssWidth, cssHeight);
  ctx.fillStyle = hexA(map.tint, 0.1);
  ctx.fillRect(0, 0, cssWidth, cssHeight);
  const vignette = ctx.createRadialGradient(cssWidth / 2, cssHeight * 0.46, Math.min(cssWidth, cssHeight) * 0.24, cssWidth / 2, cssHeight * 0.5, Math.max(cssWidth, cssHeight) * 0.78);
  vignette.addColorStop(0, "rgba(0,0,0,0)");
  vignette.addColorStop(0.7, "rgba(5,7,11,.18)");
  vignette.addColorStop(1, "rgba(5,7,11,.72)");
  ctx.fillStyle = vignette;
  ctx.fillRect(0, 0, cssWidth, cssHeight);

  // Рабочая область карты — вписана по центру.
  const scale = Math.min(cssWidth / LOGICAL_WIDTH, cssHeight / LOGICAL_HEIGHT);
  const offsetX = (cssWidth - LOGICAL_WIDTH * scale) / 2;
  const offsetY = (cssHeight - LOGICAL_HEIGHT * scale) / 2;
  viewOut.scale = scale; viewOut.offsetX = offsetX; viewOut.offsetY = offsetY;
  viewOut.width = cssWidth; viewOut.height = cssHeight;
  ctx.translate(offsetX, offsetY);
  ctx.scale(scale, scale);

  drawPaths(ctx, game);
  drawLinks(ctx, game);
  drawPads(ctx, game, hover);
  drawProps(ctx, game);
  drawEffects(ctx, game);
  drawSelection(ctx, game);

  const enemies = [...game.enemies].filter((enemy) => !enemy.dead).sort((a, b) => game.enemyPos(a).y - game.enemyPos(b).y);
  for (const enemy of enemies) drawEnemy(ctx, game, enemy);

  for (const tower of game.towers) drawTower(ctx, game, tower);
  drawHero(ctx, game);

  drawProjectiles(ctx, game);
  drawParticles(ctx, game);
  drawBossTelegraph(ctx, game);
  drawTargeting(ctx, game, pointer);
  drawHover(ctx, game, hover);
  drawFrame(ctx, game);

  ctx.setTransform(1, 0, 0, 1, 0, 0);
}

function drawPaths(ctx: CanvasRenderingContext2D, game: Game) {
  for (const path of game.map.paths) {
    ctx.lineJoin = "round";
    ctx.lineCap = "round";
    ctx.beginPath();
    path.forEach((point, index) => (index ? ctx.lineTo(point.x, point.y) : ctx.moveTo(point.x, point.y)));
    ctx.strokeStyle = "rgba(8, 10, 14, .42)";
    ctx.lineWidth = 46;
    ctx.stroke();
    ctx.strokeStyle = "rgba(222, 209, 185, .07)";
    ctx.lineWidth = 30;
    ctx.stroke();
    ctx.strokeStyle = "rgba(226, 210, 180, .3)";
    ctx.lineWidth = 1.4;
    ctx.setLineDash([7, 17]);
    ctx.lineDashOffset = -(game.time * 12) % 24;
    ctx.stroke();
    ctx.setLineDash([]);

    // стрелки по маршруту
    let distance = 150;
    const segments = path.length - 1;
    for (let i = 1; i <= segments; i++) {
      const a = path[i - 1];
      const b = path[i];
      const length = Math.hypot(b.x - a.x, b.y - a.y);
      while (distance < length) {
        const t = distance / length;
        const x = a.x + (b.x - a.x) * t;
        const y = a.y + (b.y - a.y) * t;
        const angle = Math.atan2(b.y - a.y, b.x - a.x);
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(angle);
        ctx.strokeStyle = "rgba(233, 216, 183, .28)";
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        ctx.moveTo(-4, -4); ctx.lineTo(2, 0); ctx.lineTo(-4, 4);
        ctx.stroke();
        ctx.restore();
        distance += 105;
      }
      distance -= length;
    }

    const start = path[0];
    const inX = Math.max(24, Math.min(LOGICAL_WIDTH - 24, start.x));
    const inY = Math.max(24, Math.min(LOGICAL_HEIGHT - 24, start.y));
    ctx.strokeStyle = "rgba(179, 103, 117, .6)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(inX, inY, 9, 0, TAU);
    ctx.stroke();
    ctx.fillStyle = "rgba(179, 103, 117, .16)";
    ctx.fill();
    ctx.fillStyle = "rgba(242, 236, 223, .7)";
    ctx.font = `700 7px ${UI_FONT}`;
    ctx.textAlign = "center";
    ctx.fillText("ВХОД", inX, inY + 3);
  }

  const end = game.map.paths[0][game.map.paths[0].length - 2];
  const pulse = 0.6 + Math.sin(game.time * 2.4) * 0.18;
  const glow = ctx.createRadialGradient(end.x, end.y, 4, end.x, end.y, 72);
  glow.addColorStop(0, `rgba(217, 187, 130, ${0.24 * pulse})`);
  glow.addColorStop(1, "rgba(217, 187, 130, 0)");
  ctx.fillStyle = glow;
  ctx.fillRect(end.x - 80, end.y - 80, 160, 160);
  ctx.save();
  ctx.translate(end.x, end.y);
  roundRect(ctx, -23, -30, 46, 60, 4);
  ctx.fillStyle = "rgba(10, 13, 18, .86)";
  ctx.fill();
  ctx.strokeStyle = "rgba(217, 187, 130, .55)";
  ctx.lineWidth = 1;
  ctx.stroke();
  roundRect(ctx, -14, -19, 28, 34, 2);
  ctx.strokeStyle = "rgba(217, 187, 130, .32)";
  ctx.stroke();
  ctx.fillStyle = "rgba(236, 203, 141, .55)";
  ctx.fillRect(-10, -14, 8, 12);
  ctx.fillRect(2, -14, 8, 12);
  ctx.fillStyle = "rgba(242, 236, 223, .62)";
  ctx.font = `700 7px ${UI_FONT}`;
  ctx.textAlign = "center";
  ctx.fillText("ПОДЪЕЗД", 0, 42);
  ctx.restore();
}

function drawLinks(ctx: CanvasRenderingContext2D, game: Game) {
  for (const link of game.getLinks()) {
    const a = game.padPos(link.a);
    const b = game.padPos(link.b);
    ctx.save();
    ctx.strokeStyle = hexA(link.color, 0.55);
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 5]);
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
    ctx.setLineDash([]);
    const midX = (a.x + b.x) / 2;
    const midY = (a.y + b.y) / 2;
    ctx.font = `700 7px ${UI_FONT}`;
    const width = ctx.measureText(link.name).width + 12;
    roundRect(ctx, midX - width / 2, midY - 7, width, 14, 2);
    ctx.fillStyle = "rgba(10, 13, 18, .8)";
    ctx.fill();
    ctx.strokeStyle = hexA(link.color, 0.4);
    ctx.stroke();
    ctx.fillStyle = link.color;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(link.name, midX, midY);
    ctx.restore();
  }
}

function drawPads(ctx: CanvasRenderingContext2D, game: Game, hover: number | null) {
  for (const pad of game.map.pads) {
    const unlocked = game.unlockedPads.includes(pad.id);
    const tower = game.towers.find((item) => item.pad === pad.id);
    const active = game.selectedPad === pad.id;
    const isHover = hover === pad.id;
    const color = tower ? TOWERS[tower.type].color : "#d9bb82";

    ctx.save();
    ctx.translate(pad.x, pad.y);
    // тень
    ctx.fillStyle = "rgba(0,0,0,.34)";
    ctx.beginPath();
    ctx.ellipse(0, 4, 34, 13, 0, 0, TAU);
    ctx.fill();

    if (unlocked) {
      const pulse = 0.5 + Math.sin(game.time * 2 + pad.id) * 0.12;
      ctx.fillStyle = tower ? "rgba(12,16,22,.5)" : `rgba(217,187,130,${0.06 + pulse * 0.04})`;
      ctx.beginPath();
      ctx.ellipse(0, 0, 32, 12.5, 0, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = active || isHover ? "rgba(240,215,162,.95)" : tower ? hexA(color, 0.55) : "rgba(217,187,130,.44)";
      ctx.lineWidth = active ? 2 : 1.2;
      ctx.beginPath();
      ctx.ellipse(0, 0, 32, 12.5, 0, 0, TAU);
      ctx.stroke();
      if (!tower) {
        ctx.strokeStyle = `rgba(217,187,130,${0.25 + pulse * 0.25})`;
        ctx.beginPath();
        ctx.arc(0, 0, 20 + pulse * 5, 0, TAU);
        ctx.stroke();
        ctx.strokeStyle = "rgba(240,215,162,.7)";
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(-5, 0); ctx.lineTo(5, 0);
        ctx.moveTo(0, -5); ctx.lineTo(0, 5);
        ctx.stroke();
      }
    } else {
      ctx.fillStyle = "rgba(8,11,16,.45)";
      ctx.beginPath();
      ctx.ellipse(0, 0, 30, 12, 0, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = "rgba(236,227,211,.18)";
      ctx.setLineDash([3, 4]);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = "rgba(236,227,211,.36)";
      ctx.font = `700 8px ${UI_FONT}`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(`ВОЛНА ${pad.unlockWave}`, 0, 0);
    }
    if (game.selectedPad === pad.id && tower) {
      ctx.strokeStyle = "rgba(240,215,162,.28)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.ellipse(0, 0, 42, 19, 0, 0, TAU);
      ctx.stroke();
    }
    ctx.restore();
  }
}

function drawProps(ctx: CanvasRenderingContext2D, game: Game) {
  for (const spot of game.map.props) {
    const prop = game.props.find((item) => item.spot === spot.id);
    ctx.save();
    ctx.translate(spot.x, spot.y);
    ctx.fillStyle = "rgba(0,0,0,.28)";
    ctx.beginPath();
    ctx.ellipse(0, 6, 20, 7, 0, 0, TAU);
    ctx.fill();
    if (!prop) {
      ctx.strokeStyle = "rgba(147,170,160,.3)";
      ctx.setLineDash([2, 4]);
      ctx.beginPath();
      ctx.arc(0, -2, 11, 0, TAU);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = "rgba(147,170,160,.5)";
      ctx.font = `700 10px ${UI_FONT}`;
      ctx.textAlign = "center";
      ctx.fillText("+", 0, 2);
    } else {
      if (prop.type === "sofa") {
        ctx.fillStyle = "#7c5c4d";
        roundRect(ctx, -18, -12, 36, 15, 3); ctx.fill();
        ctx.fillStyle = "#93705c";
        roundRect(ctx, -16, -20, 32, 10, 3); ctx.fill();
      } else if (prop.type === "dumpster") {
        ctx.fillStyle = "#4e6a60";
        roundRect(ctx, -14, -17, 28, 21, 2); ctx.fill();
        ctx.fillStyle = "#6b8b7d";
        roundRect(ctx, -16, -21, 32, 5, 2); ctx.fill();
      } else if (prop.type === "car") {
        ctx.fillStyle = "#6c5d5c";
        roundRect(ctx, -20, -14, 40, 16, 4); ctx.fill();
        ctx.fillStyle = "#8b7b76";
        roundRect(ctx, -12, -20, 24, 9, 3); ctx.fill();
        ctx.fillStyle = "#d9bb82";
        ctx.fillRect(-16, -8, 5, 3);
        ctx.fillRect(11, -8, 5, 3);
      } else {
        ctx.strokeStyle = "#9b8b76";
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.moveTo(-17, -14); ctx.lineTo(-17, 6);
        ctx.moveTo(17, -14); ctx.lineTo(17, 6);
        ctx.moveTo(-17, -12); ctx.lineTo(17, -7);
        ctx.moveTo(-17, -7); ctx.lineTo(17, -12);
        ctx.stroke();
        ctx.fillStyle = "#b9a98f";
        ctx.fillRect(-9, -10, 6, 9);
        ctx.fillRect(4, -10, 6, 9);
      }
      bar(ctx, 0, 12, 32, prop.hp / prop.maxHp, "#9cb8a4", 2.5);
    }
    ctx.restore();
  }
}

function drawEffects(ctx: CanvasRenderingContext2D, game: Game) {
  for (const effect of game.effects) {
    const progress = Math.max(0, Math.min(1, effect.life));
    if (effect.kind === "cat") {
      const gradient = ctx.createRadialGradient(effect.x, effect.y, 8, effect.x, effect.y, effect.radius);
      gradient.addColorStop(0, "rgba(214,189,108,.2)");
      gradient.addColorStop(0.7, "rgba(214,189,108,.06)");
      gradient.addColorStop(1, "rgba(214,189,108,0)");
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(effect.x, effect.y, effect.radius, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = "rgba(214,189,108,.4)";
      ctx.setLineDash([4, 6]);
      ctx.beginPath();
      ctx.arc(effect.x, effect.y, effect.radius, 0, TAU);
      ctx.stroke();
      ctx.setLineDash([]);
    } else {
      const radius = effect.radius * (1.12 - progress * 0.28);
      ctx.strokeStyle = effect.kind === "bucket" ? `rgba(145,181,198,${progress * 0.7})` : `rgba(193,155,208,${progress * 0.8})`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(effect.x, effect.y, radius, 0, TAU);
      ctx.stroke();
    }
  }
  for (const ring of game.particles.filter((particle) => particle.kind === "ring")) {
    const alpha = Math.max(0, ring.life / ring.maxLife);
    ctx.strokeStyle = hexA(ring.color, alpha * 0.55);
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(ring.x, ring.y, Math.max(4, ring.size), 0, TAU);
    ctx.stroke();
  }
}

function drawSelection(ctx: CanvasRenderingContext2D, game: Game) {
  const tower = game.selectedTower ?? null;
  if (!tower) return;
  const point = game.padPos(tower.pad);
  const range = game.towerStats(tower).range;
  ctx.save();
  const gradient = ctx.createRadialGradient(point.x, point.y, range * 0.3, point.x, point.y, range);
  gradient.addColorStop(0, hexA(TOWERS[tower.type].color, 0.08));
  gradient.addColorStop(1, hexA(TOWERS[tower.type].color, 0));
  ctx.fillStyle = gradient;
  ctx.beginPath();
  ctx.arc(point.x, point.y, range, 0, TAU);
  ctx.fill();
  ctx.strokeStyle = hexA(TOWERS[tower.type].color, 0.55);
  ctx.setLineDash([4, 6]);
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.arc(point.x, point.y, range, 0, TAU);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.restore();
}

function drawTower(ctx: CanvasRenderingContext2D, game: Game, tower: Tower) {
  const point = game.padPos(tower.pad);
  const def = TOWERS[tower.type];
  const disabled = tower.disabledUntil > game.time;
  const image = IMG[tower.type];
  const height = tower.type === "kiosk" ? 94 : tower.type === "cat" ? 76 : 112;
  ctx.save();
  ctx.fillStyle = "rgba(0,0,0,.36)";
  ctx.beginPath();
  ctx.ellipse(point.x, point.y + 2, 26, 9, 0, 0, TAU);
  ctx.fill();
  ctx.globalAlpha = disabled ? 0.45 : 1;
  drawImage(ctx, image, point.x, point.y + 3 - Math.abs(Math.sin(game.time * 2.2 + tower.pad)) * 1.2, height);
  ctx.globalAlpha = 1;

  // аура и уровень
  const color = def.color;
  ctx.strokeStyle = disabled ? "rgba(226,138,114,.8)" : hexA(color, 0.46);
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.ellipse(point.x, point.y, 27, 10, 0, 0, TAU);
  ctx.stroke();
  for (let i = 0; i < tower.level; i++) {
    ctx.fillStyle = color;
    ctx.fillRect(point.x - (tower.level * 5) / 2 + i * 5, point.y + 13, 3, 2);
  }
  if (disabled) {
    ctx.fillStyle = "rgba(226,138,114,.95)";
    ctx.font = `700 8px ${UI_FONT}`;
    ctx.textAlign = "center";
    ctx.fillText("ОТКЛЮЧЕН", point.x, point.y - height - 8);
  }
  ctx.restore();
}

function drawEnemy(ctx: CanvasRenderingContext2D, game: Game, enemy: Enemy) {
  const def = ENEMIES[enemy.type];
  const point = game.enemyPos(enemy);
  const flying = def.tags.includes("flying");
  const boss = enemy.type === "boss";
  const height = boss ? 138 : enemy.type === "pigeons" ? 34 : 76 * def.scale;
  const tint = def.color;

  ctx.save();
  if (!flying) {
    ctx.fillStyle = "rgba(0,0,0,.35)";
    ctx.beginPath();
    ctx.ellipse(point.x, point.y - 1, (boss ? 30 : 15) * def.scale, (boss ? 10 : 5) * def.scale, 0, 0, TAU);
    ctx.fill();
  } else {
    ctx.fillStyle = "rgba(0,0,0,.18)";
    ctx.beginPath();
    ctx.ellipse(point.x, game.map.paths[enemy.lane] ? point.y + 16 : point.y, 12, 4, 0, 0, TAU);
    ctx.fill();
  }

  // цветной ориентир под ногами
  ctx.strokeStyle = hexA(tint, 0.5);
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.ellipse(point.x, point.y - (flying ? 4 : 0), flying ? 13 : boss ? 30 : 16, flying ? 5 : boss ? 9 : 5, 0, 0, TAU);
  ctx.stroke();

  if (enemy.type === "pigeons") {
    for (let i = 0; i < 3; i++) {
      const ox = (i - 1) * 11 + Math.sin(game.time * 5 + i) * 3;
      const oy = Math.abs(Math.sin(game.time * 7 + i * 2)) * 6;
      ctx.save();
      ctx.translate(point.x + ox, point.y - oy - i * 3);
      ctx.fillStyle = i === 1 ? "#a9b8c6" : "#8399b5";
      ctx.beginPath();
      ctx.ellipse(0, 0, 4, 7, 0.2, 0, TAU);
      ctx.fill();
      ctx.fillRect(-1, 4, 2, 3);
      ctx.strokeStyle = "#c4d1db";
      ctx.lineWidth = 1.4;
      const flap = Math.sin(game.time * 12 + i) * 5;
      ctx.beginPath();
      ctx.moveTo(-1, -3); ctx.lineTo(-8, -5 - flap);
      ctx.moveTo(1, -3); ctx.lineTo(8, -5 + flap);
      ctx.stroke();
      ctx.restore();
    }
  } else {
    const flash = enemy.flash;
    const wobble = enemy.type === "drunk" ? Math.sin(game.time * 3 + enemy.wobble) * 0.08 : 0;
    ctx.save();
    ctx.translate(point.x, point.y);
    ctx.rotate(wobble * 0.12);
    drawImage(ctx, boss ? IMG.boss : IMG.skuf, 0, 0, height + (enemy.spawnScale < 1 ? (1 - enemy.spawnScale) * 20 : 0), flash, enemy.spawnScale < 1 ? 0.45 + enemy.spawnScale * 0.55 : 1);
    ctx.restore();

    if (enemy.shield > 0) {
      ctx.strokeStyle = "rgba(126,176,202,.55)";
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.arc(point.x, point.y - height * 0.5, height * 0.42, Math.PI * 1.05, Math.PI * 1.95);
      ctx.stroke();
    }
    if (enemy.type === "helmet") {
      ctx.fillStyle = "#c7b184";
      ctx.beginPath();
      ctx.ellipse(point.x, point.y - height - 2, 10, 4, 0, Math.PI, TAU);
      ctx.fill();
    }
    if (enemy.type === "cop") {
      ctx.fillStyle = "rgba(100,133,175,.5)";
      ctx.fillRect(point.x - 17, point.y - height * 0.62, 4, height * 0.4);
    }
    if (enemy.type === "loudmouth") {
      ctx.fillStyle = "rgba(165,120,176,.5)";
      ctx.beginPath();
      ctx.arc(point.x, point.y - height - 8, 4 + Math.sin(game.time * 5) * 1.5, 0, TAU);
      ctx.fill();
    }
  }

  const showBar = boss || enemy.hp < enemy.maxHp || enemy.shield > 0;
  if (showBar) {
    const width = boss ? 82 : 30 * def.scale;
    const ratio = enemy.hp / enemy.maxHp;
    bar(ctx, point.x, point.y - height - 10, width, ratio, ratio < 0.3 ? "#c46666" : ratio < 0.65 ? "#d5a869" : "#a7b39b", boss ? 4 : 2.5);
    if (enemy.shield > 0) bar(ctx, point.x, point.y - height - 6, width, enemy.shield / enemy.maxShield, "#7eb0ca", 1.6);
    if (boss) {
      ctx.fillStyle = "rgba(242,236,223,.8)";
      ctx.font = `700 7px ${UI_FONT}`;
      ctx.textAlign = "center";
      ctx.fillText(`УПРАВДОМ · ${Math.ceil(ratio * 100)}%`, point.x, point.y - height - 15);
    }
  }
  const statuses: string[] = [];
  if (enemy.stunUntil > game.time) statuses.push("✦");
  else if (enemy.heldUntil > game.time) statuses.push("◆");
  if (enemy.slowUntil > game.time) statuses.push("≈");
  if (statuses.length) {
    ctx.fillStyle = "rgba(224,208,170,.85)";
    ctx.font = `700 9px ${UI_FONT}`;
    ctx.textAlign = "left";
    ctx.fillText(statuses.join(" "), point.x + (boss ? 34 : 14), point.y - height * 0.62);
  }
  ctx.restore();
}

function drawHero(ctx: CanvasRenderingContext2D, game: Game) {
  const hero = game.map.hero;
  ctx.save();
  const glow = ctx.createRadialGradient(hero.x, hero.y - 24, 8, hero.x, hero.y - 24, 92);
  glow.addColorStop(0, "rgba(217, 160, 179, .2)");
  glow.addColorStop(1, "rgba(217, 160, 179, 0)");
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.arc(hero.x, hero.y - 24, 92, 0, TAU);
  ctx.fill();
  ctx.fillStyle = "rgba(0,0,0,.42)";
  ctx.beginPath();
  ctx.ellipse(hero.x, hero.y + 3, 34, 10, 0, 0, TAU);
  ctx.fill();
  drawImage(ctx, IMG.altushka, hero.x, hero.y + 4, 212, game.heroRecoil * 0.5);
  ctx.fillStyle = "rgba(217,187,130,.7)";
  ctx.fillRect(hero.x - 24, hero.y + 13, 48, 1);
  ctx.fillStyle = "rgba(242,236,223,.8)";
  ctx.font = `600 9px ${SERIF_FONT}`;
  ctx.textAlign = "center";
  ctx.fillText("АЛЬТУШКА", hero.x, hero.y + 26);
  ctx.restore();
}

function drawProjectiles(ctx: CanvasRenderingContext2D, game: Game) {
  for (const projectile of game.projectiles) {
    if (projectile.life <= 0) continue;
    ctx.save();
    const gradient = ctx.createLinearGradient(projectile.from.x, projectile.from.y, projectile.to.x, projectile.to.y);
    gradient.addColorStop(0, hexA(projectile.color, 0));
    gradient.addColorStop(1, hexA(projectile.color, 0.6));
    ctx.strokeStyle = gradient;
    ctx.lineWidth = projectile.type === "heavy" ? 3 : 1.6;
    ctx.beginPath();
    ctx.moveTo(projectile.from.x, projectile.from.y);
    ctx.lineTo(projectile.to.x, projectile.to.y);
    ctx.stroke();
    ctx.fillStyle = projectile.color;
    ctx.beginPath();
    ctx.arc(projectile.from.x, projectile.from.y, projectile.type === "heavy" ? 3.4 : 2.2, 0, TAU);
    ctx.fill();
    ctx.restore();
  }
}

function drawParticles(ctx: CanvasRenderingContext2D, game: Game) {
  for (const particle of game.particles) {
    if (particle.kind === "ring") continue;
    const alpha = Math.max(0, Math.min(1, particle.life / particle.maxLife));
    ctx.save();
    ctx.globalAlpha = alpha;
    if (particle.kind === "text" || particle.kind === "coin") {
      ctx.fillStyle = particle.color;
      ctx.font = `700 ${particle.kind === "coin" ? 10 : 9}px ${MONO_FONT}`;
      ctx.textAlign = "center";
      ctx.fillText(particle.text ?? "", particle.x, particle.y);
    } else {
      ctx.fillStyle = particle.color;
      ctx.beginPath();
      ctx.arc(particle.x, particle.y, particle.size * alpha, 0, TAU);
      ctx.fill();
    }
    ctx.restore();
  }
}

function drawBossTelegraph(ctx: CanvasRenderingContext2D, game: Game) {
  const boss = game.enemies.find((enemy) => enemy.type === "boss" && !enemy.dead);
  if (!boss || boss.telegraph <= 0) return;
  const point = game.enemyPos(boss);
  const radius = boss.telegraphKind === "slam" ? 220 : 150;
  ctx.save();
  ctx.fillStyle = "rgba(196, 98, 98, .09)";
  ctx.beginPath();
  ctx.arc(point.x, point.y, radius, 0, TAU);
  ctx.fill();
  ctx.strokeStyle = "rgba(214, 116, 116, .6)";
  ctx.setLineDash([6, 6]);
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(point.x, point.y, radius, 0, TAU);
  ctx.stroke();
  ctx.setLineDash([]);
  const ratio = Math.min(1, boss.telegraph / 2.2);
  ctx.strokeStyle = "rgba(226, 138, 114, .85)";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(point.x, point.y, radius, -Math.PI / 2, -Math.PI / 2 + TAU * ratio);
  ctx.stroke();
  ctx.fillStyle = "rgba(236, 203, 184, .9)";
  ctx.font = `700 8px ${UI_FONT}`;
  ctx.textAlign = "center";
  ctx.fillText(boss.telegraphKind === "slam" ? "УДАР ПО БАШНЯМ" : boss.telegraphKind === "summon" ? "ВЫЗОВ КОМПАНИИ" : "КЛЮЧИ ОТ ПОДЪЕЗДА", point.x, point.y - 158);
  ctx.restore();
}

function drawTargeting(ctx: CanvasRenderingContext2D, game: Game, pointer: Vec | null) {
  if (!game.targeting) return;
  const ability = ABILITIES[game.targeting];
  const point = pointer ?? { x: LOGICAL_WIDTH / 2, y: LOGICAL_HEIGHT / 2 };
  const color = game.targeting === "bucket" ? "#91b5c6" : game.targeting === "chord" ? "#c19bd0" : "#d6bd6c";
  ctx.save();
  ctx.fillStyle = hexA(color, 0.11);
  ctx.beginPath();
  ctx.arc(point.x, point.y, ability.radius, 0, TAU);
  ctx.fill();
  ctx.strokeStyle = hexA(color, 0.7);
  ctx.setLineDash([5, 6]);
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.arc(point.x, point.y, ability.radius, 0, TAU);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.strokeStyle = hexA(color, 0.8);
  ctx.beginPath();
  ctx.moveTo(point.x - 9, point.y); ctx.lineTo(point.x + 9, point.y);
  ctx.moveTo(point.x, point.y - 9); ctx.lineTo(point.x, point.y + 9);
  ctx.stroke();
  ctx.fillStyle = color;
  ctx.font = `700 9px ${UI_FONT}`;
  ctx.textAlign = "center";
  ctx.fillText(ability.name.toUpperCase(), point.x, point.y - ability.radius - 10);
  ctx.restore();
}

function drawHover(ctx: CanvasRenderingContext2D, game: Game, hover: number | null) {
  if (hover === null) return;
  const pad = game.map.pads.find((item) => item.id === hover);
  if (!pad) return;
  const tower = game.towers.find((item) => item.pad === pad.id);
  const unlocked = game.unlockedPads.includes(pad.id);
  const label = tower ? `${TOWERS[tower.type].name} · ур. ${tower.level}` : unlocked ? "Свободная площадка" : `Закрыта · волна ${pad.unlockWave} · ${pad.unlockCost} монет`;
  ctx.save();
  ctx.font = `600 8px ${UI_FONT}`;
  const width = ctx.measureText(label).width + 16;
  const x = Math.min(LOGICAL_WIDTH - width / 2 - 6, Math.max(width / 2 + 6, pad.x));
  const y = Math.max(22, pad.y - 48);
  roundRect(ctx, x - width / 2, y - 11, width, 18, 2);
  ctx.fillStyle = "rgba(10,13,18,.9)";
  ctx.fill();
  ctx.strokeStyle = "rgba(217,187,130,.33)";
  ctx.lineWidth = 0.8;
  ctx.stroke();
  ctx.fillStyle = "rgba(242,236,223,.9)";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(label, x, y - 2);
  ctx.restore();
}

function drawFrame(ctx: CanvasRenderingContext2D, game: Game) {
  // Рамка поля: тонкая внутренняя линия и координатные метки.
  ctx.strokeStyle = "rgba(217,187,130,.16)";
  ctx.lineWidth = 1;
  ctx.strokeRect(0.5, 0.5, LOGICAL_WIDTH - 1, LOGICAL_HEIGHT - 1);
  ctx.fillStyle = "rgba(242,236,223,.24)";
  ctx.font = `700 7px ${MONO_FONT}`;
  ctx.textAlign = "left";
  ctx.fillText(`СЕКТОР ${game.map.difficulty.toUpperCase()} · ${game.map.name.toUpperCase()}`, 14, LOGICAL_HEIGHT - 14);
  ctx.textAlign = "right";
  ctx.fillText(`ВОЛНА ${Math.max(1, game.wave)} / 20`, LOGICAL_WIDTH - 14, LOGICAL_HEIGHT - 14);
}
