import { useEffect, useState } from "react";
import {
  ArrowRight, BookOpen, Map, Music2, Pause, Play, Settings as SettingsIcon,
  Star, Volume2, VolumeX,
} from "lucide-react";
import { audio } from "../audio/director";
import { cn } from "../utils/cn";

export type Screen = "menu" | "maps" | "codex" | "settings" | "game";

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <span className="brand">
      <span className="brand-mark" aria-hidden="true">А</span>
      {!compact && (
        <span className="brand-text">
          <span className="brand-title">Альтушка</span>
          <span className="brand-sub">Ночной двор · tower defense</span>
        </span>
      )}
    </span>
  );
}

export function Stars({ value, max = 3, size = 12 }: { value: number; max?: number; size?: number }) {
  return (
    <span className="stars" aria-label={`${value} из ${max} звёзд`}>
      {Array.from({ length: max }, (_, i) => (
        <Star key={i} size={size} strokeWidth={1.6} className={i < value ? "on" : ""} />
      ))}
    </span>
  );
}

export function SoundToggle({ className }: { className?: string }) {
  const [on, setOn] = useState(audio.settings.music || audio.settings.sfx);
  const toggle = () => {
    const next = !on;
    setOn(next);
    audio.unlock();
    audio.set("music", next);
    audio.set("sfx", next);
    if (next) audio.click();
  };
  return (
    <button className={cn("icon-button", className)} onClick={toggle} title={on ? "Выключить звук" : "Включить звук"} aria-label={on ? "Выключить звук" : "Включить звук"}>
      {on ? <Volume2 size={16} /> : <VolumeX size={16} />}
    </button>
  );
}

export function TopNav({
  screen, onNavigate, stars, transparent = false,
}: {
  screen: Screen;
  onNavigate: (screen: Screen) => void;
  stars: number;
  transparent?: boolean;
}) {
  const links: { id: Screen; label: string; icon: typeof Map }[] = [
    { id: "menu", label: "Двор", icon: Map },
    { id: "maps", label: "Локации", icon: Map },
    { id: "codex", label: "Справочник", icon: BookOpen },
    { id: "settings", label: "Звук и настройки", icon: SettingsIcon },
  ];
  return (
    <header className="topnav" style={transparent ? { background: "rgba(9,12,17,.35)", position: "absolute", left: 0, right: 0, borderBottomColor: "rgba(236,227,211,.07)" } : undefined}>
      <div className="shell topnav-inner">
        <button className="brand" onClick={() => onNavigate("menu")} aria-label="Альтушка — на главную">
          <Logo />
        </button>
        <nav className="nav-links" aria-label="Основная навигация">
          {links.map((link) => (
            <button
              key={link.id}
              className={cn("nav-link", screen === link.id && "active")}
              onClick={() => { audio.click(); onNavigate(link.id); }}
            >
              {link.label}
            </button>
          ))}
        </nav>
        <div className="nav-right">
          <span className="stars-chip" title="Собрано звёзд">
            <Star size={12} className="on" fill="currentColor" />
            <span className="mono">{stars}</span>
            <span className="tiny" style={{ letterSpacing: ".08em" }}>/ 9</span>
          </span>
          <SoundToggle />
          <button className="btn btn-primary btn-sm" onClick={() => { audio.unlock(); audio.click(); onNavigate("maps"); }}>
            <Play size={13} fill="currentColor" /> Играть
          </button>
        </div>
      </div>
    </header>
  );
}

export function NowPlaying({ compact = false }: { compact?: boolean }) {
  const [track, setTrack] = useState(audio.current);
  const [playing, setPlaying] = useState(audio.settings.music);
  useEffect(() => audio.subscribe(setTrack), []);
  const toggle = () => {
    audio.unlock();
    const next = !playing;
    setPlaying(next);
    audio.set("music", next);
    if (!next) audio.stopMusic();
    else if (audio.current) audio.playTrack(audio.current.id);
  };
  return (
    <div className={cn("now-playing", compact && "py-2")}>
      <div className="eq" aria-hidden="true">
        {playing ? <><span /><span /><span /><span /></> : <Music2 size={15} color="#8a8479" />}
      </div>
      <div className="now-playing-copy">
        <div className="now-playing-title">{track?.title ?? "Ноктюрн двора"}</div>
        <div className="now-playing-sub">{track ? `${track.artist} · ${track.mood}` : "Живой саундтрек · включите звук"}</div>
      </div>
      <button className="icon-button sm" onClick={toggle} aria-label={playing ? "Пауза" : "Включить музыку"}>
        {playing ? <Pause size={13} /> : <Play size={13} fill="currentColor" />}
      </button>
    </div>
  );
}

export function BackButton({ onClick, label = "Назад" }: { onClick: () => void; label?: string }) {
  return (
    <button className="btn btn-quiet btn-sm" onClick={onClick} style={{ paddingLeft: 0 }}>
      <ArrowRight size={13} style={{ transform: "rotate(180deg)" }} /> {label}
    </button>
  );
}

export function SectionHeading({
  eyebrow, title, description, action,
}: {
  eyebrow: string; title: string; description?: string; action?: React.ReactNode;
}) {
  return (
    <div className="section-head">
      <div>
        <p className="eyebrow" style={{ marginBottom: 12 }}>{eyebrow}</p>
        <h2 className="display h2">{title}</h2>
        {description && <p className="lead" style={{ marginTop: 12 }}>{description}</p>}
      </div>
      {action}
    </div>
  );
}
