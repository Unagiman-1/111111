import { useCallback, useEffect, useState } from "react";
import { audio } from "./audio/director";
import { TopNav, type Screen } from "./components/ui";
import { MenuScreen } from "./screens/MenuScreen";
import { MapsScreen } from "./screens/MapsScreen";
import { CodexScreen } from "./screens/CodexScreen";
import { SettingsScreen } from "./screens/SettingsScreen";
import { GameScreen, type GameResult } from "./screens/GameScreen";
import { loadProgress, recordResult, saveProgress, totalStars, type Progress } from "./game/progress";
import type { GameMode } from "./game/types";
import { mapById } from "./game/data";

export default function App() {
  const [screen, setScreen] = useState<Screen>("menu");
  const [progress, setProgress] = useState<Progress>(() => loadProgress());
  const [session, setSession] = useState(0);
  const [config, setConfig] = useState<{ mapId: string; mode: GameMode }>({ mapId: "yard", mode: "campaign" });
  const stars = totalStars(progress);

  useEffect(() => {
    const unlock = () => { audio.unlock(); audio.preloadSfx(); };
    window.addEventListener("pointerdown", unlock, { once: true });
    window.addEventListener("keydown", unlock, { once: true });
    return () => {
      window.removeEventListener("pointerdown", unlock);
      window.removeEventListener("keydown", unlock);
    };
  }, []);

  useEffect(() => {
    if (screen !== "game") audio.setScene("menu");
  }, [screen]);

  const navigate = useCallback((next: Screen) => {
    audio.unlock();
    audio.preloadSfx();
    setScreen(next);
    window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
  }, []);

  const startGame = useCallback((mapId: string, endless: boolean) => {
    audio.unlock();
    audio.preloadSfx();
    setConfig({ mapId, mode: endless ? "endless" : "campaign" });
    setSession((value) => value + 1);
    setScreen("game");
  }, []);

  const restart = useCallback(() => {
    setSession((value) => value + 1);
    setScreen("game");
  }, []);

  const handleResult = useCallback((result: GameResult) => {
    setProgress((current) => {
      const next = recordResult(current, result.mapId, result.stars, result.wave, result.endless);
      saveProgress(next);
      return next;
    });
  }, []);

  const resetProgress = useCallback(() => {
    const empty: Progress = {};
    saveProgress(empty);
    setProgress(empty);
    try {
      localStorage.removeItem("altushka-td-intro");
    } catch { /* noop */ }
  }, []);

  if (screen === "game") {
    return (
      <GameScreen
        key={`${config.mapId}-${config.mode}-${session}`}
        mapId={config.mapId}
        mode={config.mode}
        onExit={() => navigate("maps")}
        onRestart={restart}
        onResult={handleResult}
      />
    );
  }

  return (
    <div className="screen">
      <div className="app-bg" />
      <TopNav screen={screen} stars={stars} onNavigate={navigate} />
      {screen === "menu" && (
        <MenuScreen
          progress={progress}
          onPlay={() => navigate("maps")}
          onNavigate={(next) => navigate(next)}
          onSelectMap={(id) => {
            const map = mapById(id);
            try { localStorage.setItem("altushka-td-last-map", map.id); } catch { /* noop */ }
            startGame(map.id, false);
          }}
        />
      )}
      {screen === "maps" && (
        <MapsScreen progress={progress} onStart={startGame} onBack={() => navigate("menu")} />
      )}
      {screen === "codex" && <CodexScreen onBack={() => navigate("menu")} />}
      {screen === "settings" && (
        <SettingsScreen progress={progress} onBack={() => navigate("menu")} onResetProgress={resetProgress} />
      )}
    </div>
  );
}
