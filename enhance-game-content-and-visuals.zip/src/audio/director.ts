/**
 * Аудиорежиссёр «Альтушки».
 * Музыка и фоновые атмосферы стримятся из интернета (archive.org),
 * короткие эффекты — из открытой библиотеки Google Sounds.
 * Если сеть недоступна, включается тихий процедурный ноктюрн.
 */

export interface Track {
  id: string;
  title: string;
  artist: string;
  mood: string;
  src: string;
  page: string;
  license: string;
}

export const TRACKS: Track[] = [
  {
    id: "hidden", title: "Hidden Agenda", artist: "Kevin MacLeod", mood: "Нуар · главное меню",
    src: "https://archive.org/download/kevin-macleod-ha/Kevin%20MacLeod%20-%20Hidden%20Agenda.mp3",
    page: "https://archive.org/details/kevin-macleod-ha", license: "CC BY-ND 4.0",
  },
  {
    id: "coldfunk", title: "Cold Funk", artist: "Kevin MacLeod", mood: "Фанк · южный двор",
    src: "https://archive.org/download/cold-funk-by-kevin-macleod/cold-funk-by-kevin-macleod.mp3",
    page: "https://archive.org/details/cold-funk-by-kevin-macleod", license: "CC BY-ND 4.0",
  },
  {
    id: "gothic", title: "Southern Gothic", artist: "Kevin MacLeod", mood: "Готика · арка и босс",
    src: "https://archive.org/download/southern-20-gothic/Southern%2520Gothic.mp3",
    page: "https://archive.org/details/southern-20-gothic", license: "CC BY-ND 4.0",
  },
  {
    id: "hypno", title: "Hypnothis", artist: "Kevin MacLeod", mood: "Транс · котельная",
    src: "https://archive.org/download/hypno-this-by-kevin-macleod/Hypnothis.mp3",
    page: "https://archive.org/details/hypno-this-by-kevin-macleod", license: "CC0 1.0",
  },
];

export const AMBIENCES = [
  { id: "none", title: "Тишина", src: "" },
  { id: "night", title: "Ночной двор", src: "https://actions.google.com/sounds/v1/ambiences/outside_night.ogg" },
  { id: "factory", title: "Гул теплопункта", src: "https://actions.google.com/sounds/v1/ambiences/factory_background.ogg" },
];

const SFX_BASE = "https://actions.google.com/sounds/v1/";
const SFX_SOURCES: Record<string, { src: string; volume: number; rate?: number }> = {
  shot: { src: "cartoon/pop.ogg", volume: 0.15, rate: 1.55 },
  heavy: { src: "impacts/body_punch_series.ogg", volume: 0.3, rate: 0.85 },
  speaker: { src: "science_fiction/sci_fi_vortex.ogg", volume: 0.16, rate: 1.35 },
  hero: { src: "science_fiction/alien_beam.ogg", volume: 0.14, rate: 1.7 },
  coin: { src: "sports/ping_pong_ball_hit.ogg", volume: 0.22, rate: 1.5 },
  build: { src: "tools/hammer_on_cement.ogg", volume: 0.35, rate: 1 },
  upgrade: { src: "alarms/dinner_bell_triangle.ogg", volume: 0.3, rate: 1.1 },
  ability: { src: "science_fiction/sci_fi_vortex.ogg", volume: 0.4, rate: 1 },
  boss: { src: "crowds/battle_intimidation_forest.ogg", volume: 0.42, rate: 0.9 },
  bossDown: { src: "crowds/battle_crowd_celebration.ogg", volume: 0.4, rate: 1 },
  leak: { src: "alarms/beep_short.ogg", volume: 0.4, rate: 0.8 },
  deny: { src: "impacts/dumpster.ogg", volume: 0.35, rate: 1.1 },
  wave: { src: "alarms/bugle_tune.ogg", volume: 0.25, rate: 1 },
  click: { src: "office/button_push.ogg", volume: 0.24, rate: 1 },
  victory: { src: "crowds/battle_crowd_celebration.ogg", volume: 0.45, rate: 1 },
};

type Settings = {
  music: boolean;
  sfx: boolean;
  ambient: boolean;
  musicVolume: number;
  sfxVolume: number;
  ambientVolume: number;
  favouriteTrack: string | null;
};

const STORAGE = "altushka-td-audio-v1";
const DEFAULTS: Settings = {
  music: true, sfx: true, ambient: false,
  musicVolume: 0.55, sfxVolume: 0.7, ambientVolume: 0.22,
  favouriteTrack: null,
};

class AudioDirector {
  settings: Settings = DEFAULTS;
  current: Track | null = null;
  private listeners = new Set<(track: Track | null) => void>();
  private musicEl: HTMLAudioElement | null = null;
  private ambientEl: HTMLAudioElement | null = null;
  private requestedTrack: string | null = null;
  private ambientId = "none";
  private unlocked = false;
  private synth: { ctx: AudioContext; timer: number } | null = null;
  private pools = new Map<string, HTMLAudioElement[]>();
  private last: Record<string, number> = {};
  private explicit = false;

  constructor() {
    if (typeof window === "undefined") return;
    try {
      const raw = localStorage.getItem(STORAGE);
      if (raw) this.settings = { ...DEFAULTS, ...JSON.parse(raw) };
    } catch { /* тихо: настройки не критичны */ }
  }

  private save() {
    try { localStorage.setItem(STORAGE, JSON.stringify(this.settings)); } catch { /* noop */ }
  }

  subscribe(fn: (track: Track | null) => void) {
    this.listeners.add(fn);
    fn(this.current);
    return () => { this.listeners.delete(fn); };
  }

  private emit() { for (const fn of this.listeners) fn(this.current); }

  /** Вызывается после первого действия пользователя — снимает автоблокировку браузера. */
  unlock() {
    this.unlocked = true;
    if (this.settings.music && this.requestedTrack && this.musicEl?.paused) this.playTrack(this.requestedTrack);
    if (this.settings.ambient) this.applyAmbient();
  }

  set<K extends keyof Settings>(key: K, value: Settings[K]) {
    this.settings[key] = value;
    this.save();
    if (key === "music") {
      if (value) { if (this.requestedTrack) this.playTrack(this.requestedTrack); }
      else this.stopMusic();
    }
    if (key === "sfx" && !value) this.stopAllSfx();
    if (key === "ambient") this.applyAmbient();
    if (key === "musicVolume" && this.musicEl) this.musicEl.volume = this.settings.musicVolume;
    if (key === "ambientVolume" && this.ambientEl) this.ambientEl.volume = this.settings.ambientVolume;
  }

  preloadSfx() {
    for (const name of Object.keys(SFX_SOURCES)) {
      if (this.pools.has(name)) continue;
      const pool: HTMLAudioElement[] = [];
      for (let i = 0; i < 3; i++) {
        const el = new Audio(SFX_BASE + SFX_SOURCES[name].src);
        el.preload = "auto";
        el.volume = 0;
        pool.push(el);
      }
      this.pools.set(name, pool);
    }
  }

  private ensureMusic() {
    if (this.musicEl) return this.musicEl;
    const el = new Audio();
    el.loop = true;
    el.preload = "auto";
    el.volume = this.settings.musicVolume;
    el.addEventListener("error", () => {
      if (!this.settings.music || !this.requestedTrack) return;
      if (this.current) this.startSynthNocturne();
    });
    this.musicEl = el;
    return el;
  }

  playTrack(id: string, explicit = false) {
    if (explicit) this.explicit = true;
    this.requestedTrack = id;
    this.settings.favouriteTrack = id;
    this.save();
    const track = TRACKS.find((t) => t.id === id);
    if (!track) return;
    if (!this.settings.music) { this.current = track; this.emit(); return; }
    const el = this.ensureMusic();
    if (el.src !== track.src) el.src = track.src;
    el.volume = this.settings.musicVolume;
    this.current = track;
    this.stopSynth();
    this.emit();
    if (!this.unlocked) return;
    el.play().catch(() => {
      if (this.current && this.settings.music) this.startSynthNocturne();
    });
  }

  stopMusic() {
    this.musicEl?.pause();
    this.stopSynth();
  }

  setFavourite(id: string | null) {
    this.settings.favouriteTrack = id;
    this.save();
    if (id) this.playTrack(id, true);
  }

  /** Автоподбор темы под экран или локацию. */
  setScene(scene: "menu" | "yard" | "arch" | "boiler" | "boss" | "result") {
    if (this.explicit && scene !== "boss") return;
    const byScene: Record<typeof scene, string> = {
      menu: "hidden", yard: "coldfunk", arch: "gothic", boiler: "hypno", boss: "gothic", result: "hidden",
    };
    const next = scene === "result" ? (this.requestedTrack ?? "hidden") : byScene[scene];
    if (this.requestedTrack !== next) this.playTrack(next);
  }

  setAmbient(id: string) {
    this.ambientId = id;
    this.applyAmbient();
  }

  private applyAmbient() {
    const data = AMBIENCES.find((a) => a.id === this.ambientId) ?? AMBIENCES[0];
    if (!this.ambientEl) {
      this.ambientEl = new Audio();
      this.ambientEl.loop = true;
      this.ambientEl.preload = "auto";
    }
    const el = this.ambientEl;
    if (!this.settings.ambient || !data.src) { el.pause(); return; }
    if (el.src !== data.src) el.src = data.src;
    el.volume = this.settings.ambientVolume;
    if (this.unlocked) el.play().catch(() => undefined);
  }

  sfx(name: string, gain = 1) {
    if (!this.settings.sfx) return;
    const data = SFX_SOURCES[name];
    if (!data) return;
    const now = performance.now();
    const gap = name === "shot" || name === "coin" ? 65 : name === "heavy" ? 90 : 25;
    if (now - (this.last[name] ?? 0) < gap) return;
    this.last[name] = now;
    const pool = this.pools.get(name);
    const el = pool?.find((item) => item.paused) ?? new Audio(SFX_BASE + data.src);
    el.volume = Math.min(1, data.volume * this.settings.sfxVolume * gain);
    el.playbackRate = data.rate ?? 1;
    try { el.currentTime = 0; } catch { /* ещё не загружен */ }
    el.play().catch(() => undefined);
  }

  /** Преобразует событие движка в звук. */
  event(name: string) {
    const map: Record<string, string> = {
      shot: "shot", heavy: "heavy", speaker: "speaker", hero: "hero", coin: "coin",
      build: "build", upgrade: "upgrade", ability: "ability", boss: "boss",
      bossDown: "bossDown", leak: "leak", deny: "deny", wave: "wave", lost: "deny",
      explode: "heavy", alarm: "deny",
    };
    const sfx = map[name];
    if (sfx) this.sfx(sfx);
  }

  click() { this.sfx("click"); }

  private startSynthNocturne() {
    if (this.synth) return;
    try {
      const Ctx = window.AudioContext ?? (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Ctx) return;
      const ctx = new Ctx();
      const master = ctx.createGain();
      master.gain.value = this.settings.music ? this.settings.musicVolume * 0.16 : 0;
      master.connect(ctx.destination);
      const notes = [110, 130.81, 146.83, 164.81, 196, 164.81, 146.83, 130.81];
      let step = 0;
      const play = () => {
        if (!this.synth) return;
        const t = ctx.currentTime;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = step % 4 === 0 ? "triangle" : "sine";
        osc.frequency.value = notes[step % notes.length] / (step % 8 === 0 ? 1 : 2);
        gain.gain.setValueAtTime(0.0001, t);
        gain.gain.exponentialRampToValueAtTime(0.9, t + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + 1.5);
        osc.connect(gain); gain.connect(master);
        osc.start(t); osc.stop(t + 1.6);
        step++;
      };
      play();
      const timer = window.setInterval(play, 1700);
      this.synth = { ctx, timer };
    } catch { /* остаёмся без музыки, но не ломаем игру */ }
  }

  private stopSynth() {
    if (!this.synth) return;
    clearInterval(this.synth.timer);
    this.synth.ctx.close().catch(() => undefined);
    this.synth = null;
  }

  private stopAllSfx() {
    for (const pool of this.pools.values()) for (const el of pool) { el.pause(); el.currentTime = 0; }
  }
}

export const audio = new AudioDirector();
export type AudioScene = Parameters<AudioDirector["setScene"]>[0];
