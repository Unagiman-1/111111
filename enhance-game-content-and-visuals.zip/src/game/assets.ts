import altushka from "../assets/units/source-altushka.webp?inline";
import girlfriend from "../assets/units/source-girlfriend.webp?inline";
import granny from "../assets/units/source-granny.webp?inline";
import cat from "../assets/units/source-cat.webp?inline";
import kiosk from "../assets/units/source-kiosk.webp?inline";
import patrol from "../assets/units/source-patrol.webp?inline";
import skuf from "../assets/units/source-skuf.webp?inline";
import boss from "../assets/units/source-boss.webp?inline";
import speaker from "../assets/units/source-speaker.webp?inline";
import yard from "../assets/locations/courtyard.jpg?inline";
import arch from "../assets/locations/arch.jpg?inline";
import boiler from "../assets/locations/boiler.jpg?inline";

export const UNIT_ART: Record<string, string> = {
  altushka, girlfriend, granny, cat, kiosk, patrol, speaker, skuf, boss,
};

export const LOCATION_ART: Record<string, string> = { yard, arch, boiler };

export const locationArt = (key: string) => LOCATION_ART[key] ?? yard;
export const unitArt = (key: string) => UNIT_ART[key] ?? skuf;

const cache = new Map<string, HTMLImageElement>();

export function imageFor(src: string): HTMLImageElement {
  let image = cache.get(src);
  if (!image) {
    image = new Image();
    image.src = src;
    cache.set(src, image);
  }
  return image;
}
