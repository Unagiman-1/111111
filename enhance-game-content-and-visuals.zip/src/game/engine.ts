import { ABILITIES, ENEMIES, LOGICAL_HEIGHT, MAPS, MAX_WAVE, PROP_DATA, TOWERS, getWave } from "./data";
import { PERKS, type PerkId } from "./perks";
import type {
  ActiveEffect, DamageType, Enemy, EnemyId, GameMode, GameStatus, MapDef, PadDef,
  Particle, Prop, PropId, Projectile, Snapshot, Tower, TowerId, Vec, WaveDef,
} from "./types";

interface SpawnItem { time: number; enemy: EnemyId; lane: number }
interface PathMetric { points: Vec[]; lengths: number[]; total: number }
export interface FadingActor { type: EnemyId; x: number; y: number; phase: number; life: number; maxLife: number }

const dist = (a: Vec, b: Vec) => Math.hypot(a.x - b.x, a.y - b.y);
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

function mulberry32(seed: number) {
  return () => {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export class Game {
  map: MapDef;
  mode: GameMode;
  seed: number;
  rng: () => number;
  fxRng: () => number;
  coins = 270;
  lives = 20;
  maxLives = 20;
  wave = 0;
  status: GameStatus = "prep";
  speed = 1;
  paused = false;
  time = 0;
  waveTime = 0;
  intermission = 0;
  waveActive = false;
  enemies: Enemy[] = [];
  towers: Tower[] = [];
  projectiles: Projectile[] = [];
  particles: Particle[] = [];
  fadingActors: FadingActor[] = [];
  props: Prop[] = [];
  effects: ActiveEffect[] = [];
  spawnQueue: SpawnItem[] = [];
  unlockedPads: number[];
  selectedPad: number | null = 0;
  selectedTowerUid: number | null = null;
  selectedPropUid: number | null = null;
  selectedSpot: number | null = null;
  pendingTower: TowerId | null = null;
  targeting: "bucket" | "chord" | "cat" | null = null;
  cooldowns = { bucket: 0, chord: 0, cat: 0 };
  notice: { text: string; sub: string; time: number } | null = null;
  events: string[] = [];
  shake = 0;
  hitStop = 0;
  score = 0;
  totalSpawned = 0;
  totalInWave = 0;
  killedWaveHp = 0;
  totalWaveHp = 0;
  fps = 60;
  heroCooldown = 0;
  heroRecoil = 0;
  nextUid = 1;
  private pathMetrics: PathMetric[];
  private neighbors = new Map<number, number[]>();
  private stolenKiosks = new Set<number>();
  private slowMotion = 0;
  perks: PerkId[] = [];
  draft: PerkId[] | null = null;

  constructor(mapId = "yard", mode: GameMode = "campaign", seed = Date.now() & 0xffffffff) {
    this.map = MAPS.find((m) => m.id === mapId) ?? MAPS[0];
    this.mode = mode;
    this.seed = seed;
    this.rng = mulberry32(seed);
    this.fxRng = mulberry32(seed ^ 0x9e3779b9);
    this.unlockedPads = this.map.pads.filter((p) => p.unlockWave === 0).map((p) => p.id);
    this.pathMetrics = this.map.paths.map((points) => {
      const lengths: number[] = [0];
      for (let i = 1; i < points.length; i++) lengths.push(lengths[i - 1] + dist(points[i - 1], points[i]));
      return { points, lengths, total: lengths[lengths.length - 1] };
    });
    for (const pad of this.map.pads) {
      const near = this.map.pads
        .filter((p) => p.id !== pad.id)
        .map((p) => ({ id: p.id, d: dist(p, pad) }))
        .sort((a, b) => a.d - b.d)
        .filter((p) => p.d < 330)
        .slice(0, 2)
        .map((p) => p.id);
      this.neighbors.set(pad.id, near);
    }
    this.say("ДВОР ПРОСЫПАЕТСЯ", "Выбери площадку и поставь первого защитника", 4.5);
  }

  get currentWave(): WaveDef { return getWave(Math.max(1, this.wave)); }
  get nextWave(): WaveDef { return getWave(this.wave + 1); }
  get selectedTower(): Tower | null { return this.towers.find((t) => t.uid === this.selectedTowerUid) ?? null; }
  get selectedProp(): Prop | null { return this.props.find((p) => p.uid === this.selectedPropUid) ?? null; }

  say(text: string, sub = "", time = 3) { this.notice = { text, sub, time }; }

  hpScale(wave = this.wave) {
    if (this.mode === "campaign" || wave <= MAX_WAVE) {
      const n = Math.max(0, wave - 1);
      return 1 + n * 0.075 + n * n * 0.0018;
    }
    const base = 1 + 19 * 0.075 + 19 * 19 * 0.0018;
    return base * Math.pow(1.055, wave - MAX_WAVE);
  }

  startWave() {
    if (this.waveActive || this.status === "won" || this.status === "lost" || this.draft) return;
    const early = this.earlyBonus;
    if (early) {
      this.coins += early;
      this.floatText(1080, 90, `+${early} досрочно`, "#e8c979");
    }
    this.wave += 1;
    this.waveActive = true;
    this.status = "wave";
    this.waveTime = 0;
    this.intermission = 0;
    this.spawnQueue = [];
    let laneCount = 0;
    for (const group of this.currentWave.groups) {
      for (let i = 0; i < group.count; i++) {
        const lane = group.lane !== undefined
          ? group.lane % this.map.paths.length
          : (laneCount++ + Math.floor(this.rng() * this.map.paths.length)) % this.map.paths.length;
        this.spawnQueue.push({ time: (group.delay ?? 0) + i * group.gap, enemy: group.enemy, lane });
      }
    }
    this.spawnQueue.sort((a, b) => a.time - b.time);
    this.totalInWave = this.spawnQueue.length;
    this.totalSpawned = 0;
    this.totalWaveHp = this.spawnQueue.reduce((sum, s) => sum + ENEMIES[s.enemy].hp * this.hpScale(), 0);
    this.killedWaveHp = 0;
    const boss = this.currentWave.groups.some((g) => g.enemy === "boss");
    this.say(`ВОЛНА ${this.wave} · ${this.currentWave.name}`, this.currentWave.tip, boss ? 4.5 : 3);
    this.events.push(boss ? "boss" : "wave");
    if (boss) this.shake = Math.max(this.shake, 0.35);
  }

  update(rawDt: number) {
    const dt = Math.min(rawDt, 0.05) * (this.slowMotion > 0 ? 0.35 : 1);
    this.slowMotion = Math.max(0, this.slowMotion - rawDt);
    this.updateParticles(rawDt);
    this.shake = Math.max(0, this.shake - rawDt * 1.8);
    this.heroRecoil = Math.max(0, this.heroRecoil - rawDt * 5);
    if (this.notice) {
      this.notice.time -= rawDt;
      if (this.notice.time <= 0) this.notice = null;
    }
    if (this.paused || this.draft || this.status === "won" || this.status === "lost") return;
    if (this.hitStop > 0) { this.hitStop -= rawDt; return; }
    this.time += dt;
    for (const key of Object.keys(this.cooldowns) as (keyof typeof this.cooldowns)[]) {
      this.cooldowns[key] = Math.max(0, this.cooldowns[key] - dt);
    }
    if (!this.waveActive && this.status === "prep" && this.wave > 0 && !this.draft) {
      this.intermission = Math.max(0, this.intermission - dt);
      if (this.intermission <= 0) this.startWave();
    }
    if (this.waveActive) {
      this.waveTime += dt;
      while (this.spawnQueue.length && this.spawnQueue[0].time <= this.waveTime) {
        const item = this.spawnQueue.shift()!;
        this.spawnEnemy(item.enemy, item.lane);
        this.totalSpawned++;
      }
    }
    this.updateProps(dt);
    this.updateEnemies(dt);
    this.updateTowers(dt);
    this.updateHero(dt);
    this.updateProjectiles(dt);
    this.updateEffects(dt);
    this.enemies = this.enemies.filter((e) => !e.dead);
    this.projectiles = this.projectiles.filter((p) => p.life > 0);
    this.effects = this.effects.filter((e) => e.life > 0);
    if (this.waveActive && this.spawnQueue.length === 0 && this.enemies.length === 0) this.completeWave();
  }

  spawnEnemy(type: EnemyId, lane: number, progress = 0, hpFactor = 1) {
    const def = ENEMIES[type];
    const hp = Math.round(def.hp * this.hpScale() * hpFactor);
    const enemy: Enemy = {
      uid: this.nextUid++, type, lane: lane % this.map.paths.length, progress,
      hp, maxHp: hp, shield: type === "cop" ? Math.round(90 * this.hpScale()) : 0,
      maxShield: type === "cop" ? Math.round(90 * this.hpScale()) : 0,
      speed: def.speed * (this.map.id === "boiler" || this.map.id === "arch" ? 1.08 : 1), slowUntil: 0, slowFactor: 1,
      stunUntil: 0, heldUntil: 0, flash: 0, dead: false, leaked: false,
      wobble: this.rng() * Math.PI * 2, phase: 1, abilityTimer: type === "boss" ? 5.5 : 0,
      telegraph: 0, telegraphKind: null, spawnScale: 0, stolen: 0, hitAgo: 99, vulnerableUntil: 0,
      walking: false,
    };
    this.enemies.push(enemy);
    return enemy;
  }

  updateEnemies(dt: number) {
    for (const e of this.enemies) {
      if (e.dead) continue;
      const def = ENEMIES[e.type];
      e.spawnScale = Math.min(1, e.spawnScale + dt * 4);
      e.flash = Math.max(0, e.flash - dt * 12);
      e.hitAgo += dt;
      const pos = this.enemyPos(e);
      if (e.type === "regen" && e.hitAgo > 2 && e.hp < e.maxHp) e.hp = Math.min(e.maxHp, e.hp + e.maxHp * 0.03 * dt);
      if (e.type === "boss") this.updateBoss(e, dt, pos);
      if (e.type === "courier" && !e.stolen) {
        const kiosk = this.towers.find((t) => t.type === "kiosk" && dist(this.padPos(t.pad), pos) < 135 && !this.stolenKiosks.has(t.uid));
        if (kiosk) {
          e.stolen = kiosk.uid;
          this.stolenKiosks.add(kiosk.uid);
          this.floatText(pos.x, pos.y - 35, "ВЫРУЧКА УКРАДЕНА", "#e28a72");
          this.events.push("leak");
        }
      }
      let movement = e.speed;
      if (e.type === "drunk") movement *= 0.78 + Math.sin(this.time * 2.7 + e.wobble) * 0.28;
      if (e.type === "scooter") movement *= 1 + Math.max(0, Math.sin(this.time * 1.8 + e.wobble)) * 0.18;
      if (e.stolen) movement *= 1.25;
      if (e.type === "boss" && e.phase === 3) movement *= 1.35;
      if (e.slowUntil > this.time) movement *= e.slowFactor;
      else e.slowFactor = 1;
      if (e.stunUntil > this.time || e.heldUntil > this.time || e.telegraph > 0) movement = 0;
      let blocked = false;
      if (!def.tags.includes("flying")) {
        for (const prop of this.props) {
          if (prop.type !== "sofa" || prop.hp <= 0) continue;
          const spot = this.map.props[prop.spot];
          if (dist(pos, spot) < 43) {
            prop.hp -= dt * (e.type === "boss" ? 65 : 20);
            blocked = true;
            if (this.fxRng() < dt * 3) this.burst(spot.x, spot.y, "#aa8d78", 2);
            break;
          }
        }
      }
      e.walking = movement > 0 && !blocked;
      if (!blocked) e.progress += movement * dt;
      const metric = this.pathMetrics[e.lane];
      if (e.progress >= metric.total) {
        e.dead = true;
        e.leaked = true;
        this.lives = Math.max(0, this.lives - def.damage);
        this.events.push("leak");
        this.shake = Math.max(this.shake, 0.28);
        this.floatText(this.map.hero.x, this.map.hero.y - 70, `−${def.damage} HP`, "#e47d7d");
        if (this.lives <= 0) this.lose();
      }
    }
  }

  updateBoss(e: Enemy, dt: number, pos: Vec) {
    const ratio = e.hp / e.maxHp;
    const nextPhase = ratio <= 0.33 ? 3 : ratio <= 0.66 ? 2 : 1;
    if (nextPhase > e.phase) {
      e.phase = nextPhase;
      e.abilityTimer = 1.5;
      e.telegraph = 0;
      this.say(nextPhase === 2 ? "ФАЗА II · ВЫЗОВ КОМПАНИИ" : "ФАЗА III · КЛЮЧИ ОТ ПОДЪЕЗДА", nextPhase === 2 ? "Управдом начнёт призывать подмогу" : "Броня ослабла, но скорость выросла", 3);
      this.shake = 0.5;
      this.events.push("boss");
    }
    if (e.telegraph > 0) {
      e.telegraph -= dt;
      if (e.telegraph <= 0) this.executeBossAbility(e, pos);
      return;
    }
    e.abilityTimer -= dt;
    if (e.abilityTimer <= 0) {
      e.telegraphKind = e.phase === 1 ? "slam" : e.phase === 2 ? (Math.floor(this.time) % 2 ? "summon" : "slam") : (Math.floor(this.time) % 2 ? "rage" : "summon");
      e.telegraph = e.telegraphKind === "slam" ? 2.2 : 1.7;
      e.abilityTimer = Math.max(4.8, 8.5 - e.phase);
      this.events.push("telegraph");
    }
  }

  executeBossAbility(e: Enemy, pos: Vec) {
    const kind = e.telegraphKind;
    e.telegraphKind = null;
    if (kind === "slam") {
      for (const t of this.towers) if (dist(this.padPos(t.pad), pos) < 220) t.disabledUntil = this.time + 3.2;
      this.ring(pos.x, pos.y, 220, "#c56666");
      this.shake = 0.75;
      this.hitStop = 0.07;
      this.events.push("explode");
    } else if (kind === "summon") {
      for (let i = 0; i < 3 + e.phase; i++) this.spawnEnemy(i % 2 ? "skuf" : "crowd", e.lane, Math.max(0, e.progress - 70 - i * 18), 0.72);
      this.ring(pos.x, pos.y, 130, "#a990ba");
      this.say("«ВСЕ СЮДА, БЫСТРО!»", "Управдом позвал компанию", 1.8);
    } else {
      for (const other of this.enemies) if (dist(this.enemyPos(other), pos) < 210) other.stunUntil = 0;
      e.slowUntil = 0;
      e.hp = Math.min(e.maxHp, e.hp + e.maxHp * 0.035);
      this.ring(pos.x, pos.y, 180, "#d19a61");
      this.events.push("boss");
    }
  }

  updateTowers(dt: number) {
    for (const t of this.towers) {
      const def = TOWERS[t.type];
      t.recoil = Math.max(0, t.recoil - dt * 7);
      if (t.disabledUntil > this.time) continue;
      if (t.type === "kiosk" && !this.waveActive && this.wave === 0) { t.cooldown = 8; continue; }
      t.cooldown -= dt;
      if (t.type === "kiosk") {
        if (t.cooldown <= 0) {
          t.cooldown += 8;
          if (this.stolenKiosks.has(t.uid)) {
            this.stolenKiosks.delete(t.uid);
            this.floatText(this.padPos(t.pad).x, this.padPos(t.pad).y - 40, "НЕТ ВЫРУЧКИ", "#b67a75");
          } else {
            let payout = 10;
            if (t.branch === 1) payout = 14;
            if (t.branch === 0 && t.level === 4) payout = 16;
            if (this.perks.includes("kiosk")) payout += 3;
            payout = Math.round(payout * (1 + (t.level - 1) * 0.12));
            this.coins += payout;
            t.invested += 0;
            this.floatText(this.padPos(t.pad).x, this.padPos(t.pad).y - 38, `+${payout}`, "#e5c66f", "coin");
            this.events.push("coin");
            const buff = t.branch === 0 ? 1.45 : t.branch === 1 ? 1.18 : 1.3;
            for (const other of this.towers) {
              if (other.type !== "kiosk" && this.areNeighbors(t.pad, other.pad)) {
                other.buffUntil = this.time + 6;
                (other as Tower & { buffAmount?: number }).buffAmount = buff;
              }
            }
          }
        }
        continue;
      }
      if (t.cooldown > 0) continue;
      const target = this.findTarget(t);
      if (!target) { t.cooldown = Math.max(t.cooldown, -0.15); continue; }
      const stats = this.towerStats(t);
      t.cooldown = 1 / stats.rate;
      t.recoil = 1;
      t.facing = this.enemyPos(target).x < this.padPos(t.pad).x ? -1 : 1;
      t.shots++;
      if (t.type === "speaker") {
        const targets = this.enemies.filter((e) => !e.dead && dist(this.enemyPos(e), this.padPos(t.pad)) <= stats.range && (def.canAir || !ENEMIES[e.type].tags.includes("flying")));
        for (const e of targets) {
          this.applyHit(t, e, stats.damage, "control", 0, false);
          const slow = t.branch === 0 ? 0.42 : 0.58;
          if (e.slowUntil <= this.time || slow < e.slowFactor) e.slowFactor = slow;
          e.slowUntil = this.time + 2.4;
          if (t.branch === 0 && t.level === 4) e.stunUntil = Math.max(e.stunUntil, this.time + 0.25);
        }
        this.ring(this.padPos(t.pad).x, this.padPos(t.pad).y, stats.range, def.color);
        this.events.push("speaker");
      } else {
        this.projectiles.push({
          uid: this.nextUid++, from: { x: this.padPos(t.pad).x, y: this.padPos(t.pad).y - 45 }, to: this.enemyPos(target), targetUid: target.uid,
          towerUid: t.uid, damage: stats.damage, type: def.damageType, speed: t.type === "granny" ? 390 : 590,
          life: 3, color: def.color, aoe: this.projectileAoe(t), crit: false,
        });
        if (t.type === "cat" && t.branch === 1 && t.shots % 3 === 0) {
          const second = this.enemies.find((e) => !e.dead && e.uid !== target.uid && dist(this.enemyPos(e), this.padPos(t.pad)) < stats.range);
          if (second) this.projectiles.push({ uid: this.nextUid++, from: { ...this.padPos(t.pad) }, to: this.enemyPos(second), targetUid: second.uid, towerUid: t.uid, damage: stats.damage * 0.8, type: "pierce", speed: 650, life: 3, color: def.color, aoe: 0, crit: false });
        }
        this.events.push(t.type === "granny" ? "heavy" : "shot");
      }
    }
  }

  towerStats(t: Tower) {
    const def = TOWERS[t.type];
    let damage = def.damage * (1 + (t.level - 1) * 0.45);
    let rate = def.rate * (1 + (t.level - 1) * 0.075);
    let range = def.range + (t.level - 1) * 7;
    if (t.type === "patrol" && t.branch === 1) range += 45;
    if (t.type === "patrol" && t.branch === 0) damage *= 1.2;
    if (t.type === "girlfriend" && t.branch === 1 && t.level === 4) rate *= 1.25;
    if (t.type === "granny" && t.branch === 1 && t.level === 4) rate *= 1.2;
    if (t.type === "cat" && t.branch === 1 && t.level === 4) rate *= 1.3;
    if (t.buffUntil > this.time) rate *= (t as Tower & { buffAmount?: number }).buffAmount ?? 1.3;
    for (const other of this.towers) {
      if (other.type === "speaker" && other.branch === 1 && this.areNeighbors(t.pad, other.pad)) rate *= other.level === 4 ? 1.2 : 1.1;
    }
    const tpos = this.padPos(t.pad);
    if (this.enemies.some((e) => e.type === "loudmouth" && !e.dead && dist(this.enemyPos(e), tpos) < 150)) rate *= 0.75;
    if (this.perks.includes("tempo") && t.type !== "kiosk") rate *= 1.08;
    if (this.perks.includes("glass") && t.type === "girlfriend") damage *= 1.2;
    if (this.perks.includes("iron") && t.type === "granny") damage *= 1.18;
    if (this.perks.includes("bass") && t.type === "speaker") damage *= 1.35;
    if (this.perks.includes("catEyes") && t.type === "cat") range += 30;
    return { damage, rate, range };
  }

  findTarget(t: Tower): Enemy | null {
    const def = TOWERS[t.type];
    const pos = this.padPos(t.pad);
    const range = this.towerStats(t).range;
    const candidates = this.enemies.filter((e) => {
      if (e.dead || (!def.canAir && ENEMIES[e.type].tags.includes("flying"))) return false;
      return dist(this.enemyPos(e), pos) <= range;
    });
    if (!candidates.length) return null;
    const metric = (e: Enemy) => e.progress / this.pathMetrics[e.lane].total;
    candidates.sort((a, b) => {
      if (t.targetMode === "first") return metric(b) - metric(a);
      if (t.targetMode === "last") return metric(a) - metric(b);
      if (t.targetMode === "strong") return (b.hp + b.shield) - (a.hp + a.shield);
      if (t.targetMode === "weak") return (a.hp + a.shield) - (b.hp + b.shield);
      return dist(this.enemyPos(a), pos) - dist(this.enemyPos(b), pos);
    });
    return candidates[0];
  }

  projectileAoe(t: Tower) {
    if (t.type === "girlfriend" && t.branch === 1) return 42;
    if (t.type === "granny" && t.branch === 1) return t.level === 4 ? 76 : 58;
    return 0;
  }

  updateProjectiles(dt: number) {
    for (const p of this.projectiles) {
      p.life -= dt;
      const target = this.enemies.find((e) => e.uid === p.targetUid && !e.dead);
      if (!target) { p.life = 0; continue; }
      p.to = this.enemyPos(target);
      const d = dist(p.from, p.to);
      const step = p.speed * dt;
      if (d <= step + 8) {
        const tower = this.towers.find((t) => t.uid === p.towerUid) ?? null;
        if (p.aoe > 0) {
          for (const e of this.enemies) if (!e.dead && dist(this.enemyPos(e), p.to) <= p.aoe) this.applyHit(tower, e, p.damage * (e.uid === target.uid ? 1 : 0.72), p.type, 0, false);
          this.ring(p.to.x, p.to.y, p.aoe, p.color);
        } else this.applyHit(tower, target, p.damage, p.type, 0, p.crit);
        if (tower?.type === "girlfriend" && tower.branch === 0 && tower.level === 4) {
          const second = this.enemies.find((e) => !e.dead && e.uid !== target.uid && dist(this.enemyPos(e), p.to) < 100);
          if (second) this.applyHit(tower, second, p.damage * 0.55, p.type, 0, false);
        }
        this.burst(p.to.x, p.to.y, p.color, p.type === "heavy" ? 7 : 4);
        p.life = 0;
      } else {
        p.from.x += ((p.to.x - p.from.x) / d) * step;
        p.from.y += ((p.to.y - p.from.y) / d) * step;
      }
    }
  }

  applyHit(tower: Tower | null, e: Enemy, amount: number, type: DamageType, _aoe = 0, forcedCrit = false) {
    if (e.dead) return;
    const def = ENEMIES[e.type];
    let damage = amount;
    let crit = forcedCrit;
    if (tower) {
      if (tower.type === "girlfriend" && tower.branch === 0 && this.rng() < 0.25) { damage *= 2; crit = true; }
      if (tower.type === "cat" && tower.branch === 0 && e.hp >= e.maxHp * 0.98) damage *= 1.35;
      if (tower.type === "cat" && e.heldUntil > this.time && this.hasLink(tower, "patrol")) { damage *= this.perks.includes("neighbors") ? 2.25 : 2; crit = true; }
      if (tower.type === "granny" && e.slowUntil > this.time && this.hasLink(tower, "speaker")) damage *= this.perks.includes("neighbors") ? 1.65 : 1.5;
      if (tower.type === "granny" && tower.branch === 0 && (def.tags.includes("armor") || def.tags.includes("shield"))) damage *= 1.3;
      if (tower.type === "patrol" && tower.branch === 1 && def.tags.includes("flying")) damage *= 1.5;
      if (tower.type === "patrol") {
        e.heldUntil = Math.max(e.heldUntil, this.time + (tower.branch === 0 ? 0.8 : 0.45) + (this.perks.includes("watch") ? 0.25 : 0));
        if (tower.branch === 0 && tower.level === 4) {
          for (const other of this.enemies) if (other.uid !== e.uid && dist(this.enemyPos(other), this.enemyPos(e)) < 60) other.stunUntil = Math.max(other.stunUntil, this.time + 0.35);
        }
        if (tower.branch === 1 && tower.level === 4) e.vulnerableUntil = this.time + 2.5;
      }
      if (tower.type === "granny" && tower.branch === 0 && tower.level === 4 && tower.shots % 4 === 0) e.stunUntil = Math.max(e.stunUntil, this.time + 0.65);
      if (tower.type === "cat" && tower.branch === 0 && tower.level === 4 && e.hp / e.maxHp < 0.18 && e.type !== "boss") damage = e.hp + e.shield + 10;
    }
    if (e.vulnerableUntil > this.time) damage *= 1.1;
    if (e.type === "boss" && this.perks.includes("bossBane")) damage *= 1.2;
    const resist = def.resists[type] ?? 1;
    damage *= resist;
    let armor = def.armor;
    if (e.type === "boss" && e.phase === 3) armor = Math.max(0, armor - 3);
    if (type !== "control") damage = Math.max(1, damage - armor);
    if (e.shield > 0) {
      const shieldMultiplier = type === "pierce" ? 0.45 : type === "heavy" ? 1.3 : 1;
      const absorbed = Math.min(e.shield, damage * shieldMultiplier);
      e.shield -= absorbed;
      damage = Math.max(0, damage - absorbed / shieldMultiplier);
      this.floatText(this.enemyPos(e).x, this.enemyPos(e).y - 30, `ЩИТ ${Math.round(absorbed)}`, "#82a9c2");
    }
    if (damage > 0) e.hp -= damage;
    e.flash = 1;
    e.hitAgo = 0;
    this.killedWaveHp += Math.min(damage, Math.max(0, e.hp + damage));
    if (tower) tower.damageDone += damage;
    if (crit || damage >= 30 || type === "heavy") this.floatText(this.enemyPos(e).x, this.enemyPos(e).y - 28, `${crit ? "КРИТ " : ""}${Math.round(damage)}`, crit ? "#f0cf7a" : "#d8d4cd");
    if (type === "heavy" && damage > 25) this.hitStop = Math.max(this.hitStop, 0.035);
    if (e.hp <= 0) this.killEnemy(e, tower);
  }

  killEnemy(e: Enemy, tower: Tower | null) {
    if (e.dead) return;
    e.dead = true;
    const def = ENEMIES[e.type];
    const reward = Math.max(1, Math.round(def.reward * Math.pow(this.hpScale(), 0.6)));
    this.coins += reward;
    this.score += Math.round(e.maxHp) + reward * 5;
    if (tower) tower.kills++;
    const pos = this.enemyPos(e);
    this.fadingActors.push({ type: e.type, x: pos.x, y: pos.y, phase: e.wobble, life: 0.65, maxLife: 0.65 });
    if (this.fadingActors.length > 64) this.fadingActors.shift();
    this.floatText(pos.x, pos.y - 22, `+${reward}`, "#e5c66f", "coin");
    this.burst(pos.x, pos.y, def.color, e.type === "boss" ? 24 : 8);
    if (e.type === "crowd") {
      for (let i = 0; i < 3; i++) this.spawnEnemy("skuf", e.lane, Math.max(0, e.progress - i * 12), 0.55);
      this.floatText(pos.x, pos.y - 50, "РАЗДЕЛИЛАСЬ ×3", "#cf9da6");
    }
    if (e.type === "boss") {
      this.slowMotion = 0.45;
      this.shake = 0.9;
      this.events.push("bossDown");
      this.say("УПРАВДОМ ОТСТУПАЕТ", `Ключи подобраны · +${reward} монет`, 3);
    }
  }

  updateHero(dt: number) {
    this.heroCooldown -= dt;
    if (this.heroCooldown > 0 || !this.waveActive) return;
    const target = this.enemies.filter((e) => !e.dead && dist(this.enemyPos(e), this.map.hero) < 245).sort((a, b) => b.progress - a.progress)[0];
    if (!target) return;
    this.heroCooldown = 0.82;
    this.heroRecoil = 1;
    this.projectiles.push({ uid: this.nextUid++, from: { x: this.map.hero.x, y: this.map.hero.y - 70 }, to: this.enemyPos(target), targetUid: target.uid, towerUid: -1, damage: 15 * (1 + this.wave * 0.015), type: "soft", speed: 660, life: 3, color: "#d9a0b3", aoe: 0, crit: false });
    this.events.push("hero");
  }

  updateProps(dt: number) {
    for (const p of this.props) {
      if (p.hp <= 0) continue;
      p.cooldown -= dt;
      const spot = this.map.props[p.spot];
      if (p.type === "clothesline") {
        for (const e of this.enemies) {
          if (ENEMIES[e.type].tags.includes("flying")) continue;
          if (dist(this.enemyPos(e), spot) < (this.perks.includes("lines") ? 130 : 90)) {
            if (e.slowUntil <= this.time || e.slowFactor > 0.75) e.slowFactor = 0.75;
            e.slowUntil = Math.max(e.slowUntil, this.time + 0.25);
          }
        }
      } else if (p.type === "dumpster" && !p.triggered) {
        const near = this.enemies.some((e) => !ENEMIES[e.type].tags.includes("flying") && dist(this.enemyPos(e), spot) < 48);
        if (near) {
          p.triggered = true;
          p.hp = 0;
          for (const e of this.enemies) if (dist(this.enemyPos(e), spot) < 115) this.applyHit(null, e, 150 * this.hpScale() ** 0.35, "heavy");
          this.ring(spot.x, spot.y, 115, "#d19065");
          this.burst(spot.x, spot.y, "#d8b078", 22);
          this.shake = 0.6;
          this.events.push("explode");
        }
      } else if (p.type === "car" && p.cooldown <= 0) {
        const near = this.enemies.filter((e) => !ENEMIES[e.type].tags.includes("flying") && dist(this.enemyPos(e), spot) < 135);
        if (near.length) {
          p.cooldown = 12;
          for (const e of near) e.stunUntil = Math.max(e.stunUntil, this.time + 1.2);
          this.ring(spot.x, spot.y, 135, "#c76565");
          this.events.push("alarm");
        }
      }
    }
    this.props = this.props.filter((p) => p.hp > 0);
  }

  updateEffects(dt: number) {
    for (const effect of this.effects) {
      effect.life -= dt;
      effect.tick -= dt;
      if (effect.kind === "cat" && effect.tick <= 0) {
        effect.tick += 0.5;
        for (const e of this.enemies) if (!e.dead && dist(this.enemyPos(e), effect) <= effect.radius) this.applyHit(null, e, 24 * (1 + this.wave * 0.025), "pierce");
        this.ring(effect.x, effect.y, effect.radius, "#d6bd6c");
      }
    }
  }

  armAbility(kind: "bucket" | "chord" | "cat") {
    if (!this.waveActive || this.cooldowns[kind] > 0 || this.paused) return false;
    this.pendingTower = null;
    this.targeting = this.targeting === kind ? null : kind;
    return true;
  }

  castAbility(x: number, y: number) {
    const kind = this.targeting;
    if (!kind || this.cooldowns[kind] > 0) return false;
    this.targeting = null;
    this.heroRecoil = 1;
    this.cooldowns[kind] = ABILITIES[kind].cooldown * (this.perks.includes("cold") ? 0.8 : 1);
    const radius = ABILITIES[kind].radius;
    if (kind === "cat") {
      this.effects.push({ kind, x, y, radius, life: 5, tick: 0 });
    } else {
      for (const e of this.enemies) {
        if (e.dead || dist(this.enemyPos(e), { x, y }) > radius) continue;
        if (kind === "bucket") {
          this.applyHit(null, e, 85 * (1 + this.wave * 0.025), "soft");
          e.slowFactor = Math.min(e.slowFactor, 0.5);
          e.slowUntil = this.time + 4;
        } else {
          this.applyHit(null, e, 55 * (1 + this.wave * 0.02), "control");
          e.stunUntil = Math.max(e.stunUntil, this.time + 1.5);
        }
      }
      this.effects.push({ kind, x, y, radius, life: 0.7, tick: 0 });
    }
    this.ring(x, y, radius, kind === "bucket" ? "#91b5c6" : kind === "chord" ? "#c19bd0" : "#d6bd6c");
    this.shake = kind === "chord" ? 0.55 : 0.3;
    this.hitStop = kind === "chord" ? 0.06 : 0;
    this.events.push("ability");
    return true;
  }

  prepareTower(type: TowerId) {
    const def = TOWERS[type];
    this.targeting = null;
    if (this.coins < def.cost) {
      this.say("НЕ ХВАТАЕТ МОНЕТ", `Нужно ещё ${Math.ceil(def.cost - this.coins)} монет`, 2.4);
      this.events.push("deny");
      return false;
    }
    if (this.selectedPad !== null && this.unlockedPads.includes(this.selectedPad) && !this.towers.some((t) => t.pad === this.selectedPad)) {
      return this.buildTower(this.selectedPad, type);
    }
    this.pendingTower = type;
    this.say(`ВЫБРАНА: ${def.name.toUpperCase()}`, "Нажми на свободную площадку во дворе", 2.7);
    return true;
  }

  buildTower(padId: number, type: TowerId) {
    const def = TOWERS[type];
    if (!this.unlockedPads.includes(padId)) {
      this.say("ПЛОЩАДКА ЗАКРЫТА", "Сначала расчисти её в карточке справа", 2.4);
      this.events.push("deny");
      return false;
    }
    if (this.towers.some((t) => t.pad === padId)) {
      this.say("ПЛОЩАДКА ЗАНЯТА", "Выбери свободное место", 2.4);
      this.events.push("deny");
      return false;
    }
    if (this.coins < def.cost) {
      this.say("НЕ ХВАТАЕТ МОНЕТ", `Нужно ещё ${Math.ceil(def.cost - this.coins)} монет`, 2.4);
      this.events.push("deny");
      return false;
    }
    this.coins -= def.cost;
    const t: Tower = {
      uid: this.nextUid++, type, pad: padId, level: 1, branch: null, cooldown: 0.2,
      targetMode: "first", kills: 0, damageDone: 0, invested: def.cost, buffUntil: 0, disabledUntil: 0, recoil: 0, shots: 0, facing: 1,
    };
    this.towers.push(t);
    this.selectedTowerUid = t.uid;
    this.selectedPad = padId;
    this.selectedPropUid = null;
    this.selectedSpot = null;
    this.pendingTower = null;
    this.ring(this.padPos(padId).x, this.padPos(padId).y, 65, def.color);
    this.say(`${def.name.toUpperCase()} НА ПОСТУ`, "Нажми на персонажа, чтобы улучшить", 1.8);
    this.events.push("build");
    return true;
  }

  unlockPad(padId: number) {
    const pad = this.map.pads.find((p) => p.id === padId);
    if (!pad || this.unlockedPads.includes(padId) || this.wave < pad.unlockWave || this.coins < pad.unlockCost) { this.events.push("deny"); return false; }
    this.coins -= pad.unlockCost;
    this.unlockedPads.push(padId);
    this.selectedPad = padId;
    this.events.push("build");
    this.say("НОВАЯ ПЛОЩАДКА", "Соседние связи пересчитаны", 1.6);
    return true;
  }

  upgradeCost(t: Tower) {
    const base = TOWERS[t.type].cost;
    if (t.level === 1) return Math.round(base * 0.55);
    if (t.level === 2) return Math.round(base * 0.85);
    if (t.level === 3) return Math.round(base * 1.35);
    return 0;
  }

  upgradeTower(uid: number, branch?: 0 | 1) {
    const t = this.towers.find((tower) => tower.uid === uid);
    if (!t || t.level >= 4) return false;
    if (t.level === 2 && branch === undefined) { this.events.push("deny"); return false; }
    if (t.level !== 2 && branch !== undefined) return false;
    const cost = this.upgradeCost(t);
    if (this.coins < cost) {
      this.say("НЕ ХВАТАЕТ МОНЕТ", `Для улучшения нужно ещё ${Math.ceil(cost - this.coins)} монет`, 2.4);
      this.events.push("deny");
      return false;
    }
    this.coins -= cost;
    t.invested += cost;
    t.level++;
    if (branch !== undefined) t.branch = branch;
    this.events.push("upgrade");
    this.ring(this.padPos(t.pad).x, this.padPos(t.pad).y, 85, TOWERS[t.type].color);
    if (t.level === 4) this.say("КАПСТОУН ОТКРЫТ", t.branch !== null ? TOWERS[t.type].branches[t.branch].capstone : "", 2.5);
    else this.say("УЛУЧШЕНИЕ ГОТОВО", `${TOWERS[t.type].name} · уровень ${t.level}`, 1.5);
    return true;
  }

  sellTower(uid: number) {
    const index = this.towers.findIndex((t) => t.uid === uid);
    if (index < 0) return;
    const t = this.towers[index];
    const refund = Math.floor(t.invested * 0.7);
    this.coins += refund;
    this.floatText(this.padPos(t.pad).x, this.padPos(t.pad).y - 25, `+${refund}`, "#e5c66f", "coin");
    this.towers.splice(index, 1);
    this.selectedTowerUid = null;
    this.selectedPad = t.pad;
    this.events.push("coin");
  }

  setTargetMode(uid: number, mode: Tower["targetMode"]) {
    const t = this.towers.find((tower) => tower.uid === uid);
    if (t) t.targetMode = mode;
  }

  buildProp(spot: number, type: PropId) {
    const spotDef = this.map.props.find((p) => p.id === spot);
    const data = PROP_DATA[type];
    if (!spotDef || !spotDef.allowed.includes(type) || this.props.some((p) => p.spot === spot) || this.coins < data.cost) { this.events.push("deny"); return false; }
    this.coins -= data.cost;
    const durability = data.hp * (this.perks.includes("props") ? 1.6 : 1);
    const prop: Prop = { uid: this.nextUid++, type, spot, hp: durability, maxHp: durability, cooldown: 0, triggered: false };
    this.props.push(prop);
    this.selectedPropUid = prop.uid;
    this.selectedSpot = spot;
    this.selectedTowerUid = null;
    this.selectedPad = null;
    this.events.push("build");
    return true;
  }

  removeProp(uid: number) {
    const p = this.props.find((prop) => prop.uid === uid);
    if (!p) return;
    this.coins += Math.floor(PROP_DATA[p.type].cost * 0.5 * (p.hp / p.maxHp));
    this.props = this.props.filter((prop) => prop.uid !== uid);
    this.selectedPropUid = null;
    this.events.push("coin");
  }

  selectAt(x: number, y: number) {
    let bestPad: PadDef | null = null;
    let best = 46;
    for (const pad of this.map.pads) {
      const d = dist(pad, { x, y });
      if (d < best) { best = d; bestPad = pad; }
    }
    // A standing character is taller than the ground marker; the whole body is clickable.
    if (!bestPad) {
      const tower = [...this.towers].sort((a, b) => this.padPos(b.pad).y - this.padPos(a.pad).y).find((t) => {
        const p = this.padPos(t.pad);
        return Math.abs(x - p.x) <= 42 && y >= p.y - 130 && y <= p.y + 18;
      });
      if (tower) bestPad = this.map.pads.find((p) => p.id === tower.pad) ?? null;
    }
    if (bestPad) {
      this.selectedPad = bestPad.id;
      this.selectedTowerUid = this.towers.find((t) => t.pad === bestPad!.id)?.uid ?? null;
      this.selectedPropUid = null;
      this.selectedSpot = null;
      if (this.pendingTower && !this.selectedTowerUid && this.unlockedPads.includes(bestPad.id)) this.buildTower(bestPad.id, this.pendingTower);
      return "pad";
    }
    for (const prop of this.props) {
      if (dist(this.map.props[prop.spot], { x, y }) < 46) {
        this.selectedPropUid = prop.uid;
        this.selectedSpot = prop.spot;
        this.selectedTowerUid = null;
        this.selectedPad = null;
        return "prop";
      }
    }
    for (const spot of this.map.props) {
      if (!this.props.some((p) => p.spot === spot.id) && dist(spot, { x, y }) < 38) {
        this.selectedSpot = spot.id;
        this.selectedPropUid = null;
        this.selectedTowerUid = null;
        this.selectedPad = null;
        return "spot";
      }
    }
    this.selectedPad = null;
    this.selectedTowerUid = null;
    this.selectedPropUid = null;
    this.selectedSpot = null;
    return null;
  }

  completeWave() {
    if (!this.waveActive) return;
    this.waveActive = false;
    const bonus = this.currentWave.bonus;
    this.coins += bonus;
    this.score += 500 + this.wave * 100;
    for (const t of this.towers) {
      if (t.type === "kiosk" && t.branch === 1 && t.level === 4) this.coins += Math.min(40, Math.floor(this.coins * 0.04));
    }
    this.events.push("waveClear");
    if (this.mode === "campaign" && this.wave >= MAX_WAVE) {
      this.status = "won";
      this.say("ДВОР ОТСТОЯН", "Рассвет. Можно выдохнуть.", 20);
      return;
    }
    this.status = "prep";
    this.intermission = 12;
    const newPads = this.map.pads.filter((p) => p.unlockWave === this.wave + 1);
    this.say(`ВОЛНА ${this.wave} ОТБИТА`, `+${bonus} монет${newPads.length ? " · доступна новая площадка" : " · следующая через 12 секунд"}`, 3.2);
    if (this.wave % 5 === 0) this.makeDraft();
  }

  makeDraft() {
    const available = PERKS.filter((perk) => !this.perks.includes(perk.id)).map((perk) => perk.id);
    const options: PerkId[] = [];
    while (available.length && options.length < 3) {
      const index = Math.floor(this.rng() * available.length);
      options.push(available.splice(index, 1)[0]);
    }
    this.draft = options.length ? options : null;
  }

  choosePerk(id: PerkId) {
    if (!this.draft?.includes(id)) return false;
    this.perks.push(id);
    this.draft = null;
    if (id === "threshold") { this.maxLives += 4; this.lives = Math.min(this.maxLives, this.lives + 4); }
    const perk = PERKS.find((item) => item.id === id)!;
    this.say(perk.name.toUpperCase(), perk.description, 3);
    this.events.push("upgrade");
    return true;
  }

  lose() {
    this.status = "lost";
    this.waveActive = false;
    this.paused = false;
    this.say("ПОДЪЕЗД ЗАХВАЧЕН", `Ты продержалась до волны ${this.wave}`, 20);
    this.events.push("lost");
  }

  get starsEarned() {
    if (this.status !== "won") return 0;
    return this.lives >= 18 ? 3 : this.lives >= 10 ? 2 : 1;
  }

  get earlyBonus() {
    if (this.waveActive || this.wave === 0 || this.intermission <= 0 || this.draft) return 0;
    let bonus = Math.floor(this.intermission * 2) + 8;
    if (this.map.id === "boiler") bonus = Math.floor(bonus * 1.5);
    if (this.perks.includes("bell")) bonus = Math.floor(bonus * 1.5);
    return bonus;
  }

  getLinks() {
    const links: { a: number; b: number; name: string; color: string }[] = [];
    for (let i = 0; i < this.towers.length; i++) {
      for (let j = i + 1; j < this.towers.length; j++) {
        const a = this.towers[i], b = this.towers[j];
        if (!this.areNeighbors(a.pad, b.pad)) continue;
        const pair = [a.type, b.type];
        if (pair.includes("speaker") && pair.includes("granny")) links.push({ a: a.pad, b: b.pad, name: "СИНКОПА", color: "#b39ad2" });
        else if (pair.includes("patrol") && pair.includes("cat")) links.push({ a: a.pad, b: b.pad, name: "В ГОЛОВУ", color: "#dcc477" });
        else if (pair.includes("kiosk") && pair.some((type) => type !== "kiosk")) links.push({ a: a.pad, b: b.pad, name: "ЭНЕРГЕТИК", color: "#d79a68" });
      }
    }
    return links;
  }

  hasLink(t: Tower, otherType: TowerId) {
    return this.towers.some((o) => o.type === otherType && this.areNeighbors(t.pad, o.pad));
  }

  areNeighbors(a: number, b: number) { return this.neighbors.get(a)?.includes(b) || this.neighbors.get(b)?.includes(a) || false; }
  padPos(id: number) { const p = this.map.pads.find((pad) => pad.id === id); return p ? { x: p.x, y: p.y } : { x: 0, y: 0 }; }

  enemyPos(e: Enemy): Vec {
    const metric = this.pathMetrics[e.lane];
    const d = clamp(e.progress, 0, metric.total);
    let segment = 1;
    while (segment < metric.lengths.length - 1 && metric.lengths[segment] < d) segment++;
    const a = metric.points[segment - 1], b = metric.points[segment];
    const len = metric.lengths[segment] - metric.lengths[segment - 1] || 1;
    const t = clamp((d - metric.lengths[segment - 1]) / len, 0, 1);
    let x = a.x + (b.x - a.x) * t;
    let y = a.y + (b.y - a.y) * t;
    if (e.type === "drunk") { x += Math.sin(this.time * 2 + e.wobble) * 12; y += Math.cos(this.time * 2.7 + e.wobble) * 8; }
    if (ENEMIES[e.type].tags.includes("flying")) y -= 22 + Math.sin(this.time * 5 + e.wobble) * 5;
    return { x, y };
  }

  pathPoint(lane: number, progress: number) {
    const fake = { lane, progress, type: "skuf", wobble: 0 } as Enemy;
    return this.enemyPos(fake);
  }

  updateParticles(dt: number) {
    for (const actor of this.fadingActors) actor.life -= dt;
    this.fadingActors = this.fadingActors.filter((actor) => actor.life > 0);
    for (const p of this.particles) {
      p.life -= dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      if (p.kind === "spark" || p.kind === "leaf") p.vy += 32 * dt;
      if (p.kind === "coin") { p.vx *= 0.98; p.vy -= 12 * dt; }
    }
    this.particles = this.particles.filter((p) => p.life > 0).slice(-220);
  }

  burst(x: number, y: number, color: string, count: number) {
    for (let i = 0; i < count; i++) {
      const angle = this.fxRng() * Math.PI * 2, speed = 25 + this.fxRng() * 90;
      this.particles.push({ x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed - 20, life: 0.35 + this.fxRng() * 0.35, maxLife: 0.7, size: 2 + this.fxRng() * 4, color, kind: "spark" });
    }
  }

  floatText(x: number, y: number, text: string, color: string, kind: Particle["kind"] = "text") {
    if (this.particles.filter((p) => p.kind === "text").length > 28 && kind === "text") return;
    this.particles.push({ x, y, vx: kind === "coin" ? 15 : 0, vy: kind === "coin" ? -55 : -32, life: kind === "coin" ? 1.25 : 0.85, maxLife: kind === "coin" ? 1.25 : 0.85, size: 13, color, kind, text });
  }

  ring(x: number, y: number, radius: number, color: string) {
    this.particles.push({ x, y, vx: radius, vy: 0, life: 0.55, maxLife: 0.55, size: 3, color, kind: "ring" });
  }

  snapshot(): Snapshot {
    const boss = this.enemies.find((e) => e.type === "boss" && !e.dead);
    return {
      coins: Math.floor(this.coins), lives: this.lives, maxLives: this.maxLives, wave: this.wave,
      status: this.status, speed: this.speed, paused: this.paused, enemies: this.enemies.length + this.spawnQueue.length,
      selectedPad: this.selectedPad, selectedTowerUid: this.selectedTowerUid, selectedTower: this.selectedTower,
      selectedProp: this.selectedProp, selectedSpot: this.selectedSpot, pendingTower: this.pendingTower,
      unlockedPads: [...this.unlockedPads], towers: this.towers, props: this.props,
      cooldowns: { ...this.cooldowns }, targeting: this.targeting, nextWave: this.nextWave, currentWave: this.currentWave,
      intermission: this.intermission, waveActive: this.waveActive, totalWaveHp: this.totalWaveHp, killedWaveHp: this.killedWaveHp,
      earlyBonus: this.earlyBonus, starsEarned: this.starsEarned, score: this.score, links: this.getLinks(), notice: this.notice,
      boss: boss ? { name: ENEMIES.boss.name, hp: Math.max(0, boss.hp), maxHp: boss.maxHp, phase: boss.phase, telegraph: boss.telegraph > 0 ? boss.telegraphKind : null } : null,
      waveProgress: this.totalInWave ? clamp(1 - (this.spawnQueue.length + this.enemies.filter((e) => !e.leaked).length) / this.totalInWave, 0, 1) : 0,
      totalSpawned: this.totalSpawned, totalInWave: this.totalInWave, endless: this.mode === "endless",
      perks: [...this.perks], draft: this.draft ? [...this.draft] : null, fps: this.fps,
    };
  }
}

export const WORLD_BOUNDS = { width: 1200, height: LOGICAL_HEIGHT };
