export interface MapProgress {
  stars: number;
  bestWave: number;
  cleared: boolean;
}

export type Progress = Record<string, MapProgress>;

const KEY = "altushka-td-progress-v2";

export function loadProgress(): Progress {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Progress) : {};
  } catch {
    return {};
  }
}

export function saveProgress(progress: Progress) {
  try { localStorage.setItem(KEY, JSON.stringify(progress)); } catch { /* локальное хранилище может быть закрыто */ }
}

export const totalStars = (progress: Progress) =>
  Object.values(progress).reduce((sum, item) => sum + (item.stars || 0), 0);

export function recordResult(progress: Progress, mapId: string, stars: number, wave: number, endless: boolean): Progress {
  const prev = progress[mapId] ?? { stars: 0, bestWave: 0, cleared: false };
  const next: MapProgress = {
    stars: Math.max(prev.stars, stars),
    bestWave: Math.max(prev.bestWave, wave),
    cleared: prev.cleared || (!endless && stars > 0),
  };
  const result = { ...progress, [mapId]: next };
  saveProgress(result);
  return result;
}

export function markSeenIntro(): boolean {
  try {
    if (localStorage.getItem("altushka-td-intro") === "1") return true;
    localStorage.setItem("altushka-td-intro", "1");
  } catch { /* noop */ }
  return false;
}
