import { chromium } from 'playwright';
const browser = await chromium.launch();
const errors = [];
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();
page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
await page.goto('http://localhost:4173/', { waitUntil: 'networkidle' });
await page.evaluate(() => { localStorage.setItem('altushka-td-progress-v2', JSON.stringify({ yard: { stars: 3, bestWave: 20, cleared: true }, arch: { stars: 2, bestWave: 12, cleared: true } })); localStorage.setItem('altushka-td-intro','1'); });
await page.reload({ waitUntil: 'networkidle' });
await page.waitForTimeout(700);
await page.screenshot({ path: 'tmp_shots/11-menu-returning.png' });
await page.locator('.nav-link', { hasText: 'Справочник' }).click();
await page.getByRole('button', { name: 'Визитёры' }).click();
await page.waitForTimeout(400);
await page.screenshot({ path: 'tmp_shots/12-codex-enemies.png' });
await page.getByRole('button', { name: 'Механика' }).click();
await page.waitForTimeout(300);
await page.screenshot({ path: 'tmp_shots/13-codex-mechanics.png', fullPage: true });
await page.locator('.nav-link', { hasText: 'Локации' }).click();
await page.waitForTimeout(400);
await page.screenshot({ path: 'tmp_shots/14-maps-unlocked.png' });
// start arch campaign
await page.locator('.map-row').nth(1).getByRole('button', { name: /Кампания/ }).click();
await page.waitForTimeout(1300);
await page.screenshot({ path: 'tmp_shots/15-arch-intro.png' });
const c1 = page.locator('canvas.board-canvas');
const b1 = await c1.boundingBox();
if (b1) {
  const scale = Math.min(b1.width / 1200, b1.height / 720);
  const ox = b1.x + (b1.width - 1200 * scale) / 2, oy = b1.y + (b1.height - 720 * scale) / 2;
  await page.mouse.click(ox + 390 * scale, oy + 340 * scale);
  await page.locator('.tower-card').filter({ hasText: 'Дозорный' }).first().click();
  await page.waitForTimeout(300);
  await page.mouse.click(ox + 390 * scale, oy + 340 * scale);
  await page.waitForTimeout(400);
}
await page.screenshot({ path: 'tmp_shots/16-arch-game.png' });
await page.getByRole('button', { name: /Начать ночь/i }).click();
await page.waitForTimeout(2500);
await page.screenshot({ path: 'tmp_shots/17-arch-wave.png' });
// resources loaded
const media = await page.evaluate(() => performance.getEntriesByType('resource').map(r => r.name).filter(n => /mp3|ogg/.test(n)).slice(0, 12));
console.log('MEDIA:', media);
console.log('ERRORS:', JSON.stringify(errors));
// boiler
await page.locator('button[title="Выйти"]').click({ force: true }).catch(()=>{});
await page.waitForTimeout(300);
if (await page.locator('.nav-link', { hasText: 'Локации' }).count() === 0) await page.goto('http://localhost:4173/', { waitUntil: 'networkidle' });
await page.locator('.nav-link', { hasText: 'Локации' }).click();
await page.locator('.map-row').nth(2).getByRole('button', { name: /Кампания/ }).click();
await page.waitForTimeout(1400);
await page.screenshot({ path: 'tmp_shots/18-boiler.png' });

// mobile
const ctxM = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
const m = await ctxM.newPage();
m.on('console', x => { if (x.type() === 'error') errors.push('MOBILE ' + x.text()); });
m.on('pageerror', e => errors.push('MOBILE PAGEERROR: ' + e.message));
await m.goto('http://localhost:4173/', { waitUntil: 'networkidle' });
await m.evaluate(() => localStorage.setItem('altushka-td-intro','1'));
await m.waitForTimeout(1000);
await m.screenshot({ path: 'tmp_shots/19-mobile-menu.png', fullPage: true });
await m.getByRole('button', { name: /Играть/ }).first().click();
await m.waitForTimeout(600);
await m.screenshot({ path: 'tmp_shots/20-mobile-maps.png', fullPage: true });
await m.getByRole('button', { name: /Кампания/ }).first().click();
await m.waitForTimeout(1300);
await m.screenshot({ path: 'tmp_shots/21-mobile-game.png', fullPage: true });
console.log('MOBILE ERRORS:', JSON.stringify(errors));
await browser.close();
