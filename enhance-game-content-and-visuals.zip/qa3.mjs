import { chromium } from 'playwright';
const browser = await chromium.launch();
const errors = [];
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();
page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
await page.goto('http://localhost:4173/', { waitUntil: 'networkidle' });
await page.evaluate(() => { localStorage.setItem('altushka-td-progress-v2', JSON.stringify({ yard: { stars: 3, bestWave: 20, cleared: true }, arch: { stars: 3, bestWave: 20, cleared: true }, boiler: { stars: 3, bestWave: 20, cleared: true } })); localStorage.setItem('altushka-td-intro','1'); });
await page.reload({ waitUntil: 'networkidle' });
await page.locator('.nav-link', { hasText: 'Локации' }).click();
await page.locator('.map-row').nth(2).getByRole('button', { name: /Кампания/ }).click();
await page.waitForTimeout(1800);
await page.screenshot({ path: 'tmp_shots/22-boiler.png' });
const c = page.locator('canvas.board-canvas'); const b = await c.boundingBox();
if (b) {
  const sc = Math.min(b.width/1200, b.height/720), ox = b.x + (b.width-1200*sc)/2, oy = b.y + (b.height-720*sc)/2;
  await page.mouse.click(ox+260*sc, oy+360*sc);
  await page.locator('.tower-card').filter({ hasText: 'Киоск' }).first().click();
  await page.waitForTimeout(350);
  await page.screenshot({ path: 'tmp_shots/23-boiler-kiosk.png' });
}
await page.locator('button[title="Скорость"]').first().click();
await page.getByRole('button', { name: /Начать ночь/i }).click();
await page.waitForTimeout(7000);
await page.screenshot({ path: 'tmp_shots/24-boiler-wave.png' });
await page.getByRole('button', { name: 'Справочник' }).count().then(async cnt => {
  if (!cnt) { await page.goto('http://localhost:4173/', { waitUntil: 'networkidle' }); }
});
await page.locator('.nav-link', { hasText: 'Справочник' }).click().catch(async () => { await page.locator('.brand').first().click(); await page.locator('.nav-link', { hasText: 'Справочник' }).click(); });
await page.getByRole('button', { name: 'Визитёры' }).click();
await page.waitForTimeout(500);
await page.screenshot({ path: 'tmp_shots/25-enemies-new.png', fullPage: true });
const ctxM = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
const m = await ctxM.newPage();
m.on('pageerror', e => errors.push('MOBILE PAGEERROR: ' + e.message));
await m.goto('http://localhost:4173/', { waitUntil: 'networkidle' });
await m.evaluate(() => { localStorage.setItem('altushka-td-intro','1'); localStorage.setItem('altushka-td-progress-v2', JSON.stringify({ yard: { stars: 3, bestWave: 20, cleared: true } })); });
await m.reload({ waitUntil: 'networkidle' });
await m.waitForTimeout(900);
await m.screenshot({ path: 'tmp_shots/26-mobile-menu.png', fullPage: true });
await m.getByRole('button', { name: /^Играть$/ }).first().click();
await m.waitForTimeout(500);
await m.screenshot({ path: 'tmp_shots/27-mobile-maps.png', fullPage: true });
await m.getByRole('button', { name: /Кампания/ }).first().click();
await m.waitForTimeout(1500);
await m.screenshot({ path: 'tmp_shots/28-mobile-game.png', fullPage: true });
console.log('ERRORS', JSON.stringify(errors));
await browser.close();
