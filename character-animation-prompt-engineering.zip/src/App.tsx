import { useEffect, useRef, useState, type CSSProperties } from "react";
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  Check,
  Copy,
  Download,
  Pause,
  Play,
} from "lucide-react";

const referenceUrl =
  "https://drive.google.com/file/d/14vFlhs8xsn4F0-IbFR9ejSDNpLB2PUgT/view?usp=sharing";

type Phase = {
  number: string;
  range: string;
  frames: string;
  start: number;
  title: string;
  short: string;
  movement: string;
  joints: string;
  velocity: string;
};

const phases: Phase[] = [
  {
    number: "01",
    range: "00-10%",
    frames: "FRAMES 00-02",
    start: 0,
    title: "Contact & load",
    short: "The lead heel finds the ground. Weight transfers into the supporting leg.",
    movement:
      "Plant the left heel while the right toes remain in contact. Shift the center of mass from between the feet toward the left support and lower the pelvis by about 2-3% of leg length. Roll the left contact from heel to full sole.",
    joints:
      "Left hip: about 25 deg flexion. Left knee: 5 to 15 deg flexion. Left ankle: about 5 deg dorsiflexion to neutral. The trailing right hip stays extended as its heel rises.",
    velocity:
      "Ease into the weight acceptance; let the knee absorb impact over 2-3 frames. Preserve forward root velocity and keep each active contact fixed in world space.",
  },
  {
    number: "02",
    range: "10-30%",
    frames: "FRAMES 02-07",
    start: 10,
    title: "Pass & rise",
    short: "The body moves over the planted foot as the free leg passes through.",
    movement:
      "Release the right toes at 10%. Move the pelvis over the planted left foot and let it rise from its low point. The right foot clears the floor without changing limb length; keep a modest 3-7 cm clearance at human scale.",
    joints:
      "Left hip: roughly 20 deg flexion to 5 deg extension; knee: 15 to 5 deg flexion; ankle: neutral to about 10 deg dorsiflexion. The right knee flexes to roughly 50-60 deg during swing.",
    velocity:
      "Accelerate the swinging leg from the hip, then let the knee and ankle follow. The foot reaches its vertical apex with zero vertical velocity; avoid straight, constant-speed arcs.",
  },
  {
    number: "03",
    range: "30-50%",
    frames: "FRAMES 07-12",
    start: 30,
    title: "Push & reach",
    short: "The trailing foot rolls to the toes while the next heel reaches forward.",
    movement:
      "Let the left heel rise while its toes remain fixed. Carry the pelvis forward, then extend the right leg into the next heel contact at 50%. The left toes stay planted until 60%.",
    joints:
      "Left hip: about 5 to 15 deg extension; knee: 5 to 15 deg flexion; ankle: about 10 deg dorsiflexion to 15 deg plantarflexion. Right hip reaches about 25 deg flexion; right knee extends to 5-10 deg flexion and the ankle stays near neutral for contact.",
    velocity:
      "Build push-off smoothly through the hip, knee, and ankle. Decelerate the incoming heel to near-zero world velocity at contact; do not snap the knee straight.",
  },
  {
    number: "04",
    range: "50-100%",
    frames: "FRAMES 12-24",
    start: 50,
    title: "Mirror & continue",
    short: "Repeat on the opposite side, carrying momentum through the loop seam.",
    movement:
      "Mirror the first half with the right leg in support. Transfer weight to the right, release the left toes at 60%, and return to the next left-heel contact at 100%. Keep the root moving forward throughout.",
    joints:
      "Use the same hip, knee, and ankle ranges on the opposite side. Counter-rotate the shoulders against the pelvis by about 2-4 deg. Free arms swing 10-20 deg opposite the legs, with 10-25 deg of elbow flexion, within rig limits.",
    velocity:
      "Match pose and first-order velocity at frames 0 and 24, accounting for the root's forward displacement. The last frame is an editing duplicate, not an extra held frame.",
  },
];

const rules = [
  {
    number: "01",
    title: "Weight & balance",
    text: "Keep the center of mass over the active support area, moving between supports during double contact. Use a small lateral shift, roughly 1-3 cm at human scale. Shorten the stride if the planted leg cannot reach.",
  },
  {
    number: "02",
    title: "A connected chain",
    text: "Lead from root and hips; propagate through spine, shoulders, elbows, and wrists with a slight delay. Counter-rotate the torso and stabilize the head by 1-3 deg. If a hand is constrained to a prop, maintain its existing grip rather than forcing a free arm swing.",
  },
  {
    number: "03",
    title: "Anticipation & release",
    text: "For entry, shift onto the support foot and flex the knees over 4-6 frames while easing the root into the loop speed. For exit, finish on a stable contact and settle over 4-8 frames. Do not add a stop at the loop seam.",
  },
  {
    number: "04",
    title: "Secondary motion",
    text: "Only where independent controls exist, let hair, loose elements, or gear lag the driving motion by 2-4 frames. Use gravity, damped follow-through, and collision against the unchanged body; if collision or controls are unavailable, keep that element still.",
  },
];

const phaseText = phases
  .map(
    (phase) =>
      `${phase.number}. ${phase.title.toUpperCase()} (${phase.range}, ${phase.frames})\n${phase.movement}\nJoint rotations: ${phase.joints}\nVelocity: ${phase.velocity}`,
  )
  .join("\n\n");

const specText = `ALTUSHKA / ANIMATION SPECIFICATION\nNATURAL WALK CYCLE - PROPOSED BASELINE\n\nNo specific action was named. This is a proposed natural walk, not an inferred action. The supplied archive contains 2D artwork and procedural mesh motion, not a skeletal rig. These joint-level instructions are conditional on an existing compatible rig.\n\nTIMING\n24 fps; 24-frame / 1-second cycle. Frame 24 duplicates frame 0 for editing, with the root offset by one stride. Left support: 0-60%; right support: 50-100% and 0-10% of the next cycle. Angles are approximate local rotations relative to neutral: flexion and dorsiflexion are positive. Adapt to the existing rig's axes and limits.\n\n${phaseText}\n\nMOTION RULES\n${rules.map((rule) => `${rule.title}: ${rule.text}`).join("\n\n")}\n\nCONTACT, CURVES & PHYSICS\nUse world-space IK locks for the planted heel, sole, or toe pivot. Release only after weight is transferred; never slide a planted contact. Use smooth cubic or Hermite curves with matched tangents at the seam, acceleration away from extrema, and deceleration into contact. Run secondary simulation at a stable fixed step, such as 1/120 s, with a damping ratio around 0.65-0.85 and collision enabled. Maintain original local bone scales and lengths at all times; never use stretch IK, mesh scaling, or bone elongation. If controls or collision are not present, do not invent or deform them.\n`;

function App() {
  const [progress, setProgress] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [copyState, setCopyState] = useState<"idle" | "copied" | "error">("idle");
  const lastFrame = useRef<number | null>(null);
  const copyTimeout = useRef<number | null>(null);

  useEffect(() => {
    if (!playing) {
      lastFrame.current = null;
      return;
    }

    let animationFrame = 0;
    const tick = (now: number) => {
      if (lastFrame.current !== null) {
        const elapsed = Math.min(now - lastFrame.current, 100);
        setProgress((current) => (current + elapsed / 10) % 100);
      }
      lastFrame.current = now;
      animationFrame = window.requestAnimationFrame(tick);
    };
    animationFrame = window.requestAnimationFrame(tick);
    return () => {
      window.cancelAnimationFrame(animationFrame);
      lastFrame.current = null;
    };
  }, [playing]);

  useEffect(() => () => {
    if (copyTimeout.current !== null) window.clearTimeout(copyTimeout.current);
  }, []);

  const activePhase =
    progress < 10 ? phases[0] : progress < 30 ? phases[1] : progress < 50 ? phases[2] : phases[3];
  const frame = Math.min(24, Math.round((progress / 100) * 24));

  const selectPhase = (phase: Phase) => {
    setPlaying(false);
    setProgress(phase.start);
  };

  const copySpec = async () => {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(specText);
      } else {
        const field = document.createElement("textarea");
        field.value = specText;
        field.style.position = "fixed";
        field.style.opacity = "0";
        document.body.appendChild(field);
        field.select();
        const copied = document.execCommand("copy");
        field.remove();
        if (!copied) throw new Error("Copy unavailable");
      }
      setCopyState("copied");
    } catch {
      setCopyState("error");
    }
    if (copyTimeout.current !== null) window.clearTimeout(copyTimeout.current);
    copyTimeout.current = window.setTimeout(() => setCopyState("idle"), 2600);
  };

  const downloadSpec = () => {
    const url = URL.createObjectURL(new Blob([specText], { type: "text/plain;charset=utf-8" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = "altushka-walk-animation-spec.txt";
    link.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  return (
    <div className="app-shell">
      <header className="site-header">
        <a className="brand" href="#top" aria-label="Altushka Motion Study, back to top">
          <span className="brand-mark">A</span>
          <span className="brand-name">ALTUSHKA <small>MOTION STUDIES</small></span>
        </a>

        <nav className="main-nav" aria-label="Page sections">
          <a className="nav-current" href="#top">The brief</a>
          <a href="#breakdown">The movement</a>
          <a href="#principles">The principles</a>
        </nav>

        <div className="header-actions">
          <a className="source-link" href={referenceUrl} target="_blank" rel="noreferrer">
            Source file <ArrowUpRight size={14} />
          </a>
          <button className="copy-button" type="button" onClick={() => void copySpec()}>
            {copyState === "copied" ? <Check size={15} /> : <Copy size={15} />}
            <span>{copyState === "copied" ? "Copied" : copyState === "error" ? "Copy failed" : "Copy brief"}</span>
          </button>
        </div>
      </header>

      <main id="top">
        <section className="hero-layout" aria-labelledby="main-title">
          <figure className="reference-panel">
            <div className="reference-topline">
              <span>REFERENCE / 01</span>
              <span>ORIGINAL SOURCE</span>
            </div>
            <div className="reference-image-wrap">
              <img src="/reference/altushka.png" alt="Static source reference from the supplied archive" />
            </div>
            <figcaption className="reference-caption">
              <span><i /> STATIC REFERENCE</span>
              <span>ALTUSHKA / SOURCE 01</span>
            </figcaption>
          </figure>

          <div className="hero-content">
            <div className="hero-intro">
              <div className="overline"><span className="short-line" /> ANIMATION STUDY <span className="overline-separator">/</span> 01</div>
              <h1 id="main-title">Natural walk<br /><em>cycle.</em></h1>
              <p className="hero-description">A grounded, continuous movement that starts at the hips and carries through the whole body.</p>
              <p className="assumption"><span>PROPOSED BASELINE</span> No specific action was named in the brief.</p>
            </div>

            <div className="timeline" aria-label="Interactive cycle timing guide">
              <div className="timeline-heading">
                <div>
                  <div className="section-kicker">01 / TIMING GUIDE</div>
                  <h2>One complete cycle</h2>
                </div>
                <div className="timing-meta">24 FPS <span>/</span> 1.00 SEC</div>
              </div>

              <div className="timeline-controls">
                <button
                  className="play-button"
                  type="button"
                  onClick={() => setPlaying((value) => !value)}
                  aria-label={playing ? "Pause timing guide" : "Play timing guide"}
                >
                  {playing ? <Pause size={17} fill="currentColor" /> : <Play size={17} fill="currentColor" />}
                </button>
                <div className="timeline-track-area">
                  <div className="frame-labels" aria-hidden="true"><span>00</span><span>06</span><span>12</span><span>18</span><span>24</span></div>
                  <input
                    aria-label="Scrub cycle timing"
                    aria-valuetext={`Frame ${frame} of 24, ${activePhase.title}`}
                    className="timeline-range"
                    type="range"
                    min="0"
                    max="100"
                    step="0.1"
                    value={progress}
                    onChange={(event) => {
                      setPlaying(false);
                      setProgress(Number(event.currentTarget.value));
                    }}
                    style={{ "--progress": `${progress}%` } as CSSProperties}
                  />
                  <div className="track-labels"><span>CONTACT</span><span>PASSING</span><span>CONTACT</span><span>PASSING</span></div>
                </div>
              </div>

              <div className="phase-selector" aria-label="Jump to a cycle phase">
                {phases.map((phase) => (
                  <button
                    type="button"
                    key={phase.number}
                    className={activePhase.number === phase.number ? "selected" : ""}
                    onClick={() => selectPhase(phase)}
                    aria-pressed={activePhase.number === phase.number}
                  >
                    <span>{phase.number}</span> {phase.title}
                  </button>
                ))}
              </div>

              <div className="active-cue" aria-live="polite">
                <div className="cue-number">{activePhase.number} <span>/ 04</span></div>
                <div className="cue-copy">
                  <div className="cue-title-line"><h3>{activePhase.title}</h3><span>{activePhase.range} OF CYCLE</span></div>
                  <p>{activePhase.short}</p>
                </div>
              </div>
              <div className="timeline-bottom">
                <span>Timing only. Source reference is static.</span>
                <a href="#breakdown">Full breakdown <ArrowDown size={13} /></a>
              </div>
            </div>

            <div className="hero-footnote">
              <span className="footnote-index">RIG NOTE</span>
              <p>The archive contains 2D artwork; rig-level steps are conditional.</p>
            </div>
          </div>
        </section>

        <section id="breakdown" className="breakdown-section content-section">
          <div className="section-intro">
            <div className="section-kicker"><span className="short-line" /> 02 / CYCLE BREAKDOWN</div>
            <h2>Movement,<br /><em>with intention.</em></h2>
            <p>Follow the weight from one point of contact to the next. The second half mirrors the first.</p>
            <div className="section-side-note"><span>THE LOOP</span><strong>00 <i /> 24</strong><small>FRAMES AT 24 FPS</small></div>
          </div>

          <div className="phase-list">
            <div className="list-heading"><span>PHASE / ACTION</span><span>TIME / FRAME</span></div>
            {phases.map((phase) => (
              <article className="phase-row" key={phase.number}>
                <div className="phase-index">{phase.number}</div>
                <div className="phase-body">
                  <div className="phase-heading"><h3>{phase.title}</h3><div><span>{phase.range}</span><small>{phase.frames}</small></div></div>
                  <p>{phase.movement}</p>
                  <div className="technical-line"><b>JOINTS</b><p>{phase.joints}</p></div>
                  <div className="technical-line"><b>CURVE</b><p>{phase.velocity}</p></div>
                </div>
              </article>
            ))}
            <p className="angle-note">Angles are approximate local rotations relative to neutral. Flexion and dorsiflexion are positive; adapt signs to the existing rig axes and limits.</p>
          </div>
        </section>

        <section id="principles" className="principles-section content-section">
          <div className="principles-header">
            <div>
              <div className="section-kicker"><span className="short-line" /> 03 / THE PRINCIPLES</div>
              <h2>Keep it <em>alive.</em><br />Keep it grounded.</h2>
            </div>
            <p>The small decisions that make a cycle feel like continuous, physical movement.</p>
          </div>
          <div className="rule-grid">
            {rules.map((rule) => (
              <article className="rule" key={rule.number}>
                <span className="rule-index">{rule.number} /</span>
                <h3>{rule.title}</h3>
                <p>{rule.text}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="constraints-section content-section">
          <div className="constraint-title">
            <div className="section-kicker"><span className="short-line" /> 04 / NON-NEGOTIABLE</div>
            <h2>Motion only.<br /><em>Nothing stretched.</em></h2>
          </div>
          <div className="constraint-copy">
            <p>Maintain original local bone scales and lengths at all times. No stretch IK, mesh scaling, or bone elongation. Lock each planted heel, sole, or toe pivot in world space and release only after weight transfers.</p>
            <p>Use smooth cubic or Hermite curves, with matched tangents at the loop seam. Run secondary simulation at a fixed step such as 1/120 s, with a damping ratio around 0.65-0.85 and collision enabled.</p>
            <div className="source-note"><span>REFERENCE NOTE</span><p>The supplied archive contains 2D artwork and procedural mesh motion, not a skeletal rig. This joint-level brief is conditional on an existing compatible rig; the timing guide does not animate the source.</p></div>
          </div>
        </section>

        <section className="end-section">
          <div><span className="section-kicker">READY FOR THE ANIMATION LAYER</span><h2>Keep the movement honest.</h2></div>
          <button className="download-button" type="button" onClick={downloadSpec}>Download the brief <Download size={16} /></button>
        </section>
      </main>

      <footer className="site-footer">
        <a className="footer-brand" href="#top"><span>A</span> ALTUSHKA / MOTION STUDIES</a>
        <span>ANIMATION SPECIFICATION / 01</span>
        <a href="#top">BACK TO TOP <ArrowRight size={13} /></a>
      </footer>
    </div>
  );
}

export default App;